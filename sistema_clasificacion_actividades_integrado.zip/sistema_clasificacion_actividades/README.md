# Sistema de Clasificación de Actividades Físicas

Compara dos clasificadores de ejercicios (**abdominales, pesas, salto, elasticidad**) a partir de video. Cada modelo recibe **imágenes + features tabulares geométricas** calculadas con las poses (MediaPipe Pose) de los mismos frames clave:

| Modelo | Arquitectura |
|---|---|
| **Clásico** | imágenes: MobileNetV3Small (por frame) → LSTM(128) → Dropout(0.3) · tabular: Dense(32) → Dropout(0.2) → Dense(16) → **Concatenate** → Dense(64) → Dense(n_clases, softmax) |
| **Híbrido cuántico-clásico** | imágenes: MobileNetV3Small (por frame) → promedio temporal → Dropout(0.3) · tabular: igual → **Concatenate** → Dense(n_qubits, tanh) → ×π → **PQC** → Dense(n_clases, softmax) |

Ambos comparten extractor (80 % de capas congeladas), dataset particionado, semilla (42) y condiciones de entrenamiento. Las caras se **anonimizan siempre** (desenfoque gaussiano) al preparar el dataset y en la cámara. El extractor, la LSTM y el PQC no se modificaron.

## Instalación

Requiere **Python 3.9 – 3.11** (TensorFlow 2.15 no soporta 3.12+).

```bash
python -m venv venv
# Windows: venv\Scripts\activate      Linux: source venv/bin/activate
pip install -r requirements.txt
```

* Linux: `sudo apt install python3-tk`. `nvidia-smi` es opcional (sin él la GPU se reporta como 0 %).
* `requirements.txt` fija `autoray==0.6.12`: con `pennylane==0.35.1`, un `autoray` más nuevo rompe el import de PennyLane (`AttributeError: ... NumpyMimic`).
* La detección en vivo con modelos multimodales necesita **MediaPipe Pose** (incluido en `mediapipe==0.10.9`) además de Face Detection.

## Preparar el dataset

```
datos/dataset/
├── train/       <clase>/video1.mp4 ...
├── validation/  <clase>/...
└── test/        <clase>/...
```

Las subcarpetas de `train/` definen las clases y **deben ser** `abdominales`, `pesas`, `salto` y `elasticidad`: el detector de ejercicios solo conoce esas cuatro y con otro nombre falla con un mensaje claro. Al entrenar (o con `Preprocesador.procesar_dataset()`) cada video se procesa con la herramienta integrada y genera en `datos/frames/{split}/<clase>/<video>/`:

| Archivo | Contenido |
|---|---|
| `000.jpg … 007.jpg` | `seq_length` frames clave anonimizados, del intervalo del ejercicio |
| `poses.npz` | landmarks de MediaPipe Pose de **todos** los frames (+ fps, ancho, alto) |
| `meta.json` | intervalo detectado, `deteccion_ok`, `indices_clave`, … |
| `debug.png` | señal de detección con intervalo y frames clave |
| `features.csv`, `features_seq.csv` | diagnóstico de la herramienta. **El entrenamiento NO los usa** (ver abajo) |

Si `deteccion_ok` es `False` el detector no halló el ejercicio y se usó el video completo (se avisa en el log con el número de videos afectados); revise su `debug.png`.

## Uso

```bash
python main.py
```

1. **Configuración**: modelo, qubits, `seq_length`, shots, learning rate, épocas, batch size, ruta del dataset y la casilla **Usar features tabulares (CSV)**.
2. **Entrenamiento**: Clásico / Híbrido / Ambos. Los modelos se guardan en `modelos_guardados/`.
3. **Evaluación comparativa** sobre `test/` (accuracy, precision, recall, F1, tiempo/video, CPU, GPU, RAM).
4. **Detección en tiempo real** con cámara.

## Integración de la herramienta de preparación de dataset

### Qué se copió (`modulos/preparar_dataset/`)

`detector_ejercicio.py`, `gestor_csv.py` y `graficos.py` son **idénticos** a la herramienta. Cambian:

| Archivo | Cambio |
|---|---|
| `__init__.py` | **Nuevo** (no se copió el de la herramienta). Exporta la API pública y contiene los parámetros del detector (el antiguo `config.json`) como `PARAMETROS_DETECTOR`; `cargar_config(cfg)` toma `n_seq` ← `seq_length`, `img_size` y `clases` del proyecto. |
| `extractor_frames.py` | Sin `importlib` ni `Anonimizador` duplicado: `from modulos.preprocesamiento import Anonimizador` (el único). |
| `calculador_features.py` | Añadido `features_desde_poses`, `NOMBRES_FEATURES`, `N_FEATURES`. Lo anterior intacto. |
| `pipeline.py` | `procesar_video(..., carpeta_destino=None)`; eliminados `configurar_logging` y `fijar_semillas` (el proyecto tiene los suyos). |

No se copiaron `visor.py`, `main.py` ni `generar_videos_sinteticos.py`. `herramientas/preparar_dataset/` no se tocó.

### Rama tabular: qué entra y por qué NO `features_seq.csv`

`analizar_video(clase, …)` recibe la **clase real** y con ella decide el intervalo y casi todo el `meta` (`tipo_evento`, `n_repeticiones`, columnas exclusivas de salto/elasticidad…). Entrenar con `features_seq.csv` filtraría la etiqueta (métricas infladas) y esas columnas no existen en inferencia. La rama tabular usa solo `features_desde_poses(poses, aspecto)`, que **no recibe la clase**:

* Por frame clave, **13** valores: 9 ángulos (rodilla/cadera/codo/hombro izq-der, tronco), `ancho_hombros`, `y_cadera_media`, `x_cadera_media`, `visibilidad_media`.
* Por cada uno: `media, std, min, max, rom` → 13 × 5 = 65.
* Globales: `energia_media_intervalo` (media del desplazamiento de los 33 landmarks entre frames clave consecutivos / ancho de hombros mediano) y `delta_y_cadera`.
* **Total: 67 features** (`N_FEATURES`, derivado de la lista de nombres; no hay un 67 fijo en la lógica). *El plan decía 14 valores por frame → 72; la lista de features del plan suma 13, por lo que el total correcto es 67. Añadir una feature es agregar un nombre en `calculador_features.py`.*
* Los NaN (frames sin pose) no se interpolan: se ignoran en los estadísticos y lo que quede NaN se imputa.

Entrenamiento y detección usan **la misma función** y la misma entrada (poses de los frames clave).

### Imputación y normalización

En cada entrenamiento (`crear_dataset("train", entrenamiento=True)`), **solo con `train`**:

* `medias_imputacion`: `{columna: nanmean}` (0.0 si toda la columna es NaN).
* `medias_normalizacion` / `stds_normalizacion`: media y desviación tras imputar (std ≈ 0 → 1).

Se guardan en `config_<modelo>.json` junto con `columnas_tabulares` (orden exacto) y `n_features_tabulares`. Validación, test, evaluación e inferencia usan esos mismos valores (`Evaluador` toma los del **modelo**, no los de la configuración actual). Si el orden de `columnas_tabulares` no coincide con el código, se rechaza el guardado/carga con un error explícito.

### Cambios por archivo

| Archivo | Cambio |
|---|---|
| `modulos/configuracion.py` | Nuevos campos (`usar_features_tabulares=True`, `columnas_tabulares`, `medias_imputacion`, `medias_normalizacion`, `stds_normalizacion`, `n_features_tabulares`); clases por defecto = las 4 de la herramienta; eliminado `anonimizar` (nunca se leía; se descarta al cargar un config antiguo); `validar` comprueba la coherencia columnas/`n_features`. |
| `modulos/preprocesamiento.py` | `Anonimizador` sin cambios. `extraer_frames_video` **eliminado**; `procesar_dataset` llama a `procesar_video` por video (mismo manejo de errores: `RuntimeError` global aborta, el resto se registra y sigue). `listar_muestras` → `(rutas_img, rutas_poses, etiquetas)`. `crear_dataset` → `((img, tab), y)` (o `(img, y)` sin rama tabular). Nuevos: `features_de_video`, `calcular_estadisticas_tabulares`, `normalizar_features`. |
| `modulos/modelo_clasico.py`, `modelo_hibrido.py` | Segunda entrada `entrada_tabular (F,)` y rama Dense(32)→Dropout(0.2)→Dense(16); concatenación tras `Dropout(0.3)` de la LSTM (clásico) / de `GlobalAveragePooling1D` (híbrido, antes de `Dense(n_qubits, tanh)`). `parametros()` incluye los campos tabulares. Sin rama tabular el grafo es el de antes. |
| `modulos/entrenamiento.py` | Solo mensajes de log (Keras acepta `((img, tab), y)` sin cambios). |
| `modulos/evaluacion.py` | Usa el modelo guardado para decidir imagen sola o imagen+tabular y sus estadísticas. |
| `modulos/persistencia.py` | Guarda/valida los campos tabulares; `cargar` sin `usar_features_tabulares` ⇒ `False`; nuevo `cargar_parametros`. |
| `modulos/deteccion_tiempo_real.py` | Ver «Detección en tiempo real». |
| `interfaz/pantalla_configuracion.py` | Casilla «Usar features tabulares (CSV)» (nada más). |
| `interfaz/pantalla_deteccion.py` | Pasa `params` del modelo al detector (1 línea; necesario para las estadísticas). |
| `prueba_entrenamiento.py` | Reescrita: poses sintéticas auxiliares de las 4 clases + todas las comprobaciones de aceptación. |
| `requirements.txt`, `config.json` | Fusionados / actualizados. |
| `benchmark_deteccion.py` | **Nuevo**: mide FPS con y sin rama tabular. |

### Cómo se entrena y cómo se desactiva

* **Con features** (por defecto): `usar_features_tabulares=true`. Al entrenar, los videos sin `poses.npz` se reprocesan (un dataset de frames anterior se completa solo; los videos ya completos se omiten).
* **Solo imágenes**: desmarque la casilla (o `"usar_features_tabulares": false`). Todo funciona como antes: dataset `(img, y)`, un solo input, sin Pose en vivo.
* **Modelos antiguos**: si `config_<modelo>.json` no tiene `usar_features_tabulares` se asume `False`, se reconstruye el modelo de un solo input y se evalúa/usa solo con imágenes, aunque la configuración actual tenga la casilla activa.

### Detección en tiempo real

* **Hilo de captura**: en 1 de cada `paso_muestreo` frames ejecuta **MediaPipe Pose** (misma configuración que el entrenamiento, sobre el frame original antes del blur) y guarda las poses en un búfer paralelo al de imágenes.
* **Hilo de inferencia**: `features_desde_poses` → imputar → normalizar (con las estadísticas del modelo) → `modelo([x_imagen, x_tabular])`. Solo infiere cuando hay una muestra nueva.
* `seq_length` e `img_size` se leen de `input_shape` identificando cada entrada por su rango, con 1 o 2 inputs.
* Modelos antiguos: no crean Pose, mismo comportamiento que antes.

**Rendimiento** (`python benchmark_deteccion.py --fuente video.mp4`). Medido en un contenedor de **1 vCPU**, TF 2.15 CPU, Python 3.11, 224×224, `seq_length=8`, `paso_muestreo=4`, un video 640×480 con una persona (Pose detectada en el 100 % de los frames) como fuente **sin límite de cámara**, pesos aleatorios:

| Caso | FPS global | FPS medio / mínimo (EMA) | inferencias/s |
|---|---|---|---|
| Solo imagen (sin Pose) | 86,2 | 93,1 / 77,2 | 1,69 |
| Imagen + tabular (Pose en captura) | 49,8 | 73,1 / 59,6 | 1,61 |

Costes: Pose 15,1 ms por llamada (≈ 3,8 ms por frame capturado a `paso_muestreo=4`); `features_desde_poses` 1,2 ms; inferencia ≈ 265 ms en ambos casos. La rama tabular reduce la captura sostenible de ~86 a ~50 FPS en esa máquina, muy por encima de 15; con cámara real el límite es el de la cámara (~30). Mida en su equipo con el script (con cámara: `--fuente 0`).

### Resumen de archivos

* **Nuevos (copiados de la herramienta, `modulos/preparar_dataset/`)**: `detector_ejercicio.py`, `gestor_csv.py`, `graficos.py` (idénticos); `calculador_features.py`, `extractor_frames.py`, `pipeline.py` (refactorizados). **Nuevo propio**: `__init__.py`.
* **Nuevos del proyecto**: `benchmark_deteccion.py`.
* **Modificados**: `config.json`, `requirements.txt`, `README.md`, `prueba_entrenamiento.py`, `modulos/{configuracion,preprocesamiento,modelo_clasico,modelo_hibrido,entrenamiento,evaluacion,persistencia,deteccion_tiempo_real}.py`, `interfaz/{pantalla_configuracion,pantalla_deteccion}.py`.
* **Eliminados**: ningún archivo. Se eliminaron `Preprocesador.extraer_frames_video` y la clave `anonimizar` de la configuración.
* **Sin cambios**: `main.py`, `modulos/circuito_cuantico.py`, el resto de `interfaz/`.

## Prueba paso a paso

```bash
pip install -r requirements.txt
python prueba_entrenamiento.py                  # E2E completo, 2 épocas (carpetas temporales)
python prueba_entrenamiento.py --omitir-vivo    # sin la parte de cámara
python benchmark_deteccion.py --fuente 0        # FPS con cámara real
python main.py                                  # GUI
```

La prueba E2E genera videos de un muñeco con sus `.poses.npz` y comprueba: archivos por video, `features_desde_poses` (67 floats, sin clase), formas `((B,8,S,S,3), (B,67), (B,))`, entrenar/evaluar ambos modelos con guardado→carga, modelo antiguo (JSON sin la clave), `usar_features_tabulares=False` y la detección en vivo (clásico, híbrido y antiguo) con un video como cámara.

**Con sus videos reales**: ponga `.mp4` en `datos/dataset/{train,validation,test}/<clase>/`, entrene desde la GUI y revise un `debug.png`/`meta.json` por clase.

## Limitaciones conocidas (documentadas, no resueltas)

1. **Desfase entrenamiento ↔ vivo (temporal)**: en entrenamiento los 8 frames abarcan el intervalo del ejercicio recortado con reglas de la clase (varios segundos); en vivo son los últimos 8 muestreados (~1 s con `paso_muestreo=4`) sin recorte. Afecta tanto a las imágenes como a `std/rom/energía`. Ajuste `paso_muestreo` si sus ejercicios son lentos/rápidos.
2. **Desfase de poses**: en entrenamiento MediaPipe ve el video continuo; en vivo, 1 de cada 4 frames, y su suavizado temporal difiere. Con una persona de prueba, tronco/hombros/cadera coinciden (|dif| mediana 0,15 en 46 features visibles) pero codos parcialmente fuera de cuadro llegaron a diferir 28°.
3. **Aumento horizontal**: el volteo se aplica solo a la imagen (como pide el plan); las features no se espejan (izq/der).
4. `delta_y_cadera` duplica `y_cadera_media_rom` (ambas del plan).
5. Los videos con `deteccion_ok=False` se incluyen (video completo).
6. Una clase distinta de las cuatro conocidas aborta el procesamiento con un error claro.

## Notas de diseño

* **PQC**: `AngleEmbedding (RY)` → `StronglyEntanglingLayers` → `<Z>` por qubit (PennyLane `default.qubit`, `qml.qnn.KerasLayer`).
* **Shots**: por defecto el entrenamiento usa simulación analítica; `"usar_shots_entrenamiento": true` usa `shots` con la regla de desplazamiento de parámetros (mucho más lento).
* **Persistencia**: pesos `.h5` + JSON de arquitectura (la capa cuántica no es serializable con `model.save`).
* **Hilos**: entrenamiento y evaluación en hilos con colas hacia la GUI; la detección usa hilos de captura e inferencia independientes.
* **Comparación**: el híbrido sustituye la LSTM por promedio temporal + PQC (según la especificación), así que la diferencia de rendimiento refleja también esa decisión.
