"""Prueba de extremo a extremo con un dataset sintético de ejemplo.

Genera videos de un muñeco de palitos para las cuatro clases (abdominales,
pesas, salto, elasticidad) y, junto a cada video, ``<video>.poses.npz`` con los
landmarks "reales" del muñeco. MediaPipe no detecta muñecos de palitos, así que
la herramienta integrada usa ese archivo auxiliar en lugar de MediaPipe Pose
(``usar_poses_sinteticas``); los videos reales nunca lo tienen.

Comprueba, con carpetas temporales (no toca sus datos ni sus modelos):

 1. ``procesar_dataset``: ``seq_length`` JPG + ``poses.npz`` + ``meta.json`` +
    ``debug.png`` en ``frames/{split}/<clase>/<video>/``.
 2. ``features_desde_poses`` devuelve ``N_FEATURES`` valores sin recibir la clase.
 3. ``crear_dataset`` produce ``((img, tab), y)`` con las formas correctas, y las
    estadísticas de normalización salen solo de train.
 4. Entrenamiento y evaluación de ambos modelos con rama tabular (guardar/cargar).
 5. Un modelo "antiguo" (JSON sin ``usar_features_tabulares``) carga y predice.
 6. Con ``usar_features_tabulares=False`` todo funciona como antes (solo imágenes).
 7. Detección en tiempo real (con un video como fuente) con el modelo multimodal
    y con el antiguo.

Uso::

    python prueba_entrenamiento.py                # prueba rápida (2 épocas)
    python prueba_entrenamiento.py --epocas 10 --videos 12
"""
import argparse
import json
import logging
import sys
import tempfile
import time
from pathlib import Path

import cv2
import numpy as np

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from modulos.configuracion import Configuracion, fijar_semillas  # noqa: E402

logger = logging.getLogger("prueba")
CLASES = ["abdominales", "pesas", "salto", "elasticidad"]

# ------------------------------------------------------------ muñeco sintético
# Coordenadas en px de un cuadro de 640x480 (como la herramienta); se normalizan
# a [0, 1], de modo que el video final puede ser más pequeño.
W0, H0, FPS, DUR = 640, 480, 30, 5.0
N_FRAMES = int(FPS * DUR)
TRONCO, MUSLO, PANTORRILLA, BRAZO, ANTEBRAZO, ANCHO_H, ANCHO_C = 120, 90, 80, 55, 55, 70, 44
CONEXIONES = [(11, 12), (11, 13), (13, 15), (12, 14), (14, 16), (11, 23), (12, 24),
              (23, 24), (23, 25), (25, 27), (24, 26), (26, 28)]


def suave(t, t0, t1):
    """Rampa suave 0 -> 1 entre t0 y t1."""
    u = np.clip((t - t0) / max(t1 - t0, 1e-9), 0, 1)
    return u * u * (3 - 2 * u)


def construir_pose(cadera, tronco_deg=0.0, codo_i=170.0, codo_d=170.0, flex_rod=0.0):
    """Pose (33, 4) normalizada (x, y, z, visibilidad) de un muñeco frontal."""
    cx, cy = cadera
    th = np.radians(tronco_deg)
    v_tronco = np.array([np.sin(th), -np.cos(th)])
    cad_i, cad_d = np.array([cx - ANCHO_C / 2, cy]), np.array([cx + ANCHO_C / 2, cy])
    hom_c = np.array([cx, cy]) + TRONCO * v_tronco
    hom_i, hom_d = hom_c + [-ANCHO_H / 2, 0], hom_c + [ANCHO_H / 2, 0]
    nariz = hom_c + 38 * v_tronco
    fr = np.radians(flex_rod)

    def pierna(cad):
        rod = cad + [MUSLO * np.sin(fr), MUSLO * np.cos(fr)]
        return rod, rod + [0, PANTORRILLA]

    rod_i, tob_i = pierna(cad_i)
    rod_d, tob_d = pierna(cad_d)

    def brazo(hom, codo_deg, lado):
        cod = hom + [0, BRAZO]
        a = np.radians(codo_deg)
        return cod, cod + ANTEBRAZO * np.array([lado * np.sin(np.pi - a) * 0.6, -np.cos(a)])

    cod_i, mun_i = brazo(hom_i, codo_i, -1)
    cod_d, mun_d = brazo(hom_d, codo_d, +1)
    pts = np.zeros((33, 2))
    pts[0] = nariz
    for k in range(1, 11):
        pts[k] = nariz + [(k - 5) * 3, -4 + (k % 3) * 4]
    pts[11], pts[12], pts[13], pts[14], pts[15], pts[16] = hom_i, hom_d, cod_i, cod_d, mun_i, mun_d
    for k, base in zip((17, 19, 21), (mun_i,) * 3):
        pts[k] = base + [-3, 3]
    for k, base in zip((18, 20, 22), (mun_d,) * 3):
        pts[k] = base + [3, 3]
    pts[23], pts[24], pts[25], pts[26], pts[27], pts[28] = cad_i, cad_d, rod_i, rod_d, tob_i, tob_d
    pts[29], pts[31] = tob_i + [0, 4], tob_i + [10, 8]
    pts[30], pts[32] = tob_d + [0, 4], tob_d + [10, 8]
    pose = np.zeros((33, 4))
    pose[:, 0], pose[:, 1], pose[:, 3] = pts[:, 0] / W0, pts[:, 1] / H0, 0.99
    return pose


def trayectoria(clase: str, t: float, v: dict) -> np.ndarray:
    """Pose en el instante ``t`` con variación por video ``v`` (fase, periodo, posición)."""
    t0, per, x0 = v["t0"], v["periodo"], v["x0"]
    if clase == "abdominales":
        activo = t0 <= t < t0 + 4 * per
        ang = 10 + (25 - 25 * np.cos(2 * np.pi * (t - t0) / per)) if activo else 10
        return construir_pose((x0, 300), tronco_deg=ang)
    if clase == "pesas":
        activo = t0 <= t < t0 + 4 * per
        f = 0.5 - 0.5 * np.cos(2 * np.pi * (t - t0) / per) if activo else 0.0
        return construir_pose((x0, 290), codo_i=165 - 120 * f, codo_d=165 - 8 * f)
    if clase == "salto":
        a = v["amp"]
        dy = (40 * suave(t, t0, t0 + .4) - a * suave(t, t0 + .4, t0 + .8)
              + a * suave(t, t0 + .8, t0 + 1.2) - 40 * suave(t, t0 + 1.2, t0 + 1.6))
        flex = (60 * suave(t, t0, t0 + .4) - 60 * suave(t, t0 + .4, t0 + .8)
                + 50 * suave(t, t0 + .9, t0 + 1.2) - 50 * suave(t, t0 + 1.2, t0 + 1.6))
        return construir_pose((x0, 290 + dy), flex_rod=flex)
    f = suave(t, t0, t0 + 1.0) - suave(t, t0 + 2.0, t0 + 2.6)      # elasticidad
    return construir_pose((x0, 280), tronco_deg=v["amp_tronco"] * f)


def dibujar(pose: np.ndarray, lado_w: int, lado_h: int) -> np.ndarray:
    """Dibuja el muñeco en un cuadro de ``lado_w x lado_h``."""
    img = np.full((lado_h, lado_w, 3), (70, 60, 50), np.uint8)
    pts = np.stack([pose[:, 0] * lado_w, pose[:, 1] * lado_h], axis=1).astype(int)
    for a, b in CONEXIONES:
        cv2.line(img, tuple(pts[a]), tuple(pts[b]), (230, 230, 230), 3)
    cv2.circle(img, (pts[0][0], pts[0][1]), 12, (200, 200, 240), -1)
    return img


def generar_video(ruta: Path, clase: str, rng: np.random.Generator,
                  lado: tuple = (320, 240), n_frames: int = N_FRAMES) -> None:
    """Escribe un AVI (MJPG) del muñeco y su ``.poses.npz`` auxiliar."""
    v = {"t0": rng.uniform(0.8, 1.2), "periodo": rng.uniform(0.7, 0.85),
         "x0": rng.uniform(290, 350), "amp": rng.uniform(100, 130),
         "amp_tronco": rng.uniform(70, 85)}
    escritor = cv2.VideoWriter(str(ruta), cv2.VideoWriter_fourcc(*"MJPG"), FPS, lado)
    if not escritor.isOpened():
        raise RuntimeError("OpenCV no pudo crear el video (codec MJPG no disponible)")
    poses = []
    for i in range(n_frames):
        p = trayectoria(clase, (i % N_FRAMES) / FPS, v)
        poses.append(p)
        escritor.write(dibujar(p, *lado))
    escritor.release()
    np.savez_compressed(ruta.with_suffix(".poses.npz"), poses=np.stack(poses))


def generar_dataset(raiz: Path, por_clase: int, seed: int) -> None:
    """Crea ``train/validation/test`` con videos sintéticos balanceados."""
    rng = np.random.default_rng(seed)
    reparto = {"train": por_clase, "validation": max(2, por_clase // 3),
               "test": max(2, por_clase // 3)}
    for split, n in reparto.items():
        for clase in CLASES:
            carpeta = raiz / split / clase
            carpeta.mkdir(parents=True, exist_ok=True)
            for i in range(n):
                generar_video(carpeta / f"{clase}_{i:03d}.avi", clase, rng)
    logger.info("Dataset sintético creado en %s: %s", raiz, reparto)


# --------------------------------------------------------------- comprobaciones
def comprobar(cond: bool, mensaje: str) -> None:
    """Falla la prueba si ``cond`` es falso."""
    if not cond:
        raise AssertionError(mensaje)
    logger.info("OK  %s", mensaje)


def prueba_detector(repo, cfg, nombre: str, fuente: str, esperar_tabular: bool) -> None:
    """Ejecuta el detector en tiempo real con un video como fuente de cámara."""
    from modulos.deteccion_tiempo_real import DetectorTiempoReal
    modelo, clases, params = repo.cargar(nombre)
    det = DetectorTiempoReal(modelo, clases, indice_camara=fuente, params=params)
    comprobar(det.usa_tabular == esperar_tabular,
              f"detector[{nombre}]: usa_tabular={det.usa_tabular}")
    comprobar(det.seq_length == int(cfg["seq_length"]) and det.img_size == int(cfg["img_size"]),
              f"detector[{nombre}]: seq_length/img_size leídos de input_shape")
    det.iniciar()
    vista, limite = None, time.time() + 120
    while time.time() < limite and det.activo and vista is None:
        est = det.obtener_estado()
        if est["clase"]:
            vista = est
        time.sleep(0.2)
    est = det.obtener_estado()
    det.detener()
    vista = vista or (est if est["clase"] else None)
    fin_normal = est["error"] in (None, "Se perdió la señal de la cámara.")  # fin del video
    comprobar(fin_normal, f"detector[{nombre}]: sin errores ({est['error']})")
    comprobar(vista is not None and vista["clase"] in clases,
              f"detector[{nombre}]: predicción en vivo -> {vista['clase'] if vista else None}")


def main() -> int:
    """Ejecuta la prueba completa. Devuelve 0 si todo terminó bien."""
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--epocas", type=int, default=2)
    parser.add_argument("--videos", type=int, default=6, help="videos de train por clase")
    parser.add_argument("--img-size", type=int, default=96)
    parser.add_argument("--seq-length", type=int, default=8)
    parser.add_argument("--imagenet", action="store_true",
                        help="usar pesos ImageNet (requiere descarga)")
    parser.add_argument("--omitir-vivo", action="store_true",
                        help="no probar la detección en tiempo real")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    from modulos.entrenamiento import Entrenador
    from modulos.evaluacion import Evaluador
    from modulos.modelo_clasico import ModeloClasico
    from modulos.persistencia import RepositorioModelos
    from modulos.preparar_dataset import N_FEATURES, features_desde_poses
    from modulos.preprocesamiento import Preprocesador

    with tempfile.TemporaryDirectory(prefix="prueba_actividades_") as tmp:
        tmp = Path(tmp)
        generar_dataset(tmp / "dataset", args.videos, 42)
        cfg = Configuracion(ruta=tmp / "config_prueba.json")
        cfg.actualizar({
            "ruta_dataset": str(tmp / "dataset"), "ruta_frames": str(tmp / "frames"),
            "clases": CLASES, "epocas": args.epocas, "batch_size": 4,
            "img_size": args.img_size, "seq_length": args.seq_length,
            "n_capas_pqc": 1, "pesos_imagenet": args.imagenet,
            "lstm_unidades": 32, "usar_features_tabulares": True})
        fijar_semillas(cfg["seed"])
        repo = RepositorioModelos(tmp / "modelos")
        n_seq = int(cfg["seq_length"])

        # 1) Procesamiento con la herramienta integrada ------------------------------
        prep = Preprocesador(cfg)
        conteo = prep.procesar_dataset()
        logger.info("Frames por split: %s", conteo)
        ejemplo = tmp / "frames" / "train" / "salto" / "salto_000"
        archivos = sorted(p.name for p in ejemplo.iterdir())
        comprobar(len(list(ejemplo.glob("*.jpg"))) == n_seq, f"{n_seq} JPG en {ejemplo.name}")
        for nombre in ("poses.npz", "meta.json", "debug.png"):
            comprobar(nombre in archivos, f"{nombre} en frames/train/salto/salto_000/")
        metas = [json.loads(p.read_text(encoding="utf-8"))
                 for p in (tmp / "frames").glob("*/*/*/meta.json")]
        logger.info("deteccion_ok: %d/%d videos", sum(m["deteccion_ok"] for m in metas), len(metas))

        # 2) features_desde_poses: solo poses, sin clase -----------------------------
        meta = json.loads((ejemplo / "meta.json").read_text(encoding="utf-8"))
        z = np.load(ejemplo / "poses.npz")
        aspecto = float(z["ancho"]) / float(z["alto"])
        vec = features_desde_poses(z["poses"][meta["indices_clave"]], aspecto)
        comprobar(vec.shape == (N_FEATURES,) and vec.dtype.kind == "f",
                  f"features_desde_poses -> vector de {N_FEATURES} floats")
        rutas, rutas_poses, y = prep.listar_muestras("train")
        comprobar(rutas.shape == (len(y), n_seq) and rutas_poses.shape == (len(y),),
                  "listar_muestras -> (rutas_img, rutas_poses, etiquetas)")
        z0 = np.load(rutas_poses[0])
        m0 = json.loads((Path(rutas_poses[0]).parent / "meta.json").read_text())
        esperado = features_desde_poses(z0["poses"][m0["indices_clave"]],
                                        float(z0["ancho"]) / float(z0["alto"]))
        comprobar(np.allclose(prep.features_de_video(rutas_poses[0]), esperado, equal_nan=True),
                  "features_de_video == features_desde_poses(poses[indices_clave])")

        # 3) Dataset multimodal ---------------------------------------------------------
        ds = prep.crear_dataset("train", entrenamiento=True)
        (img, tab), yy = next(iter(ds))
        s = args.img_size
        comprobar(tuple(img.shape) == (4, n_seq, s, s, 3) and tuple(tab.shape) == (4, N_FEATURES)
                  and tuple(yy.shape) == (4,),
                  f"dataset train -> img{tuple(img.shape)} tab{tuple(tab.shape)} y{tuple(yy.shape)}")
        comprobar(bool(np.isfinite(tab.numpy()).all()), "features tabulares finitas (sin NaN)")
        comprobar(len(cfg["columnas_tabulares"]) == N_FEATURES
                  and len(cfg["medias_imputacion"]) == N_FEATURES
                  and len(cfg["medias_normalizacion"]) == N_FEATURES
                  and len(cfg["stds_normalizacion"]) == N_FEATURES,
                  "estadísticas de train guardadas en cfg (columnas, medias, stds)")
        (_, tab_val), _ = next(iter(prep.crear_dataset("validation")))
        comprobar(tuple(tab_val.shape[1:]) == (N_FEATURES,), "dataset validation multimodal")
        x_sin, _ = next(iter(Preprocesador(cfg).crear_dataset(
            "train", entrenamiento=False, tabular=False)))
        comprobar(tuple(x_sin.shape) == (4, n_seq, s, s, 3), "tabular=False -> solo imágenes")

        # 4) Entrenar y evaluar ambos modelos (rama tabular) -------------------------
        Entrenador(cfg, repo).entrenar("ambos")
        for nombre in ("clasico", "hibrido"):
            p = json.loads((tmp / "modelos" / f"config_{nombre}.json").read_text())
            comprobar(p["usar_features_tabulares"] and p["n_features_tabulares"] == N_FEATURES
                      and len(p["columnas_tabulares"]) == N_FEATURES
                      and len(p["medias_normalizacion"]) == N_FEATURES,
                      f"config_{nombre}.json con los campos tabulares")
        evaluador = Evaluador(cfg, repo)
        res = {n: evaluador.evaluar(n) for n in ("clasico", "hibrido")}
        filas = Evaluador.comparar(res["clasico"], res["hibrido"])
        Evaluador.exportar_csv(filas, tmp / "comparacion.csv")
        print("\n{:<18}{:>14}{:>14}{:>14}".format("Métrica", "Clásico", "Híbrido", "Diferencia"))
        for etiqueta, c, h, d in filas:
            print(f"{etiqueta:<18}{c:>14.4f}{h:>14.4f}{d:>+14.4f}")

        # 5) Modelo antiguo: JSON sin usar_features_tabulares ---------------------------
        cfg_old = Configuracion(ruta=tmp / "config_vieja.json")
        cfg_old.actualizar({**cfg.as_dict(), "usar_features_tabulares": False})
        viejo = ModeloClasico(cfg_old)
        viejo.construir()
        viejo.compilar()
        repo_old = RepositorioModelos(tmp / "modelos_viejos")
        repo_old.guardar("clasico", viejo, cfg_old, CLASES)
        ruta_json = tmp / "modelos_viejos" / "config_clasico.json"
        datos = json.loads(ruta_json.read_text())
        for k in ("usar_features_tabulares", "n_features_tabulares", "columnas_tabulares",
                  "medias_imputacion", "medias_normalizacion", "stds_normalizacion"):
            datos.pop(k, None)                 # exactamente como lo dejaba la versión anterior
        ruta_json.write_text(json.dumps(datos, indent=2))
        modelo_v, _, params_v = repo_old.cargar("clasico")
        probs = modelo_v.predict(np.random.rand(2, n_seq, s, s, 3).astype("float32") * 255,
                                 verbose=0)
        comprobar(len(modelo_v.inputs) == 1 and probs.shape == (2, len(CLASES))
                  and not params_v["usar_features_tabulares"],
                  "modelo antiguo (sin usar_features_tabulares) carga y predice")
        res_v = Evaluador(cfg, repo_old).evaluar("clasico")     # cfg dice True; manda el modelo
        comprobar(res_v["n_videos"] > 0, "modelo antiguo evaluable sobre test (solo imágenes)")

        # 6) usar_features_tabulares=False: comportamiento de antes ------------------------
        cfg_img = Configuracion(ruta=tmp / "config_img.json")
        cfg_img.actualizar({**cfg.as_dict(), "usar_features_tabulares": False})
        repo_img = RepositorioModelos(tmp / "modelos_img")
        Entrenador(cfg_img, repo_img).entrenar("ambos")
        res_img = {n: Evaluador(cfg_img, repo_img).evaluar(n) for n in ("clasico", "hibrido")}
        comprobar(all(not repo_img.cargar_parametros(n)["usar_features_tabulares"]
                      for n in ("clasico", "hibrido"))
                  and all(r["n_videos"] > 0 for r in res_img.values()),
                  "usar_features_tabulares=False: entrena, guarda y evalúa solo con imágenes")

        # 7) Detección en tiempo real (video como fuente) ----------------------------------
        if not args.omitir_vivo:
            largo = tmp / "fuente_larga.avi"
            generar_video(largo, "abdominales", np.random.default_rng(7), n_frames=N_FRAMES * 6)
            prueba_detector(repo, cfg, "clasico", str(largo), True)
            prueba_detector(repo, cfg, "hibrido", str(largo), True)
            prueba_detector(repo_old, cfg_old, "clasico", str(largo), False)
        logger.info("Prueba completada correctamente")
    return 0


if __name__ == "__main__":
    sys.exit(main())
