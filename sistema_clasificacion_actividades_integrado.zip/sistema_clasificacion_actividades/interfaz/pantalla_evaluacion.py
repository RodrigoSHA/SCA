"""Pantalla 3: evaluación comparativa de los dos modelos."""
import logging
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from modulos.configuracion import RESULTADOS_DIR
from modulos.evaluacion import Evaluador

logger = logging.getLogger(__name__)


class PantallaEvaluacion(ttk.Frame):
    """Tabla comparativa, barras dobles y matriz de confusión."""

    def __init__(self, master, app) -> None:
        super().__init__(master)
        self.app = app
        self.resultados = {"clasico": None, "hibrido": None}
        self.var_matriz = tk.StringVar(value="clasico")
        self.cola: queue.Queue = queue.Queue()
        self.evaluando = False
        self._construir()
        self.after(150, self._sondear)

    def _construir(self) -> None:
        sup = ttk.Frame(self)
        sup.pack(fill="x", padx=15, pady=(15, 5))
        ttk.Label(sup, text="Evaluación comparativa", font=("Segoe UI", 18, "bold")).pack(side="left")
        self.btn_eval = ttk.Button(sup, text="Evaluar modelos", command=self.evaluar)
        self.btn_eval.pack(side="right")

        arriba = ttk.Frame(self)
        arriba.pack(fill="both", expand=True, padx=15, pady=5)
        cols = ("metrica", "clasico", "hibrido", "dif")
        self.tabla = ttk.Treeview(arriba, columns=cols, show="headings", height=9)
        for c, t, w in zip(cols, ("Métrica", "Modelo Clásico", "Modelo Híbrido", "Diferencia"),
                           (140, 120, 120, 100)):
            self.tabla.heading(c, text=t)
            self.tabla.column(c, width=w, anchor="center")
        self.tabla.pack(side="left", fill="y")
        self.fig_barras = Figure(figsize=(5.5, 3.2), dpi=100)
        self.cv_barras = FigureCanvasTkAgg(self.fig_barras, master=arriba)
        self.cv_barras.get_tk_widget().pack(side="left", fill="both", expand=True, padx=(10, 0))

        abajo = ttk.Frame(self)
        abajo.pack(fill="both", expand=True, padx=15, pady=5)
        selector = ttk.LabelFrame(abajo, text="Matriz de confusión")
        selector.pack(side="left", fill="y")
        for texto, valor in (("Modelo clásico", "clasico"), ("Modelo híbrido", "hibrido")):
            ttk.Radiobutton(selector, text=texto, value=valor, variable=self.var_matriz,
                            command=self._dibujar_matriz).pack(anchor="w", padx=12, pady=8)
        self.fig_matriz = Figure(figsize=(5, 3.2), dpi=100)
        self.cv_matriz = FigureCanvasTkAgg(self.fig_matriz, master=abajo)
        self.cv_matriz.get_tk_widget().pack(side="left", fill="both", expand=True, padx=(10, 0))

        bot = ttk.Frame(self)
        bot.pack(pady=10)
        ttk.Button(bot, text="Exportar CSV", command=self.exportar_csv).pack(side="left", padx=8)
        ttk.Button(bot, text="Exportar gráfica PNG", command=self.exportar_png).pack(side="left", padx=8)
        ttk.Button(bot, text="Volver", command=lambda: self.app.mostrar("inicio")).pack(side="left", padx=8)

    # ---- datos -----------------------------------------------------------------------
    def al_mostrar(self) -> None:
        """Carga los resultados guardados al entrar en la pantalla."""
        for nombre in self.resultados:
            if self.resultados[nombre] is None:
                self.resultados[nombre] = Evaluador.cargar_resultados(nombre)
        self._refrescar()

    @staticmethod
    def _fmt(v, signo=False):
        if v is None:
            return "--"
        return f"{v:+.4f}" if signo else f"{v:.4f}"

    def _refrescar(self) -> None:
        self.tabla.delete(*self.tabla.get_children())
        filas = Evaluador.comparar(self.resultados["clasico"], self.resultados["hibrido"])
        for etiqueta, c, h, d in filas:
            self.tabla.insert("", "end", values=(etiqueta, self._fmt(c), self._fmt(h),
                                                 self._fmt(d, True)))
        Evaluador.graficar_barras(self.fig_barras, self.resultados["clasico"],
                                  self.resultados["hibrido"])
        self.cv_barras.draw_idle()
        self._dibujar_matriz()

    def _dibujar_matriz(self) -> None:
        nombre = self.var_matriz.get()
        Evaluador.graficar_matriz(self.fig_matriz, self.resultados[nombre],
                                  f"Matriz de confusión - {nombre}")
        self.cv_matriz.draw_idle()

    # ---- evaluación en hilo ------------------------------------------------------------------
    def evaluar(self) -> None:
        """Evalúa los modelos guardados sobre el conjunto de prueba."""
        if self.evaluando:
            return
        faltan = [n for n in ("clasico", "hibrido")
                  if not self.app.repositorio.existe(n)]
        if len(faltan) == 2:
            messagebox.showwarning("Sin modelos", "Aún no hay modelos entrenados. "
                                   "Entrene al menos uno en la pantalla de Entrenamiento.")
            return
        self.evaluando = True
        self.btn_eval.configure(state="disabled")
        self.app.estado("Evaluando modelos sobre el conjunto de prueba...")
        threading.Thread(target=self._trabajo, daemon=True).start()

    def _trabajo(self) -> None:
        try:
            ev = Evaluador(self.app.cfg, self.app.repositorio)
            for nombre in ("clasico", "hibrido"):
                if self.app.repositorio.existe(nombre):
                    self.cola.put(("res", (nombre, ev.evaluar(nombre))))
            self.cola.put(("fin", None))
        except Exception as exc:  # noqa: BLE001
            logger.exception("Fallo en la evaluación")
            self.cola.put(("error", str(exc)))

    def _sondear(self) -> None:
        try:
            while True:
                tipo, dato = self.cola.get_nowait()
                if tipo == "res":
                    self.resultados[dato[0]] = dato[1]
                    self._refrescar()
                elif tipo in ("fin", "error"):
                    self.evaluando = False
                    self.btn_eval.configure(state="normal")
                    self.app.estado("Evaluación finalizada" if tipo == "fin"
                                    else "Error en la evaluación")
                    if tipo == "error":
                        messagebox.showerror("Error de evaluación", dato)
        except queue.Empty:
            pass
        self.after(150, self._sondear)

    # ---- exportación -----------------------------------------------------------------------------
    def exportar_csv(self) -> None:
        """Exporta la tabla comparativa a CSV."""
        if not any(self.resultados.values()):
            messagebox.showinfo("Exportar", "No hay resultados para exportar.")
            return
        ruta = filedialog.asksaveasfilename(
            defaultextension=".csv", filetypes=[("CSV", "*.csv")],
            initialdir=str(RESULTADOS_DIR), initialfile="comparacion_modelos.csv")
        if not ruta:
            return
        try:
            filas = Evaluador.comparar(self.resultados["clasico"], self.resultados["hibrido"])
            Evaluador.exportar_csv(filas, Path(ruta))
            self.app.estado(f"CSV exportado: {ruta}")
        except OSError as exc:
            messagebox.showerror("Error al exportar", str(exc))

    def exportar_png(self) -> None:
        """Exporta la gráfica de barras y la matriz de confusión a PNG."""
        if not any(self.resultados.values()):
            messagebox.showinfo("Exportar", "No hay resultados para exportar.")
            return
        ruta = filedialog.asksaveasfilename(
            defaultextension=".png", filetypes=[("PNG", "*.png")],
            initialdir=str(RESULTADOS_DIR), initialfile="comparacion_metricas.png")
        if not ruta:
            return
        try:
            p = Path(ruta)
            self.fig_barras.savefig(p, dpi=150)
            self.fig_matriz.savefig(p.with_name(p.stem + "_matriz" + p.suffix), dpi=150)
            self.app.estado(f"Gráficas exportadas: {p.name} y {p.stem}_matriz{p.suffix}")
        except OSError as exc:
            messagebox.showerror("Error al exportar", str(exc))
