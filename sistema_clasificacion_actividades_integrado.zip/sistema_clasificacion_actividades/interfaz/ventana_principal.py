"""Ventana principal con menú, tarjetas de navegación y barra de estado."""
import logging
import os
import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from modulos.configuracion import BASE_DIR, RESULTADOS_DIR, Configuracion
from modulos.persistencia import RepositorioModelos

from interfaz.pantalla_configuracion import PantallaConfiguracion
from interfaz.pantalla_deteccion import PantallaDeteccion
from interfaz.pantalla_entrenamiento import PantallaEntrenamiento
from interfaz.pantalla_evaluacion import PantallaEvaluacion

logger = logging.getLogger(__name__)

TITULO = "Sistema de Clasificación de Actividades Físicas"


class VentanaPrincipal(tk.Tk):
    """Ventana raíz: gestiona la navegación entre pantallas.

    Args:
        cfg: Configuración compartida por toda la aplicación.

    Attributes:
        cfg: Configuración vigente.
        repositorio: Repositorio de modelos compartido.
        pantallas: Diccionario ``nombre -> frame``.
    """

    def __init__(self, cfg: Configuracion) -> None:
        super().__init__()
        self.cfg = cfg
        self.repositorio = RepositorioModelos()
        self.title(TITULO)
        self.geometry("1200x800")
        self.minsize(1000, 700)
        ttk.Style(self).theme_use("clam")
        self._var_estado = tk.StringVar(value="Listo")
        self._crear_menu()

        self.contenedor = ttk.Frame(self)
        self.contenedor.pack(fill="both", expand=True)
        barra = ttk.Label(self, textvariable=self._var_estado, relief="sunken",
                          anchor="w", padding=(8, 3))
        barra.pack(side="bottom", fill="x")

        self.pantallas = {
            "inicio": self._crear_inicio(self.contenedor),
            "configuracion": PantallaConfiguracion(self.contenedor, self),
            "entrenamiento": PantallaEntrenamiento(self.contenedor, self),
            "evaluacion": PantallaEvaluacion(self.contenedor, self),
            "deteccion": PantallaDeteccion(self.contenedor, self),
        }
        for frame in self.pantallas.values():
            frame.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._actual = None
        self.mostrar("inicio")

    # ---- navegación -------------------------------------------------------------
    def mostrar(self, nombre: str) -> None:
        """Muestra la pantalla ``nombre`` y avisa a la anterior que se oculta."""
        if self._actual and hasattr(self.pantallas[self._actual], "al_ocultar"):
            self.pantallas[self._actual].al_ocultar()
        self._actual = nombre
        frame = self.pantallas[nombre]
        frame.tkraise()
        if hasattr(frame, "al_mostrar"):
            frame.al_mostrar()
        self.estado({"inicio": "Listo", "configuracion": "Configuración de parámetros",
                     "entrenamiento": "Entrenamiento y monitoreo",
                     "evaluacion": "Evaluación comparativa",
                     "deteccion": "Detección en tiempo real"}[nombre])

    def estado(self, mensaje: str) -> None:
        """Escribe un mensaje en la barra de estado."""
        self._var_estado.set(mensaje)

    # ---- pantalla de inicio ----------------------------------------------------------
    def _crear_inicio(self, padre) -> ttk.Frame:
        frame = ttk.Frame(padre)
        ttk.Label(frame, text=TITULO, font=("Segoe UI", 24, "bold")).pack(pady=(50, 6))
        ttk.Label(frame, text="Modelo clásico (MobileNetV3Small + LSTM) vs. modelo "
                  "híbrido cuántico-clásico (MobileNetV3Small + PQC)",
                  font=("Segoe UI", 11)).pack(pady=(0, 40))
        rejilla = ttk.Frame(frame)
        rejilla.pack()
        tarjetas = [
            ("⚙\nConfiguración", "Parámetros del modelo y del dataset", "configuracion"),
            ("🧠\nEntrenamiento", "Entrenar y monitorear los modelos", "entrenamiento"),
            ("📊\nEvaluación Comparativa", "Métricas, gráficas y matriz de confusión", "evaluacion"),
            ("🎥\nDetección en Tiempo Real", "Clasificar actividades con la cámara", "deteccion"),
        ]
        for i, (titulo, ayuda, destino) in enumerate(tarjetas):
            celda = ttk.Frame(rejilla)
            celda.grid(row=i // 2, column=i % 2, padx=20, pady=18)
            tk.Button(celda, text=titulo, width=26, height=5, font=("Segoe UI", 14, "bold"),
                      relief="raised", bd=3, cursor="hand2",
                      command=lambda d=destino: self.mostrar(d)).pack()
            ttk.Label(celda, text=ayuda).pack(pady=(4, 0))
        return frame

    # ---- menú --------------------------------------------------------------------------
    def _crear_menu(self) -> None:
        barra = tk.Menu(self)
        m = tk.Menu(barra, tearoff=0)
        m.add_command(label="Nuevo", command=self._nuevo)
        m.add_command(label="Abrir configuración...", command=self._abrir_config)
        m.add_command(label="Guardar", command=self._guardar_config)
        m.add_separator()
        m.add_command(label="Salir", command=self.cerrar)
        barra.add_cascade(label="Archivo", menu=m)

        m = tk.Menu(barra, tearoff=0)
        m.add_command(label="Parámetros", command=lambda: self.mostrar("configuracion"))
        m.add_command(label="Modelo", command=lambda: self.mostrar("configuracion"))
        barra.add_cascade(label="Configuración", menu=m)

        m = tk.Menu(barra, tearoff=0)
        m.add_command(label="Entrenar clásico", command=lambda: self._ir_entrenar("clasico"))
        m.add_command(label="Entrenar híbrido", command=lambda: self._ir_entrenar("hibrido"))
        barra.add_cascade(label="Modelos", menu=m)

        m = tk.Menu(barra, tearoff=0)
        m.add_command(label="Comparar modelos", command=lambda: self.mostrar("evaluacion"))
        m.add_command(label="Ver reportes", command=self._ver_reportes)
        barra.add_cascade(label="Evaluación", menu=m)

        m = tk.Menu(barra, tearoff=0)
        m.add_command(label="Acerca de", command=self._acerca_de)
        m.add_command(label="Documentación", command=self._documentacion)
        barra.add_cascade(label="Ayuda", menu=m)
        self.config(menu=barra)

    def _ir_entrenar(self, modelo: str) -> None:
        self.mostrar("entrenamiento")
        self.pantallas["entrenamiento"].var_modelo.set(modelo)

    def _nuevo(self) -> None:
        if messagebox.askyesno("Nuevo", "¿Restablecer la configuración a los valores por defecto?"):
            self.cfg.restablecer()
            self.pantallas["configuracion"].cargar_en_formulario()
            self.estado("Configuración restablecida")

    def _abrir_config(self) -> None:
        ruta = filedialog.askopenfilename(
            title="Abrir configuración", filetypes=[("JSON", "*.json")],
            initialdir=str(BASE_DIR))
        if not ruta:
            return
        try:
            self.cfg.cargar(Path(ruta))
        except (OSError, ValueError) as exc:
            messagebox.showerror("Configuración inválida", str(exc))
            return
        self.pantallas["configuracion"].cargar_en_formulario()
        self.estado(f"Configuración cargada: {Path(ruta).name}")

    def _guardar_config(self) -> None:
        try:
            self.cfg.guardar()
            self.estado("Configuración guardada")
        except OSError as exc:
            messagebox.showerror("Error al guardar", str(exc))

    def _ver_reportes(self) -> None:
        RESULTADOS_DIR.mkdir(parents=True, exist_ok=True)
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(RESULTADOS_DIR))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(RESULTADOS_DIR)])
            else:
                subprocess.Popen(["xdg-open", str(RESULTADOS_DIR)])
        except Exception as exc:  # noqa: BLE001
            messagebox.showinfo("Reportes", f"Los reportes están en:\n{RESULTADOS_DIR}\n\n({exc})")

    def _acerca_de(self) -> None:
        messagebox.showinfo(
            "Acerca de",
            f"{TITULO}\n\nComparación entre un modelo clásico (MobileNetV3Small + LSTM) "
            "y un modelo híbrido cuántico-clásico (MobileNetV3Small + PQC de 4 qubits).")

    def _documentacion(self) -> None:
        ruta = BASE_DIR / "README.md"
        ventana = tk.Toplevel(self)
        ventana.title("Documentación")
        ventana.geometry("800x600")
        texto = tk.Text(ventana, wrap="word", padx=10, pady=10)
        scroll = ttk.Scrollbar(ventana, command=texto.yview)
        texto.configure(yscrollcommand=scroll.set)
        scroll.pack(side="right", fill="y")
        texto.pack(fill="both", expand=True)
        try:
            texto.insert("1.0", ruta.read_text(encoding="utf-8"))
        except OSError:
            texto.insert("1.0", "No se encontró README.md")
        texto.configure(state="disabled")

    # ---- cierre limpio ---------------------------------------------------------------------
    def cerrar(self) -> None:
        """Detiene hilos activos y cierra la aplicación."""
        entrenamiento = self.pantallas["entrenamiento"]
        if getattr(entrenamiento, "entrenando", False):
            if not messagebox.askyesno(
                    "Salir", "Hay un entrenamiento en curso. ¿Detenerlo y salir?"):
                return
        for frame in self.pantallas.values():
            if hasattr(frame, "detener_todo"):
                try:
                    frame.detener_todo()
                except Exception:  # noqa: BLE001
                    logger.exception("Error al detener una pantalla")
        self.destroy()
