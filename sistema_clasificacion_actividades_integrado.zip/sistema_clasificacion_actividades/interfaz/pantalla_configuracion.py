"""Pantalla 1: configuración de parámetros."""
import logging
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from modulos.configuracion import BASE_DIR, Configuracion

logger = logging.getLogger(__name__)


class PantallaConfiguracion(ttk.Frame):
    """Formulario de parámetros con validación.

    Args:
        master: Contenedor Tk.
        app: Ventana principal (provee ``cfg``, ``mostrar`` y ``estado``).
    """

    def __init__(self, master, app) -> None:
        super().__init__(master)
        self.app = app
        self.vars = {
            "modelo": tk.StringVar(), "n_qubits": tk.StringVar(),
            "seq_length": tk.StringVar(), "shots": tk.StringVar(),
            "learning_rate": tk.StringVar(), "epocas": tk.StringVar(),
            "batch_size": tk.StringVar(), "ruta_dataset": tk.StringVar(),
        }
        # Casilla aparte: el resto de campos son texto (StringVar).
        self.var_tabular = tk.BooleanVar(value=True)
        self.errores = {}
        self._construir()
        self.cargar_en_formulario()

    def _construir(self) -> None:
        ttk.Label(self, text="Configuración", font=("Segoe UI", 20, "bold")).pack(pady=(20, 10))
        form = ttk.Frame(self)
        form.pack(pady=10)
        fila = 0

        def etiqueta(texto):
            ttk.Label(form, text=texto).grid(row=fila, column=0, sticky="e", padx=8, pady=7)

        def error(clave):
            lbl = ttk.Label(form, text="", foreground="#c0392b")
            lbl.grid(row=fila, column=3, sticky="w", padx=8)
            self.errores[clave] = lbl

        etiqueta("Modelo:")
        radios = ttk.Frame(form)
        radios.grid(row=fila, column=1, sticky="w")
        for texto, valor in (("Clásico", "clasico"), ("Híbrido", "hibrido")):
            ttk.Radiobutton(radios, text=texto, value=valor, variable=self.vars["modelo"],
                            command=self._alternar_modelo).pack(side="left", padx=(0, 14))
        error("modelo")
        fila += 1

        etiqueta("Número de qubits:")
        self.sp_qubits = ttk.Spinbox(form, from_=2, to=8, width=12,
                                     textvariable=self.vars["n_qubits"])
        self.sp_qubits.grid(row=fila, column=1, sticky="w")
        ttk.Label(form, text="(solo modelo híbrido)").grid(row=fila, column=2, sticky="w")
        error("n_qubits")
        fila += 1

        etiqueta("Seq_length:")
        ttk.Spinbox(form, from_=2, to=64, width=12,
                    textvariable=self.vars["seq_length"]).grid(row=fila, column=1, sticky="w")
        error("seq_length")
        fila += 1

        etiqueta("Shots:")
        self.cb_shots = ttk.Combobox(form, values=("1024", "2048"), width=10,
                                     textvariable=self.vars["shots"], state="readonly")
        self.cb_shots.grid(row=fila, column=1, sticky="w")
        ttk.Label(form, text="(solo modelo híbrido)").grid(row=fila, column=2, sticky="w")
        error("shots")
        fila += 1

        etiqueta("Learning rate:")
        ttk.Entry(form, width=14, textvariable=self.vars["learning_rate"]).grid(
            row=fila, column=1, sticky="w")
        error("learning_rate")
        fila += 1

        etiqueta("Épocas:")
        ttk.Spinbox(form, from_=1, to=1000, width=12,
                    textvariable=self.vars["epocas"]).grid(row=fila, column=1, sticky="w")
        error("epocas")
        fila += 1

        etiqueta("Batch size:")
        ttk.Spinbox(form, from_=1, to=512, width=12,
                    textvariable=self.vars["batch_size"]).grid(row=fila, column=1, sticky="w")
        error("batch_size")
        fila += 1

        etiqueta("Ruta del dataset:")
        ruta = ttk.Frame(form)
        ruta.grid(row=fila, column=1, columnspan=2, sticky="w")
        ttk.Entry(ruta, width=48, textvariable=self.vars["ruta_dataset"]).pack(side="left")
        ttk.Button(ruta, text="Examinar...", command=self._examinar).pack(side="left", padx=6)
        error("ruta_dataset")
        fila += 1

        etiqueta("Rama tabular:")
        ttk.Checkbutton(form, text="Usar features tabulares (CSV)",
                        variable=self.var_tabular).grid(row=fila, column=1, columnspan=2,
                                                        sticky="w")
        error("usar_features_tabulares")

        botones = ttk.Frame(self)
        botones.pack(pady=25)
        ttk.Button(botones, text="Guardar configuración", command=self.guardar).pack(side="left", padx=8)
        ttk.Button(botones, text="Restablecer", command=self.restablecer).pack(side="left", padx=8)
        ttk.Button(botones, text="Volver", command=lambda: self.app.mostrar("inicio")).pack(side="left", padx=8)

    # ---- lógica -----------------------------------------------------------------------
    def _alternar_modelo(self) -> None:
        estado = "normal" if self.vars["modelo"].get() == "hibrido" else "disabled"
        self.sp_qubits.configure(state=estado)
        self.cb_shots.configure(state="readonly" if estado == "normal" else "disabled")

    def cargar_en_formulario(self) -> None:
        """Vuelca ``cfg`` en los campos del formulario."""
        cfg = self.app.cfg
        for clave, var in self.vars.items():
            var.set(str(cfg[clave]))
        self.var_tabular.set(bool(cfg.get("usar_features_tabulares", True)))
        if self.vars["shots"].get() not in ("1024", "2048"):
            self.cb_shots.configure(values=("1024", "2048", self.vars["shots"].get()))
        for lbl in self.errores.values():
            lbl.configure(text="")
        self._alternar_modelo()

    def _examinar(self) -> None:
        carpeta = filedialog.askdirectory(title="Seleccione la carpeta del dataset",
                                          initialdir=str(BASE_DIR / "datos"))
        if carpeta:
            self.vars["ruta_dataset"].set(carpeta)

    def _leer(self) -> dict:
        return {k: v.get().strip() for k, v in self.vars.items()}

    def guardar(self) -> bool:
        """Valida y guarda. Devuelve True si se guardó."""
        datos = self._leer()
        datos["usar_features_tabulares"] = bool(self.var_tabular.get())
        candidato = self.app.cfg.as_dict()
        candidato.update(datos)
        errores = Configuracion.validar(candidato)
        for clave, lbl in self.errores.items():
            lbl.configure(text=errores.get(clave, ""))
        if errores:
            messagebox.showerror("Datos inválidos",
                                 "Corrija los campos marcados:\n\n" +
                                 "\n".join(f"• {k}: {v}" for k, v in errores.items()))
            return False
        tipos = {"n_qubits": int, "seq_length": int, "shots": int, "epocas": int,
                 "batch_size": int, "learning_rate": float}
        for clave, tipo in tipos.items():
            datos[clave] = tipo(datos[clave])
        self.app.cfg.actualizar(datos)
        try:
            self.app.cfg.guardar()
        except OSError as exc:
            messagebox.showerror("Error al guardar", str(exc))
            return False
        self.app.estado("Configuración guardada")
        messagebox.showinfo("Configuración", "Configuración guardada correctamente.")
        return True

    def restablecer(self) -> None:
        """Restablece los valores por defecto en el formulario y en ``cfg``."""
        self.app.cfg.restablecer()
        self.cargar_en_formulario()
        self.app.estado("Valores por defecto restablecidos (use Guardar para conservarlos)")
