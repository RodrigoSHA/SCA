"""Pantalla 4: detección de actividades en tiempo real con la cámara."""
import logging
import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from PIL import Image, ImageTk

logger = logging.getLogger(__name__)


class PantallaDeteccion(ttk.Frame):
    """Video en vivo con la actividad detectada y el historial reciente."""

    def __init__(self, master, app) -> None:
        super().__init__(master)
        self.app = app
        self.modelo_actual = "clasico"
        self.detector = None
        self.cargando = False
        self.cola: queue.Queue = queue.Queue()
        self._foto = None
        self._construir()
        self.after(100, self._sondear_carga)
        self.after(33, self._actualizar)

    def _construir(self) -> None:
        sup = ttk.Frame(self)
        sup.pack(fill="x", padx=15, pady=(15, 5))
        ttk.Label(sup, text="Detección en tiempo real", font=("Segoe UI", 18, "bold")).pack(side="left")
        self.lbl_modelo = ttk.Label(sup, text="Modelo: clásico")
        self.lbl_modelo.pack(side="right")

        centro = ttk.Frame(self)
        centro.pack(fill="both", expand=True, padx=15, pady=5)
        self.lbl_video = tk.Label(centro, bg="black", fg="white", width=80, height=28,
                                  text="Cámara detenida")
        self.lbl_video.pack(side="left", fill="both", expand=True)
        lateral = ttk.LabelFrame(centro, text="Últimas 5 predicciones")
        lateral.pack(side="left", fill="y", padx=(10, 0))
        self.lista = tk.Listbox(lateral, width=34, height=10, font=("Consolas", 10))
        self.lista.pack(padx=8, pady=8, fill="both", expand=True)

        bot = ttk.Frame(self)
        bot.pack(pady=10)
        self.btn_iniciar = ttk.Button(bot, text="Iniciar cámara", command=self.iniciar)
        self.btn_detener = ttk.Button(bot, text="Detener", command=self.detener, state="disabled")
        self.btn_cambiar = ttk.Button(bot, text="Cambiar modelo", command=self.cambiar_modelo)
        for b in (self.btn_iniciar, self.btn_detener, self.btn_cambiar):
            b.pack(side="left", padx=8)
        ttk.Button(bot, text="Volver", command=lambda: self.app.mostrar("inicio")).pack(
            side="left", padx=8)

    # ---- ciclo de vida -------------------------------------------------------------------
    def al_ocultar(self) -> None:
        """Apaga la cámara al salir de la pantalla."""
        self.detener()

    def detener_todo(self) -> None:
        """Usado al cerrar la aplicación."""
        self.detener()

    def iniciar(self) -> None:
        """Carga el modelo (en un hilo) y arranca la detección."""
        if self.cargando or (self.detector and self.detector.activo):
            return
        if not self.app.repositorio.existe(self.modelo_actual):
            messagebox.showwarning(
                "Modelo no disponible",
                f"No hay un modelo {self.modelo_actual} entrenado. "
                "Entrénelo primero o use 'Cambiar modelo'.")
            return
        self.cargando = True
        self.btn_iniciar.configure(state="disabled")
        self.lbl_video.configure(image="", text="Cargando modelo...")
        self.app.estado(f"Cargando modelo {self.modelo_actual}...")
        threading.Thread(target=self._cargar, args=(self.modelo_actual,), daemon=True).start()

    def _cargar(self, nombre: str) -> None:
        try:
            from modulos.deteccion_tiempo_real import DetectorTiempoReal
            modelo, clases, params = self.app.repositorio.cargar(nombre)
            # params trae las estadísticas de la rama tabular (si el modelo la usa).
            det = DetectorTiempoReal(modelo, clases, params=params)
            self.cola.put(("listo", det))
        except Exception as exc:  # noqa: BLE001
            logger.exception("No se pudo cargar el modelo")
            self.cola.put(("error", str(exc)))

    def _sondear_carga(self) -> None:
        try:
            while True:
                tipo, dato = self.cola.get_nowait()
                self.cargando = False
                if tipo == "listo":
                    self.detector = dato
                    self.detector.iniciar()
                    self.btn_detener.configure(state="normal")
                    self.app.estado("Detección en curso")
                else:
                    self.btn_iniciar.configure(state="normal")
                    self.lbl_video.configure(image="", text="Cámara detenida")
                    messagebox.showerror("Error al cargar el modelo", dato)
        except queue.Empty:
            pass
        self.after(100, self._sondear_carga)

    def detener(self) -> None:
        """Detiene la cámara y los hilos de captura/inferencia."""
        if self.detector:
            self.detector.detener()
            self.detector = None
        self._foto = None
        self.lbl_video.configure(image="", text="Cámara detenida")
        self.btn_detener.configure(state="disabled")
        if not self.cargando:
            self.btn_iniciar.configure(state="normal")

    def cambiar_modelo(self) -> None:
        """Alterna entre clásico e híbrido (reinicia si estaba activo)."""
        activo = bool(self.detector and self.detector.activo)
        self.detener()
        self.modelo_actual = "hibrido" if self.modelo_actual == "clasico" else "clasico"
        self.lbl_modelo.configure(text=f"Modelo: {self.modelo_actual}")
        self.app.estado(f"Modelo seleccionado: {self.modelo_actual}")
        if activo:
            self.iniciar()

    # ---- refresco de la imagen (hilo principal) -----------------------------------------------------
    def _actualizar(self) -> None:
        det = self.detector
        if det is not None:
            est = det.obtener_estado()
            if est["error"]:
                mensaje = est["error"]
                self.detener()
                messagebox.showerror("Detección", mensaje)
            elif est["frame"] is not None:
                self._foto = ImageTk.PhotoImage(Image.fromarray(est["frame"]))
                self.lbl_video.configure(image=self._foto, text="")
                self.lista.delete(0, "end")
                for hora, clase, conf in est["historial"]:
                    self.lista.insert("end", f"{hora}  {clase:<10} {conf * 100:5.1f}%")
        self.after(33, self._actualizar)
