"""Pantalla 2: entrenamiento y monitoreo.

El entrenamiento corre en un hilo; la GUI se comunica con él únicamente a
través de una ``queue.Queue`` que se vacía periódicamente con ``after``
(Tkinter no es thread-safe).
"""
import logging
import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from modulos.configuracion import Configuracion
from modulos.evaluacion import MonitorRecursos

logger = logging.getLogger(__name__)

COLORES = {"clasico": "#2f6fb0", "hibrido": "#e08a1e"}


class _ManejadorCola(logging.Handler):
    """Reenvía los registros de logging a la cola de la GUI."""

    def __init__(self, cola: queue.Queue) -> None:
        super().__init__(logging.INFO)
        self.cola = cola
        self.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s",
                                            "%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        # Los mensajes del Entrenador ya llegan por callback_log; se omiten
        # aquí para no duplicarlos en el panel.
        if record.name != "modulos.entrenamiento":
            self.cola.put(("log", self.format(record)))


class PantallaEntrenamiento(ttk.Frame):
    """Entrenamiento de los modelos con gráficas y recursos en vivo."""

    def __init__(self, master, app) -> None:
        super().__init__(master)
        self.app = app
        self.var_modelo = tk.StringVar(value="ambos")
        self.cola: queue.Queue = queue.Queue()
        self.entrenador = None
        self.hilo = None
        self.entrenando = False
        self.historia = {}
        self.completadas = 0
        self.monitor = MonitorRecursos()
        self._construir()
        self.after(100, self._sondear_cola)
        self.after(1000, self._actualizar_recursos)

    def _construir(self) -> None:
        sup = ttk.Frame(self)
        sup.pack(fill="x", padx=15, pady=(15, 5))
        ttk.Label(sup, text="Entrenamiento", font=("Segoe UI", 18, "bold")).pack(side="left")
        for texto, valor in (("Clásico", "clasico"), ("Híbrido", "hibrido"), ("Ambos", "ambos")):
            ttk.Radiobutton(sup, text=texto, value=valor, variable=self.var_modelo).pack(
                side="left", padx=(18, 0))

        prog = ttk.Frame(self)
        prog.pack(fill="x", padx=15, pady=5)
        self.barra = ttk.Progressbar(prog, mode="determinate")
        self.barra.pack(side="left", fill="x", expand=True)
        self.lbl_progreso = ttk.Label(prog, text="Época 0/0", width=22)
        self.lbl_progreso.pack(side="left", padx=8)

        medio = ttk.Frame(self)
        medio.pack(fill="both", expand=True, padx=15, pady=5)
        self.fig = Figure(figsize=(7, 3.6), dpi=100)
        self.ax_loss = self.fig.add_subplot(121)
        self.ax_acc = self.fig.add_subplot(122)
        self._formatear_ejes()
        self.canvas = FigureCanvasTkAgg(self.fig, master=medio)
        self.canvas.get_tk_widget().pack(side="left", fill="both", expand=True)

        lateral = ttk.LabelFrame(medio, text="Recursos")
        lateral.pack(side="left", fill="y", padx=(10, 0))
        self.lbl_cpu = ttk.Label(lateral, text="CPU: -- %", width=18)
        self.lbl_gpu = ttk.Label(lateral, text="GPU: -- %")
        self.lbl_ram = ttk.Label(lateral, text="RAM: -- MB")
        for lbl in (self.lbl_cpu, self.lbl_gpu, self.lbl_ram):
            lbl.pack(anchor="w", padx=10, pady=8)

        logf = ttk.LabelFrame(self, text="Registro de eventos")
        logf.pack(fill="both", expand=False, padx=15, pady=5)
        self.txt = tk.Text(logf, height=9, state="disabled", wrap="word")
        sc = ttk.Scrollbar(logf, command=self.txt.yview)
        self.txt.configure(yscrollcommand=sc.set)
        sc.pack(side="right", fill="y")
        self.txt.pack(fill="both", expand=True)

        bot = ttk.Frame(self)
        bot.pack(pady=10)
        self.btn_iniciar = ttk.Button(bot, text="Iniciar", command=self.iniciar)
        self.btn_pausar = ttk.Button(bot, text="Pausar", command=self.pausar, state="disabled")
        self.btn_detener = ttk.Button(bot, text="Detener", command=self.detener, state="disabled")
        for b in (self.btn_iniciar, self.btn_pausar, self.btn_detener):
            b.pack(side="left", padx=8)
        ttk.Button(bot, text="Volver", command=lambda: self.app.mostrar("inicio")).pack(
            side="left", padx=8)

    # ---- gráficas -----------------------------------------------------------------------
    def _formatear_ejes(self) -> None:
        self.ax_loss.set_title("Loss")
        self.ax_acc.set_title("Accuracy")
        for ax in (self.ax_loss, self.ax_acc):
            ax.set_xlabel("Época")
            ax.grid(alpha=0.3)
        self.fig.tight_layout()

    def _redibujar(self) -> None:
        self.ax_loss.clear()
        self.ax_acc.clear()
        for nombre, h in self.historia.items():
            x = range(1, len(h["loss"]) + 1)
            c = COLORES[nombre]
            self.ax_loss.plot(x, h["loss"], color=c, label=f"{nombre} (train)")
            self.ax_loss.plot(x, h["val_loss"], color=c, linestyle="--", label=f"{nombre} (val)")
            self.ax_acc.plot(x, h["accuracy"], color=c, label=f"{nombre} (train)")
            self.ax_acc.plot(x, h["val_accuracy"], color=c, linestyle="--", label=f"{nombre} (val)")
        self._formatear_ejes()
        if self.historia:
            self.ax_loss.legend(fontsize=7)
        self.canvas.draw_idle()

    # ---- control --------------------------------------------------------------------------
    def iniciar(self) -> None:
        """Valida la configuración y lanza el hilo de entrenamiento."""
        if self.entrenando:
            return
        errores = Configuracion.validar(self.app.cfg.as_dict())
        if errores:
            messagebox.showerror("Configuración inválida",
                                 "\n".join(f"• {k}: {v}" for k, v in errores.items()) +
                                 "\n\nCorrija los datos en la pantalla de Configuración.")
            return
        seleccion = self.var_modelo.get()
        n_modelos = 2 if seleccion == "ambos" else 1
        self.historia = {}
        self.completadas = 0
        self.total = int(self.app.cfg["epocas"]) * n_modelos
        self.barra.configure(maximum=self.total, value=0)
        self.lbl_progreso.configure(text=f"Época 0/{self.total}")
        self._redibujar()
        self._log("Iniciando entrenamiento...")
        self.entrenando = True
        self._botones(True)
        self.hilo = threading.Thread(target=self._trabajo, args=(seleccion,), daemon=True)
        self.hilo.start()
        self.app.estado("Entrenando...")

    def _trabajo(self, seleccion: str) -> None:
        """Cuerpo del hilo de entrenamiento (no toca widgets)."""
        manejador = _ManejadorCola(self.cola)
        logging.getLogger().addHandler(manejador)
        try:
            from modulos.entrenamiento import Entrenador  # import tardío (TensorFlow)
            self.entrenador = Entrenador(
                self.app.cfg, self.app.repositorio,
                callback_epoca=lambda info: self.cola.put(("epoca", info)),
                callback_log=lambda m: self.cola.put(("log", m)))
            self.entrenador.entrenar(seleccion)
            self.cola.put(("fin", None))
        except Exception as exc:  # noqa: BLE001
            logger.exception("Fallo en el entrenamiento")
            self.cola.put(("error", str(exc)))
        finally:
            logging.getLogger().removeHandler(manejador)

    def pausar(self) -> None:
        """Alterna pausa/reanudación."""
        if not self.entrenador:
            return
        if self.entrenador.pausado:
            self.entrenador.reanudar()
            self.btn_pausar.configure(text="Pausar")
        else:
            self.entrenador.pausar()
            self.btn_pausar.configure(text="Reanudar")

    def detener(self) -> None:
        """Solicita detener el entrenamiento."""
        if self.entrenador:
            self.entrenador.detener()
        self.btn_detener.configure(state="disabled")

    def detener_todo(self) -> None:
        """Usado al cerrar la aplicación."""
        if self.entrenando and self.entrenador:
            self.entrenador.detener()

    def _botones(self, entrenando: bool) -> None:
        self.btn_iniciar.configure(state="disabled" if entrenando else "normal")
        self.btn_pausar.configure(state="normal" if entrenando else "disabled", text="Pausar")
        self.btn_detener.configure(state="normal" if entrenando else "disabled")

    # ---- cola de eventos (hilo principal) ------------------------------------------------------
    def _log(self, mensaje: str) -> None:
        self.txt.configure(state="normal")
        self.txt.insert("end", mensaje + "\n")
        self.txt.see("end")
        self.txt.configure(state="disabled")

    def _sondear_cola(self) -> None:
        try:
            while True:
                tipo, dato = self.cola.get_nowait()
                if tipo == "log":
                    self._log(dato)
                elif tipo == "epoca":
                    h = self.historia.setdefault(dato["modelo"], {
                        "loss": [], "val_loss": [], "accuracy": [], "val_accuracy": []})
                    for k in h:
                        h[k].append(dato[k])
                    self.completadas += 1
                    self.barra.configure(value=self.completadas)
                    self.lbl_progreso.configure(
                        text=f"{dato['modelo']}: época {dato['epoca']}/{dato['epocas']}")
                    self._redibujar()
                elif tipo == "fin":
                    self._terminar("Entrenamiento finalizado")
                    messagebox.showinfo("Entrenamiento", "Entrenamiento finalizado. "
                                        "Los modelos fueron guardados.")
                elif tipo == "error":
                    self._log(f"ERROR: {dato}")
                    self._terminar("Error en el entrenamiento")
                    messagebox.showerror("Error de entrenamiento", dato)
        except queue.Empty:
            pass
        self.after(100, self._sondear_cola)

    def _terminar(self, estado: str) -> None:
        self.entrenando = False
        self._botones(False)
        self.app.estado(estado)

    def _actualizar_recursos(self) -> None:
        try:
            r = self.monitor.instantanea()
            self.lbl_cpu.configure(text=f"CPU: {r['cpu']:.0f} %")
            self.lbl_gpu.configure(text=f"GPU: {r['gpu']:.0f} %")
            self.lbl_ram.configure(text=f"RAM: {r['ram_mb']:.0f} MB")
        except Exception:  # noqa: BLE001
            pass
        self.after(1000, self._actualizar_recursos)
