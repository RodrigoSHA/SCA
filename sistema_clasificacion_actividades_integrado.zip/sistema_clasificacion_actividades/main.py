"""Punto de entrada del Sistema de Clasificación de Actividades Físicas.

Inicializa el logging y la configuración por defecto, lanza la GUI y
gestiona el cierre limpio de la aplicación.
"""
import logging
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from modulos.configuracion import Configuracion, crear_estructura  # noqa: E402

logger = logging.getLogger("main")


def configurar_logging() -> None:
    """Configura logging hacia consola y hacia ``logs/entrenamiento.log``."""
    (BASE_DIR / "logs").mkdir(exist_ok=True)
    formato = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s")
    raiz = logging.getLogger()
    raiz.setLevel(logging.INFO)
    raiz.handlers.clear()
    archivo = logging.FileHandler(
        BASE_DIR / "logs" / "entrenamiento.log", encoding="utf-8")
    consola = logging.StreamHandler()
    for h in (archivo, consola):
        h.setFormatter(formato)
        raiz.addHandler(h)


def main() -> int:
    """Lanza la aplicación. Devuelve el código de salida del proceso."""
    configurar_logging()
    logger.info("Iniciando aplicación")
    try:
        crear_estructura()
        cfg = Configuracion()
        # Import tardío: TensorFlow tarda en cargar y los errores se capturan abajo.
        from interfaz.ventana_principal import VentanaPrincipal
        app = VentanaPrincipal(cfg)
        app.protocol("WM_DELETE_WINDOW", app.cerrar)
        app.mainloop()
    except Exception as exc:  # noqa: BLE001
        logger.exception("Error fatal")
        try:
            from tkinter import messagebox, Tk
            raiz = Tk()
            raiz.withdraw()
            messagebox.showerror("Error fatal", f"La aplicación no pudo iniciar:\n{exc}")
            raiz.destroy()
        except Exception:  # noqa: BLE001
            pass
        return 1
    logger.info("Aplicación cerrada correctamente")
    return 0


if __name__ == "__main__":
    sys.exit(main())
