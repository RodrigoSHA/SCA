"""Mide el rendimiento de la detección en tiempo real con y sin la rama tabular.

Compara dos configuraciones del MISMO detector (modelo clásico con pesos
aleatorios; el rendimiento no depende de los pesos):

* **solo imagen**: modelo de un input; no se ejecuta MediaPipe Pose.
* **imagen + tabular**: modelo de dos inputs; MediaPipe Pose corre en el hilo de
  captura (1 de cada ``paso_muestreo`` frames) y las features se calculan en el
  hilo de inferencia.

Además mide por separado el coste de una llamada a Pose, de
``features_desde_poses`` y de una inferencia.

Uso::

    python benchmark_deteccion.py                       # cámara 0, 20 s por caso
    python benchmark_deteccion.py --fuente video.mp4    # un video como cámara

Con una cámara real los FPS están limitados por la cámara (~30). Con un video
como fuente la captura no tiene límite, así que el resultado es el máximo FPS
que el hilo de captura puede sostener (si es >= 15, el requisito se cumple).
Para que Pose haga trabajo real el video debe contener una persona.
"""
import argparse
import logging
import sys
import time
from pathlib import Path

import numpy as np

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from modulos.configuracion import Configuracion  # noqa: E402


def crear_modelo(tabular: bool, seq: int, size: int):
    """Modelo clásico con pesos aleatorios y sus parámetros guardables."""
    from modulos.modelo_clasico import ModeloClasico
    from modulos.preparar_dataset import NOMBRES_FEATURES
    cfg = Configuracion(ruta=BASE_DIR / "__no_existe__.json")
    cfg.actualizar({"seq_length": seq, "img_size": size, "pesos_imagenet": False,
                    "usar_features_tabulares": tabular})
    if tabular:                      # estadísticas neutras: solo importa la forma
        n = len(NOMBRES_FEATURES)
        cfg.actualizar({"columnas_tabulares": list(NOMBRES_FEATURES),
                        "n_features_tabulares": n,
                        "medias_imputacion": {c: 0.0 for c in NOMBRES_FEATURES},
                        "medias_normalizacion": [0.0] * n, "stds_normalizacion": [1.0] * n})
    w = ModeloClasico(cfg, pesos_imagenet=False)
    w.construir()
    return w.modelo, list(cfg["clases"]), w.parametros()


def medir_detector(tabular: bool, fuente, segundos: float, seq: int, size: int,
                   paso: int) -> dict:
    """Ejecuta el detector ``segundos`` (o hasta que acabe el video) y devuelve métricas."""
    from modulos.deteccion_tiempo_real import DetectorTiempoReal
    modelo, clases, params = crear_modelo(tabular, seq, size)
    det = DetectorTiempoReal(modelo, clases, indice_camara=fuente, paso_muestreo=paso,
                             params=params)
    det.iniciar()
    t0 = time.perf_counter()
    muestras, marca = [], None
    while det.activo and time.perf_counter() - t0 < segundos:
        time.sleep(0.25)
        est = det.obtener_estado()
        if est["frames_capturados"] > 0 and marca is None:
            marca = (time.perf_counter(), est["frames_capturados"], est["inferencias"])
        if marca and time.perf_counter() - marca[0] > 3.0:        # descarta el arranque
            muestras.append(est["fps"])
    t1 = time.perf_counter()
    est = det.obtener_estado()
    det.detener()
    if marca is None:
        return {"error": est["error"] or "no se capturó ningún frame"}
    dt = max(t1 - marca[0], 1e-6)
    return {"fps_medio_ema": float(np.mean(muestras)) if muestras else float("nan"),
            "fps_minimo_ema": float(np.min(muestras)) if muestras else float("nan"),
            "fps_global": (est["frames_capturados"] - marca[1]) / dt,
            "inferencias_s": (est["inferencias"] - marca[2]) / dt,
            "segundos": dt, "error": est["error"]}


def micro(fuente, seq: int, size: int, paso: int) -> dict:
    """Coste por operación (ms): Pose, features_desde_poses e inferencia."""
    import cv2
    from modulos.deteccion_tiempo_real import DetectorTiempoReal
    from modulos.preparar_dataset import features_desde_poses
    cap = cv2.VideoCapture(fuente)
    frames = []
    while len(frames) < 40:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if not frames:
        return {}
    pose = DetectorTiempoReal._crear_pose()
    DetectorTiempoReal._extraer_pose(pose, frames[0])             # calentamiento
    t = time.perf_counter()
    poses = [DetectorTiempoReal._extraer_pose(pose, f) for f in frames]
    ms_pose = (time.perf_counter() - t) / len(frames) * 1000
    pose.close()
    ventana = np.stack((poses * 2)[:seq])
    t = time.perf_counter()
    for _ in range(200):
        features_desde_poses(ventana, 640 / 480)
    ms_feat = (time.perf_counter() - t) / 200 * 1000
    res = {"ms_pose": ms_pose, "ms_features": ms_feat,
           "pose_detectada": float(np.mean([not np.isnan(p[0, 0]) for p in poses]))}
    for tab in (False, True):
        modelo, _, params = crear_modelo(tab, seq, size)
        x = np.random.rand(1, seq, size, size, 3).astype("float32") * 255
        entradas = [x, np.zeros((1, len(params.get("columnas_tabulares", [])) or 1),
                                "float32")] if tab else x
        modelo(entradas, training=False)
        t = time.perf_counter()
        for _ in range(5):
            modelo(entradas, training=False)
        res["ms_inferencia_tab" if tab else "ms_inferencia_img"] = \
            (time.perf_counter() - t) / 5 * 1000
    return res


def main() -> int:
    """Imprime la tabla comparativa."""
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--fuente", default="0", help="índice de cámara o ruta de un video")
    ap.add_argument("--segundos", type=float, default=20.0, help="duración por caso")
    ap.add_argument("--seq-length", type=int, default=8)
    ap.add_argument("--img-size", type=int, default=224)
    ap.add_argument("--paso-muestreo", type=int, default=4)
    a = ap.parse_args()
    logging.basicConfig(level=logging.ERROR)
    fuente = int(a.fuente) if a.fuente.isdigit() else a.fuente

    m = micro(fuente, a.seq_length, a.img_size, a.paso_muestreo)
    if m:
        print(f"\nCoste por operación: Pose {m['ms_pose']:.1f} ms/frame "
              f"(persona detectada en {m['pose_detectada'] * 100:.0f} % de los frames) | "
              f"features_desde_poses {m['ms_features']:.2f} ms | inferencia "
              f"solo imagen {m['ms_inferencia_img']:.0f} ms, imagen+tabular "
              f"{m['ms_inferencia_tab']:.0f} ms")
    print("\n{:<22}{:>11}{:>11}{:>11}{:>12}".format(
        "Caso", "FPS medio", "FPS mín", "FPS global", "inferenc./s"))
    for nombre, tab in (("solo imagen", False), ("imagen + tabular", True)):
        r = medir_detector(tab, fuente, a.segundos, a.seq_length, a.img_size,
                           a.paso_muestreo)
        if "fps_global" not in r:
            print(f"{nombre:<22} ERROR: {r['error']}")
            continue
        print(f"{nombre:<22}{r['fps_medio_ema']:>11.1f}{r['fps_minimo_ema']:>11.1f}"
              f"{r['fps_global']:>11.1f}{r['inferencias_s']:>12.2f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
