"""Módulo 3: modelo clásico (MobileNetV3Small + LSTM).

Incluye :func:`construir_extractor`, compartido con el modelo híbrido para
garantizar una comparación justa (mismo extractor, misma política de
congelado).
"""
import logging
from typing import Optional, Tuple

import tensorflow as tf
from tensorflow.keras import layers

logger = logging.getLogger(__name__)


def construir_extractor(img_size: int, pesos_imagenet: bool = True,
                        congelar_pct: float = 0.8) -> tf.keras.Model:
    """Crea el extractor MobileNetV3Small con transfer learning.

    Se congela el ``congelar_pct`` inicial de las capas (80 % por defecto);
    solo se afina el 20 % final. Las capas BatchNormalization permanecen
    siempre congeladas, práctica habitual para estabilizar el ajuste fino.

    Args:
        img_size: Lado de la imagen de entrada.
        pesos_imagenet: Si es True, usa pesos preentrenados en ImageNet.
        congelar_pct: Fracción de capas a congelar (0-1).

    Returns:
        Modelo Keras ``(img, img, 3) -> (576,)`` con pooling promedio global.
        Espera píxeles en 0-255 (incluye su propio preprocesamiento).
    """
    base = tf.keras.applications.MobileNetV3Small(
        input_shape=(img_size, img_size, 3), include_top=False,
        weights="imagenet" if pesos_imagenet else None,
        pooling="avg", include_preprocessing=True)
    extractor = tf.keras.Model(base.input, base.output, name="mobilenet_extractor")
    total = len(extractor.layers)
    n_congeladas = int(round(total * float(congelar_pct)))
    for i, capa in enumerate(extractor.layers):
        capa.trainable = (i >= n_congeladas
                          and not isinstance(capa, layers.BatchNormalization))
    n_entrenables = sum(int(tf.size(w)) for w in extractor.trainable_weights)
    logger.info("Extractor: %d capas (%d congeladas), %d parámetros entrenables",
                total, n_congeladas, n_entrenables)
    return extractor


def usa_tabular(cfg) -> bool:
    """True si la configuración pide la rama tabular (False si la clave no existe,
    que es el caso de los modelos guardados antes de esta integración)."""
    return bool(cfg.get("usar_features_tabulares", False))


def n_features(cfg) -> int:
    """Tamaño de la rama tabular: ``len(columnas_tabulares)`` si ya hay columnas
    (modelo entrenado/cargado) o ``n_features_tabulares`` en caso contrario."""
    columnas = cfg.get("columnas_tabulares") or []
    n = len(columnas) if columnas else int(cfg.get("n_features_tabulares", 0))
    if n <= 0:
        raise ValueError("usar_features_tabulares=True pero n_features_tabulares es 0.")
    return n


def construir_rama_tabular(n_feat: int) -> Tuple[tf.Tensor, tf.Tensor]:
    """Rama tabular compartida: ``(F,) -> Dense(32) -> Dropout(0.2) -> Dense(16)``.

    Returns:
        ``(entrada_tabular, salida)``.
    """
    entrada = layers.Input(shape=(n_feat,), name="entrada_tabular")
    b = layers.Dense(32, activation="relu", name="tab_densa_1")(entrada)
    b = layers.Dropout(0.2, name="tab_dropout")(b)
    b = layers.Dense(16, activation="relu", name="tab_densa_2")(b)
    return entrada, b


def parametros_tabulares(cfg) -> dict:
    """Campos de la rama tabular que se guardan en ``config_<modelo>.json``."""
    if not usa_tabular(cfg):
        return {"usar_features_tabulares": False}
    return {
        "usar_features_tabulares": True,
        "n_features_tabulares": n_features(cfg),
        "columnas_tabulares": list(cfg.get("columnas_tabulares") or []),
        "medias_imputacion": {k: float(v) for k, v in
                              dict(cfg.get("medias_imputacion") or {}).items()},
        "medias_normalizacion": [float(v) for v in cfg.get("medias_normalizacion") or []],
        "stds_normalizacion": [float(v) for v in cfg.get("stds_normalizacion") or []],
    }


class ModeloClasico:
    """MobileNetV3Small (por frame) + LSTM + clasificador softmax.

    Con ``usar_features_tabulares`` (rama tabular) el grafo es::

        imagenes (T,S,S,3) -> TimeDistributed(extractor) -> LSTM -> Dropout(0.3) -+
        tabular  (F,)      -> Dense(32) -> Dropout(0.2) -> Dense(16) -------------+-> Concatenate
                                              -> Dense(64) -> Dense(n_clases, softmax)

    Sin ella, el modelo de un solo input de siempre.

    Args:
        cfg: Configuración (``Configuracion`` o diccionario).
        pesos_imagenet: Sobrescribe ``cfg["pesos_imagenet"]`` (False al
            cargar modelos guardados para no descargar pesos).

    Attributes:
        modelo: ``tf.keras.Model`` una vez llamado :meth:`construir`.
    """

    NOMBRE = "clasico"

    def __init__(self, cfg, pesos_imagenet: Optional[bool] = None) -> None:
        self.cfg = cfg
        self.pesos_imagenet = (cfg["pesos_imagenet"] if pesos_imagenet is None
                               else pesos_imagenet)
        self.modelo: Optional[tf.keras.Model] = None

    def construir(self) -> tf.keras.Model:
        """Construye el grafo.

        Con rama tabular: ``[(T,S,S,3), (F,)] -> softmax(n_clases)``; sin ella:
        ``(T,S,S,3) -> softmax(n_clases)`` (idéntico al modelo anterior).
        """
        t = int(self.cfg["seq_length"])
        s = int(self.cfg["img_size"])
        tabular = usa_tabular(self.cfg)
        extractor = construir_extractor(s, self.pesos_imagenet,
                                        float(self.cfg["congelar_pct"]))
        entrada = layers.Input(shape=(t, s, s, 3),
                               name="entrada_imagenes" if tabular else "secuencia")
        # El mismo extractor se aplica a cada frame de la secuencia.
        x = layers.TimeDistributed(extractor, name="extractor_td")(entrada)
        x = layers.LSTM(int(self.cfg.get("lstm_unidades", 128)), name="lstm")(x)
        x = layers.Dropout(0.3)(x)
        entradas = entrada
        if tabular:
            entrada_tab, rama = construir_rama_tabular(n_features(self.cfg))
            x = layers.Concatenate(name="fusion")([x, rama])
            entradas = [entrada, entrada_tab]
        x = layers.Dense(64, activation="relu", name="densa")(x)
        salida = layers.Dense(int(self.cfg["n_clases"]), activation="softmax",
                              name="salida")(x)
        self.modelo = tf.keras.Model(entradas, salida, name="modelo_clasico")
        return self.modelo

    def compilar(self, learning_rate: Optional[float] = None) -> None:
        """Compila con Adam y entropía cruzada categórica dispersa."""
        if self.modelo is None:
            self.construir()
        lr = float(learning_rate or self.cfg["learning_rate"])
        self.modelo.compile(
            optimizer=tf.keras.optimizers.Adam(lr),
            loss="sparse_categorical_crossentropy", metrics=["accuracy"])

    def parametros(self) -> dict:
        """Parámetros necesarios para reconstruir la arquitectura (y, con rama
        tabular, para reproducir la imputación y normalización de las features)."""
        params = {"tipo": self.NOMBRE, "seq_length": int(self.cfg["seq_length"]),
                  "img_size": int(self.cfg["img_size"]),
                  "n_clases": int(self.cfg["n_clases"]),
                  "congelar_pct": float(self.cfg["congelar_pct"]),
                  "lstm_unidades": int(self.cfg.get("lstm_unidades", 128)),
                  "pesos_imagenet": False,
                  "learning_rate": float(self.cfg["learning_rate"])}
        params.update(parametros_tabulares(self.cfg))
        return params
