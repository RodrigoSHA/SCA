"""Módulo 4: modelo híbrido cuántico-clásico (MobileNetV3Small + PQC).

Comparte el extractor congelado con :class:`ModeloClasico`. En lugar de la
LSTM, las características por frame se promedian en el tiempo, se reducen a
``n_qubits`` ángulos y pasan por el circuito cuántico variacional.
"""
import logging
from typing import Optional

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers

from modulos.circuito_cuantico import CircuitoPQC
from modulos.modelo_clasico import (construir_extractor, construir_rama_tabular,
                                    n_features, parametros_tabulares, usa_tabular)

logger = logging.getLogger(__name__)


class ModeloHibrido:
    """MobileNetV3Small + reducción a n_qubits + PQC + clasificador softmax.

    Flujo::

        secuencia -> MobileNetV3Small (por frame) -> promedio temporal (576)
        -> Dropout(0.3) -> [+ rama tabular] -> Dense(n_qubits, tanh)
        -> x pi (ángulos) -> PQC -> Dense(softmax)

    La rama tabular (``usar_features_tabulares``) es
    ``(F,) -> Dense(32) -> Dropout(0.2) -> Dense(16)`` y se concatena DESPUÉS
    del Dropout(0.3) de las imágenes y ANTES de ``Dense(n_qubits, tanh)``.
    El extractor y el PQC no cambian.

    Args:
        cfg: Configuración (``Configuracion`` o diccionario).
        pesos_imagenet: Sobrescribe ``cfg["pesos_imagenet"]``.

    Attributes:
        modelo: ``tf.keras.Model`` tras :meth:`construir`.
        pqc: Instancia de :class:`CircuitoPQC`.
    """

    NOMBRE = "hibrido"
    CAPA_CUANTICA = "capa_cuantica"

    def __init__(self, cfg, pesos_imagenet: Optional[bool] = None) -> None:
        self.cfg = cfg
        self.pesos_imagenet = (cfg["pesos_imagenet"] if pesos_imagenet is None
                               else pesos_imagenet)
        self.pqc = CircuitoPQC(
            n_qubits=int(cfg["n_qubits"]), n_capas=int(cfg["n_capas_pqc"]),
            shots=int(cfg["shots"]), seed=int(cfg["seed"]),
            usar_shots=bool(cfg.get("usar_shots_entrenamiento", False)))
        self.modelo: Optional[tf.keras.Model] = None

    def construir(self) -> tf.keras.Model:
        """Construye el grafo (``[(T,S,S,3), (F,)]`` con rama tabular, o solo
        ``(T,S,S,3)``) hasta ``softmax(n_clases)``."""
        t = int(self.cfg["seq_length"])
        s = int(self.cfg["img_size"])
        tabular = usa_tabular(self.cfg)
        extractor = construir_extractor(s, self.pesos_imagenet,
                                        float(self.cfg["congelar_pct"]))
        entrada = layers.Input(shape=(t, s, s, 3),
                               name="entrada_imagenes" if tabular else "secuencia")
        x = layers.TimeDistributed(extractor, name="extractor_td")(entrada)
        x = layers.GlobalAveragePooling1D(name="promedio_temporal")(x)
        x = layers.Dropout(0.3)(x)
        entradas = entrada
        if tabular:
            entrada_tab, rama = construir_rama_tabular(n_features(self.cfg))
            x = layers.Concatenate(name="fusion")([x, rama])
            entradas = [entrada, entrada_tab]
        # tanh limita a [-1, 1]; al multiplicar por pi los ángulos quedan en
        # [-pi, pi], el rango natural para la codificación RY.
        x = layers.Dense(self.pqc.n_qubits, activation="tanh", name="reduccion")(x)
        x = layers.Rescaling(np.pi, name="escala_angulos")(x)
        x = self.pqc.crear_capa_keras(name=self.CAPA_CUANTICA)(x)
        salida = layers.Dense(int(self.cfg["n_clases"]), activation="softmax",
                              name="salida")(x)
        self.modelo = tf.keras.Model(entradas, salida, name="modelo_hibrido")
        return self.modelo

    def compilar(self, learning_rate: Optional[float] = None) -> None:
        """Compila con Adam y entropía cruzada categórica dispersa."""
        if self.modelo is None:
            self.construir()
        lr = float(learning_rate or self.cfg["learning_rate"])
        self.modelo.compile(
            optimizer=tf.keras.optimizers.Adam(lr),
            loss="sparse_categorical_crossentropy", metrics=["accuracy"])

    def obtener_pesos_cuanticos(self) -> np.ndarray:
        """Pesos entrenables del PQC, forma ``(n_capas, n_qubits, 3)``."""
        capa = self.modelo.get_layer(self.CAPA_CUANTICA)
        return np.asarray(capa.get_weights()[0])

    def asignar_pesos_cuanticos(self, pesos: np.ndarray) -> None:
        """Asigna pesos al PQC (debe coincidir la forma)."""
        capa = self.modelo.get_layer(self.CAPA_CUANTICA)
        capa.set_weights([np.asarray(pesos, dtype=np.float32)])

    def parametros(self) -> dict:
        """Parámetros necesarios para reconstruir la arquitectura."""
        params = {"tipo": self.NOMBRE, "seq_length": int(self.cfg["seq_length"]),
                  "img_size": int(self.cfg["img_size"]),
                  "n_clases": int(self.cfg["n_clases"]),
                  "congelar_pct": float(self.cfg["congelar_pct"]),
                  "pesos_imagenet": False, "seed": int(self.cfg["seed"]),
                  "learning_rate": float(self.cfg["learning_rate"])}
        params.update(self.pqc.parametros())
        params.update(parametros_tabulares(self.cfg))
        return params
