"""Módulo 1: carga y preprocesamiento del dataset.

Convierte los videos de ``datos/dataset/{train,validation,test}/<clase>/`` en
secuencias de ``seq_length`` frames anonimizados (``datos/frames/...``) usando
la herramienta integrada :mod:`modulos.preparar_dataset` (poses MediaPipe ->
intervalo del ejercicio -> frames clave), y construye los ``tf.data.Dataset``
de entrenamiento y evaluación.

Con ``usar_features_tabulares=True`` (por defecto) el dataset es multimodal:
``((imagenes, features), etiqueta)``. Las features son las de
:func:`modulos.preparar_dataset.features_desde_poses` (solo poses, nunca la
clase), imputadas con la media de ENTRENAMIENTO y estandarizadas con la media y
desviación de ENTRENAMIENTO. Con ``False`` el dataset es ``(imagenes, etiqueta)``.

Este módulo no importa TensorFlow al cargarse (solo dentro de
:meth:`Preprocesador.crear_dataset`) ni importa ``preparar_dataset`` al cargarse
(``preparar_dataset.extractor_frames`` importa :class:`Anonimizador` de aquí).
"""
import json
import logging
import warnings
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)

EXT_VIDEO = (".mp4", ".avi", ".mov", ".mkv", ".mpg", ".mpeg", ".webm")
SPLITS = ("train", "validation", "test")
UMBRAL_STD = 1e-8   # std menor => columna constante; se usa 1.0 para no dividir por ~0


class Anonimizador:
    """Detecta rostros y los difumina con un filtro gaussiano.

    Usa MediaPipe Face Detection; si no está disponible recurre al
    clasificador Haar de OpenCV. Cada hilo debe usar su propia instancia
    (los detectores no son thread-safe).
    """

    def __init__(self, confianza: float = 0.5) -> None:
        """Inicializa el detector disponible.

        Args:
            confianza: Confianza mínima de detección (MediaPipe).
        """
        self._mp = None
        self._haar = None
        try:
            import mediapipe as mp
            self._mp = mp.solutions.face_detection.FaceDetection(
                model_selection=0, min_detection_confidence=confianza)
            logger.info("Anonimización: MediaPipe Face Detection")
        except Exception as exc:  # noqa: BLE001
            logger.warning("MediaPipe no disponible (%s); se usa Haar cascade",
                           exc)
            self._mp = None
            try:
                clase = getattr(cv2, "CascadeClassifier", None) or \
                    cv2.xobjdetect.CascadeClassifier  # OpenCV 5
                ruta = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
                haar = clase(ruta)
                if haar.empty():
                    raise RuntimeError(f"no se pudo cargar {ruta}")
                self._haar = haar
            except Exception as exc2:  # noqa: BLE001
                # La anonimización es obligatoria: sin detector se falla de
                # forma explícita en lugar de procesar rostros sin difuminar.
                raise RuntimeError(
                    "No hay detector de rostros disponible (MediaPipe ni Haar). "
                    "Instale las versiones de requirements.txt "
                    f"(mediapipe==0.10.9, opencv-python==4.9.0.80). Detalle: {exc2}"
                ) from exc2

    def detectar(self, frame_bgr: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """Devuelve las cajas ``(x, y, ancho, alto)`` de los rostros."""
        alto, ancho = frame_bgr.shape[:2]
        cajas: List[Tuple[int, int, int, int]] = []
        if self._mp is not None:
            rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
            res = self._mp.process(rgb)
            for det in (res.detections or []):
                bb = det.location_data.relative_bounding_box
                cajas.append((int(bb.xmin * ancho), int(bb.ymin * alto),
                              int(bb.width * ancho), int(bb.height * alto)))
        elif self._haar is not None and not self._haar.empty():
            gris = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
            for (x, y, w, h) in self._haar.detectMultiScale(gris, 1.1, 5):
                cajas.append((int(x), int(y), int(w), int(h)))
        return cajas

    @staticmethod
    def difuminar(frame_bgr: np.ndarray,
                  cajas: List[Tuple[int, int, int, int]]) -> np.ndarray:
        """Aplica desenfoque gaussiano (in situ) sobre las cajas dadas."""
        alto, ancho = frame_bgr.shape[:2]
        for (x, y, w, h) in cajas:
            # Se amplía la caja un 25 % para cubrir frente, barbilla y orejas.
            mx, my = int(w * 0.25), int(h * 0.25)
            x0, y0 = max(0, x - mx), max(0, y - my)
            x1, y1 = min(ancho, x + w + mx), min(alto, y + h + my)
            if x1 <= x0 or y1 <= y0:
                continue
            k = max(3, (max(x1 - x0, y1 - y0) // 2) | 1)  # núcleo impar
            roi = frame_bgr[y0:y1, x0:x1]
            frame_bgr[y0:y1, x0:x1] = cv2.GaussianBlur(roi, (k, k), 0)
        return frame_bgr

    def aplicar(self, frame_bgr: np.ndarray) -> np.ndarray:
        """Detecta y difumina los rostros de un frame BGR (in situ)."""
        return self.difuminar(frame_bgr, self.detectar(frame_bgr))

    def cerrar(self) -> None:
        """Libera los recursos del detector."""
        if self._mp is not None:
            self._mp.close()
            self._mp = None


def posiciones_secuencia(n_disponibles: int, n_seq: int) -> np.ndarray:
    """Índices equiespaciados para quedarse con ``n_seq`` de ``n_disponibles``."""
    return np.linspace(0, n_disponibles - 1, n_seq).astype(int)


def normalizar_features(x: np.ndarray, columnas: Sequence[str],
                        medias_imputacion: Dict[str, float],
                        medias: Sequence[float], stds: Sequence[float]) -> np.ndarray:
    """Imputa NaN con ``medias_imputacion`` y estandariza ``(x - media) / std``.

    Es la ÚNICA transformación tabular: la usan ``crear_dataset`` (train, val,
    test) y la detección en tiempo real, con los mismos parámetros guardados.

    Args:
        x: ``(N, F)`` o ``(F,)`` con posibles NaN.
        columnas: Nombres de columna en el orden de ``x``.
        medias_imputacion: ``{columna: media de train}``.
        medias, stds: Media y desviación de train tras imputar, ``(F,)``.

    Returns:
        ``float32`` con la misma forma que ``x``.

    Raises:
        ValueError: Si faltan columnas en ``medias_imputacion`` o las
            longitudes no coinciden con ``x``.
    """
    x = np.asarray(x, dtype=np.float64)
    f = len(columnas)
    if x.shape[-1] != f or len(medias) != f or len(stds) != f:
        raise ValueError(
            f"Dimensiones inconsistentes: x{x.shape}, {f} columnas, "
            f"{len(medias)} medias, {len(stds)} stds")
    try:
        imp = np.array([medias_imputacion[c] for c in columnas], dtype=np.float64)
    except KeyError as exc:
        raise ValueError(f"medias_imputacion no tiene la columna {exc}") from exc
    sd = np.asarray(stds, dtype=np.float64).copy()
    sd[~(sd > UMBRAL_STD)] = 1.0
    x = np.where(np.isnan(x), imp, x)
    return ((x - np.asarray(medias, dtype=np.float64)) / sd).astype(np.float32)


class Preprocesador:
    """Extrae frames anonimizados + poses y crea los datasets de TensorFlow.

    Args:
        cfg: ``Configuracion`` (o dict) del proyecto.

    Attributes:
        cfg: Configuración vigente.
    """

    def __init__(self, cfg) -> None:
        self.cfg = cfg
        self._anon: Optional[Anonimizador] = None
        # Estadísticas tabulares impuestas desde fuera (p. ej. las del modelo
        # que se evalúa); si es None se usan las de cfg / se calculan de train.
        self._stats_fijas: Optional[dict] = None

    # ---- opciones --------------------------------------------------------------
    @property
    def usar_tabular(self) -> bool:
        """Valor de ``usar_features_tabulares`` (False si la clave no existe)."""
        return bool(self.cfg.get("usar_features_tabulares", False))

    # ---- rutas ----------------------------------------------------------
    @property
    def ruta_dataset(self) -> Path:
        """Carpeta con los videos originales."""
        return self.cfg.ruta_absoluta("ruta_dataset")

    @property
    def ruta_frames(self) -> Path:
        """Carpeta con los frames preprocesados."""
        return self.cfg.ruta_absoluta("ruta_frames")

    def detectar_clases(self) -> List[str]:
        """Infiere las clases a partir de las subcarpetas de ``train``.

        Si encuentra subcarpetas, actualiza ``clases`` y ``n_clases`` en la
        configuración. Si no, conserva las de la configuración.
        """
        base = self.ruta_dataset / "train"
        if base.is_dir():
            encontradas = sorted(d.name for d in base.iterdir() if d.is_dir())
            if encontradas:
                self.cfg.actualizar({"clases": encontradas})
        return list(self.cfg["clases"])

    # ---- procesamiento de videos (herramienta integrada) ------------------------
    def _secuencia_completa(self, destino: Path, n_seq: int) -> bool:
        """True si ``destino`` ya tiene lo necesario y no hay que reprocesar."""
        if not destino.is_dir() or len(list(destino.glob("*.jpg"))) != n_seq:
            return False
        if self.usar_tabular:
            return (destino / "poses.npz").exists() and (destino / "meta.json").exists()
        return True

    def procesar_dataset(self, progreso: Optional[Callable[[int, int, str], None]] = None,
                         forzar: bool = False) -> dict:
        """Procesa todos los videos con ``preparar_dataset.pipeline.procesar_video``.

        Por video escribe en ``<ruta_frames>/<split>/<clase>/<video>/``: ``seq_length``
        JPG anonimizados, ``poses.npz``, ``meta.json``, ``debug.png`` y los CSV de
        diagnóstico de la herramienta (que el entrenamiento NO usa).

        Args:
            progreso: Callback ``(actual, total, mensaje)``.
            forzar: Si es True, reprocesa aunque ya existan los archivos.

        Returns:
            ``{split: numero_de_videos_procesados}``.

        Raises:
            ValueError: Si hay clases que la herramienta no soporta.
            FileNotFoundError: Si no hay videos.
            RuntimeError: Error global (sin detector de rostros / de poses) o
                si no se pudo procesar ningún video.
        """
        from modulos.preparar_dataset import (CLASES_CONOCIDAS, cargar_config,
                                              crear_anonimizador, procesar_video)
        clases = self.detectar_clases()
        desconocidas = [c for c in clases if c not in CLASES_CONOCIDAS]
        if desconocidas:
            raise ValueError(
                f"Clases no soportadas por el detector de ejercicios: {desconocidas}. "
                f"Clases válidas: {list(CLASES_CONOCIDAS)}. Renombre las subcarpetas "
                "de los splits o amplíe detector_ejercicio.analizar_video.")
        trabajos = []
        for split in SPLITS:
            for clase in clases:
                carpeta = self.ruta_dataset / split / clase
                if not carpeta.is_dir():
                    continue
                for v in sorted(carpeta.iterdir()):
                    if v.suffix.lower() in EXT_VIDEO:
                        trabajos.append((split, clase, v))
        if not trabajos:
            raise FileNotFoundError(
                f"No se encontraron videos en {self.ruta_dataset}. Estructura "
                "esperada: <dataset>/{train,validation,test}/<clase>/video.mp4")
        cfg_herr = cargar_config(self.cfg)
        n_seq = int(cfg_herr["n_seq"])
        conteo = {s: 0 for s in SPLITS}
        n_fallback = 0
        ultimo_error: Optional[Exception] = None
        anon = None
        try:
            for i, (split, clase, video) in enumerate(trabajos, 1):
                destino = self.ruta_frames / split / clase / video.stem
                if progreso:
                    progreso(i, len(trabajos), f"{split}/{clase}/{video.name}")
                try:
                    if not forzar and self._secuencia_completa(destino, n_seq):
                        conteo[split] += 1
                        continue
                    if anon is None:      # se crea en este hilo y solo si hace falta
                        anon = crear_anonimizador(cfg_herr["confianza_mediapipe"])
                    res = procesar_video(video, clase, cfg_herr, anonimizador=anon,
                                         carpeta_destino=destino,
                                         usar_cache=not forzar)
                    if not res["meta"].get("deteccion_ok", True):
                        n_fallback += 1
                    conteo[split] += 1
                except RuntimeError:
                    raise  # error global (p. ej. sin detector de rostros): abortar
                except Exception as exc:  # noqa: BLE001
                    ultimo_error = exc
                    logger.error("Video omitido (%s): %s", video.name, exc)
        finally:
            if anon is not None:
                anon.cerrar()
        if sum(conteo.values()) == 0:
            raise RuntimeError(
                f"No se pudo procesar ningún video. Último error: {ultimo_error}")
        if n_fallback:
            logger.warning("%d video(s) sin intervalo detectado (deteccion_ok=False): "
                           "se usó el video completo. Revise debug.png / meta.json.",
                           n_fallback)
        logger.info("Frames generados: %s", conteo)
        return conteo

    def _hay_videos(self, split: str) -> bool:
        for clase in self.cfg["clases"]:
            carpeta = self.ruta_dataset / split / clase
            if carpeta.is_dir() and any(v.suffix.lower() in EXT_VIDEO
                                        for v in carpeta.iterdir()):
                return True
        return False

    def asegurar_frames(self, progreso=None) -> None:
        """Procesa los videos si algún split con videos no tiene muestras listas.

        ``procesar_dataset`` es idempotente (omite lo ya completo), así que esto
        también completa un dataset de frames antiguo al que le faltan las poses.
        """
        pendientes = [s for s in SPLITS
                      if self._hay_videos(s) and len(self.listar_muestras(s)[0]) == 0]
        if pendientes:
            logger.info("Sin muestras listas en %s; procesando videos...", pendientes)
            self.procesar_dataset(progreso)

    # ---- muestras ---------------------------------------------------------------
    def listar_muestras(self, split: str, requiere_poses: Optional[bool] = None
                        ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Lista las secuencias de un split.

        Args:
            split: ``train``, ``validation`` o ``test``.
            requiere_poses: Si True, omite (con warning) los videos sin
                ``poses.npz`` o ``meta.json``. Por defecto, ``usar_features_tabulares``.

        Returns:
            ``(rutas_img, rutas_poses, etiquetas)``: ``rutas_img`` de forma
            ``(N, seq_length)``, ``rutas_poses`` ``(N,)`` con la ruta de
            ``poses.npz`` (cadena vacía si no existe y no se exige) y
            ``etiquetas`` ``(N,)`` enteros según ``clases``.
        """
        if requiere_poses is None:
            requiere_poses = self.usar_tabular
        n_seq = int(self.cfg["seq_length"])
        rutas, rutas_poses, etiquetas = [], [], []
        for idx, clase in enumerate(self.cfg["clases"]):
            base = self.ruta_frames / split / clase
            if not base.is_dir():
                continue
            for carpeta in sorted(d for d in base.iterdir() if d.is_dir()):
                imgs = sorted(carpeta.glob("*.jpg"))
                if len(imgs) < n_seq:
                    logger.warning("Secuencia incompleta omitida: %s", carpeta)
                    continue
                poses = carpeta / "poses.npz"
                tiene = poses.exists() and (carpeta / "meta.json").exists()
                if requiere_poses and not tiene:
                    logger.warning("Sin poses.npz/meta.json (procese el video de nuevo); "
                                   "omitido: %s", carpeta)
                    continue
                if len(imgs) > n_seq:
                    imgs = [imgs[i] for i in posiciones_secuencia(len(imgs), n_seq)]
                rutas.append([str(p) for p in imgs])
                rutas_poses.append(str(poses) if tiene else "")
                etiquetas.append(idx)
        return (np.array(rutas, dtype=str).reshape(len(rutas), n_seq),
                np.array(rutas_poses, dtype=str).reshape(len(rutas)),
                np.array(etiquetas, dtype=np.int32))

    # ---- features tabulares ---------------------------------------------------------
    def features_de_video(self, ruta_poses: str) -> np.ndarray:
        """``features_desde_poses`` de los frames clave de un video procesado.

        Lee ``poses.npz`` (poses crudas de todos los frames + ancho/alto) y
        ``meta.json`` (``indices_clave``). Es la misma función y la misma
        entrada (poses de los frames clave) que usa la detección en vivo.
        """
        from modulos.preparar_dataset import features_desde_poses
        carpeta = Path(ruta_poses).parent
        with open(carpeta / "meta.json", "r", encoding="utf-8") as fh:
            idx = list(json.load(fh)["indices_clave"])
        n_seq = int(self.cfg["seq_length"])
        if len(idx) > n_seq:   # mismas posiciones que se eligen para los JPG
            idx = [idx[i] for i in posiciones_secuencia(len(idx), n_seq)]
        z = np.load(ruta_poses, allow_pickle=False)
        poses = z["poses"]
        idx = np.clip(np.asarray(idx, dtype=int), 0, len(poses) - 1)
        aspecto = float(z["ancho"]) / max(float(z["alto"]), 1.0)
        return features_desde_poses(poses[idx], aspecto)

    def _matriz_features(self, rutas_poses: Sequence[str]) -> np.ndarray:
        return np.stack([self.features_de_video(r) for r in rutas_poses]) \
            if len(rutas_poses) else np.zeros((0, 0))

    def calcular_estadisticas_tabulares(self, guardar_en_cfg: bool = True) -> dict:
        """Calcula, SOLO con ``train``, las medias de imputación y la normalización.

        * ``medias_imputacion``: ``nanmean`` por columna (0.0 si todo es NaN).
        * ``medias`` / ``stds``: media y desviación tras imputar (std < 1e-8 -> 1).

        Con ``guardar_en_cfg`` las deja en ``cfg`` (``columnas_tabulares``,
        ``n_features_tabulares``, ``medias_imputacion``, ``medias_normalizacion``,
        ``stds_normalizacion``) para que persistencia las guarde con el modelo.

        Raises:
            ValueError: Si ``train`` no tiene muestras con poses.
        """
        from modulos.preparar_dataset import NOMBRES_FEATURES
        _, rutas_poses, _ = self.listar_muestras("train", requiere_poses=True)
        if len(rutas_poses) == 0:
            raise ValueError(
                "No hay muestras de 'train' con poses.npz para calcular las "
                "estadísticas de las features tabulares. Procese el dataset.")
        x = self._matriz_features(rutas_poses)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)    # columnas todo-NaN
            medias_imp = np.nanmean(x, axis=0)
        medias_imp = np.where(np.isnan(medias_imp), 0.0, medias_imp)
        ximp = np.where(np.isnan(x), medias_imp, x)
        mu, sd = ximp.mean(axis=0), ximp.std(axis=0)
        sd = np.where(sd > UMBRAL_STD, sd, 1.0)
        cols = list(NOMBRES_FEATURES)
        stats = {"columnas": cols,
                 "medias_imputacion": {c: float(m) for c, m in zip(cols, medias_imp)},
                 "mu": mu, "sd": sd}
        logger.info("Features tabulares: %d columnas, %d videos de train, "
                    "%.1f %% de valores NaN imputados", len(cols), len(x),
                    100.0 * float(np.isnan(x).mean()))
        if guardar_en_cfg:
            self.cfg["columnas_tabulares"] = cols
            self.cfg["n_features_tabulares"] = len(cols)
            self.cfg["medias_imputacion"] = stats["medias_imputacion"]
            self.cfg["medias_normalizacion"] = [float(v) for v in mu]
            self.cfg["stds_normalizacion"] = [float(v) for v in sd]
        return stats

    @staticmethod
    def estadisticas_desde_dict(datos) -> Optional[dict]:
        """Lee las estadísticas de un dict/Configuracion; None si faltan o no cuadran.

        Raises:
            ValueError: Si ``columnas_tabulares`` no coincide con el orden vigente
                de ``NOMBRES_FEATURES`` (el modelo se entrenó con otras columnas).
        """
        from modulos.preparar_dataset import NOMBRES_FEATURES
        cols = list(datos.get("columnas_tabulares") or [])
        mu = list(datos.get("medias_normalizacion") or [])
        sd = list(datos.get("stds_normalizacion") or [])
        imp = dict(datos.get("medias_imputacion") or {})
        if not cols or not (len(cols) == len(mu) == len(sd)) or len(imp) != len(cols):
            return None
        if cols != list(NOMBRES_FEATURES):
            raise ValueError(
                "El orden/los nombres de columnas_tabulares guardados no coinciden "
                "con los de preparar_dataset.NOMBRES_FEATURES; reentrene el modelo.")
        return {"columnas": cols, "medias_imputacion": imp,
                "mu": np.asarray(mu, dtype=np.float64),
                "sd": np.asarray(sd, dtype=np.float64)}

    def fijar_estadisticas(self, datos) -> None:
        """Impone las estadísticas de un modelo guardado (para evaluarlo).

        Raises:
            ValueError: Si ``datos`` no trae estadísticas válidas.
        """
        stats = self.estadisticas_desde_dict(datos)
        if stats is None:
            raise ValueError("El modelo usa features tabulares pero su configuración "
                             "no incluye columnas/medias/stds válidas.")
        self._stats_fijas = stats

    def _obtener_estadisticas(self, split: str, entrenamiento: bool) -> dict:
        if self._stats_fijas is not None:
            return self._stats_fijas
        if split == "train" and entrenamiento:
            return self.calcular_estadisticas_tabulares()    # siempre desde train
        stats = self.estadisticas_desde_dict(self.cfg)
        return stats if stats is not None else self.calcular_estadisticas_tabulares()

    # ---- datasets ---------------------------------------------------------------------
    def crear_dataset(self, split: str, entrenamiento: bool = False,
                      batch_size: Optional[int] = None,
                      tabular: Optional[bool] = None):
        """Construye un ``tf.data.Dataset``.

        * Multimodal (``tabular=True``): elementos ``((imagenes, features), etiqueta)``
          con formas ``(B, T, S, S, 3)``, ``(B, F)`` y ``(B,)``.
        * Solo imágenes: ``(imagenes, etiqueta)``.

        Los frames se entregan en rango 0-255 (MobileNetV3 incluye su propio
        reescalado). En entrenamiento se baraja (imagen, features y etiqueta
        juntas, para no desalinearlas) y se aplica aumento ligero SOLO a las
        imágenes (volteo horizontal y brillo, idénticos para toda la secuencia).

        Args:
            split: ``train``, ``validation`` o ``test``.
            entrenamiento: Baraja y aumenta; en ``train`` recalcula las
                estadísticas tabulares.
            batch_size: Por defecto ``cfg["batch_size"]``.
            tabular: Fuerza multimodal / solo imágenes; por defecto, la
                configuración (``usar_features_tabulares``).

        Raises:
            ValueError: Si el split no tiene muestras.
        """
        import tensorflow as tf
        usar_tab = self.usar_tabular if tabular is None else bool(tabular)
        rutas, rutas_poses, etiquetas = self.listar_muestras(split, requiere_poses=usar_tab)
        if len(rutas) == 0:
            raise ValueError(
                f"No hay muestras en '{split}'. Coloque videos en "
                f"{self.ruta_dataset / split} y procese el dataset.")
        size = int(self.cfg["img_size"])
        n_seq = rutas.shape[1]
        batch = int(batch_size or self.cfg["batch_size"])
        auto = tf.data.AUTOTUNE

        def _leer(ruta):
            img = tf.io.decode_jpeg(tf.io.read_file(ruta), channels=3)
            return tf.image.resize(img, [size, size])

        def _frames(rutas_seq):
            frames = tf.map_fn(_leer, rutas_seq, fn_output_signature=tf.float32)
            frames.set_shape((n_seq, size, size, 3))
            return frames

        def _aumentar_frames(frames):
            frames = tf.cond(tf.random.uniform([]) > 0.5,
                             lambda: tf.reverse(frames, axis=[2]),
                             lambda: frames)
            return tf.clip_by_value(
                frames + tf.random.uniform([], -20.0, 20.0), 0.0, 255.0)

        if not usar_tab:
            ds = tf.data.Dataset.from_tensor_slices((rutas, etiquetas))
            if entrenamiento:
                ds = ds.shuffle(len(rutas), seed=int(self.cfg["seed"]),
                                reshuffle_each_iteration=True)
            ds = ds.map(lambda r, y: (_frames(r), y), num_parallel_calls=auto)
            if entrenamiento:
                ds = ds.map(lambda f, y: (_aumentar_frames(f), y), num_parallel_calls=auto)
            return ds.batch(batch).prefetch(auto)

        stats = self._obtener_estadisticas(split, entrenamiento)
        tab = normalizar_features(self._matriz_features(rutas_poses), stats["columnas"],
                                  stats["medias_imputacion"], stats["mu"], stats["sd"])
        ds = tf.data.Dataset.from_tensor_slices((rutas, tab, etiquetas))
        if entrenamiento:
            ds = ds.shuffle(len(rutas), seed=int(self.cfg["seed"]),
                            reshuffle_each_iteration=True)
        ds = ds.map(lambda r, t, y: ((_frames(r), t), y), num_parallel_calls=auto)
        if entrenamiento:
            ds = ds.map(lambda x, y: ((_aumentar_frames(x[0]), x[1]), y),
                        num_parallel_calls=auto)
        return ds.batch(batch).prefetch(auto)

    @staticmethod
    def preparar_frame(frame_bgr: np.ndarray, img_size: int) -> np.ndarray:
        """Convierte un frame BGR de cámara a RGB ``img_size x img_size`` (uint8)."""
        return cv2.cvtColor(cv2.resize(frame_bgr, (img_size, img_size)),
                            cv2.COLOR_BGR2RGB)
