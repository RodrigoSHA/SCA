"""Muestreo de frames clave + anonimización + guardado como JPG.

El ``Anonimizador`` es el del proyecto (``modulos.preprocesamiento``), el único
que existe: MediaPipe Face Detection con fallback a Haar Cascade, desenfoque
gaussiano con núcleo impar >= 3 y caja ampliada un 25 %.
"""
import logging
from pathlib import Path
from typing import List

import cv2
import numpy as np

from modulos.preprocesamiento import Anonimizador

logger = logging.getLogger(__name__)


def crear_anonimizador(confianza: float = 0.5) -> Anonimizador:
    """Crea el anonimizador del proyecto.

    Debe llamarse DENTRO del hilo que lo va a usar. Lanza ``RuntimeError`` si no
    hay ningún detector de rostros.
    """
    return Anonimizador(confianza)


def indices_clave(inicio: int, fin: int, n_seq: int) -> List[int]:
    """``n_seq`` índices equiespaciados dentro de ``[inicio, fin]``."""
    return [int(i) for i in np.linspace(inicio, fin, n_seq).astype(int)]


def extraer_frames_clave(video_path, inicio: int, fin: int, n_seq: int = 8,
                         img_size: int = 224, anonimizador=None,
                         carpeta_salida=None, calidad_jpg: int = 95) -> List[str]:
    """Guarda ``n_seq`` frames equiespaciados de ``[inicio, fin]`` ya anonimizados.

    Args:
        video_path: video de origen.
        inicio, fin: intervalo (índices de frame, inclusivos).
        n_seq: número de frames clave.
        img_size: lado del JPG final (cuadrado).
        anonimizador: instancia con ``aplicar(frame_bgr)``. Obligatorio.
        carpeta_salida: carpeta ``datos_salida/frames/<clase>/<video>/``.

    Returns:
        Rutas (str) de ``000.jpg`` … en orden.

    Raises:
        RuntimeError: si no hay anonimizador (nunca se guardan rostros sin difuminar).
    """
    if anonimizador is None:
        raise RuntimeError("No hay detector de rostros (anonimizador): "
                           "no se guardan frames sin anonimizar.")
    if carpeta_salida is None:
        raise ValueError("carpeta_salida es obligatoria")
    carpeta = Path(carpeta_salida)
    carpeta.mkdir(parents=True, exist_ok=True)
    for viejo in carpeta.glob("[0-9][0-9][0-9].jpg"):   # por si cambió n_seq
        viejo.unlink()

    idx = indices_clave(inicio, fin, n_seq)
    necesarios = set(idx)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise IOError(f"No se pudo abrir el video: {video_path}")
    capturados = {}
    try:
        i, ultimo = 0, max(idx)
        while i <= ultimo:
            if not cap.grab():
                break
            if i in necesarios:
                ok, frame = cap.retrieve()
                if ok:
                    capturados[i] = frame
            i += 1
    finally:
        cap.release()
    if not capturados:
        raise IOError(f"No se pudo leer ningún frame clave de {video_path}")

    rutas, previo = [], None
    for k, f in enumerate(idx):
        frame = capturados.get(f)
        if frame is None:
            logger.warning("%s: frame %d ilegible; se repite el anterior", Path(video_path).name, f)
            frame = previo if previo is not None else next(iter(capturados.values()))
        previo = frame
        img = anonimizador.aplicar(frame.copy())            # 1) anonimizar a resolución original
        img = cv2.resize(img, (img_size, img_size), interpolation=cv2.INTER_AREA)  # 2) redimensionar
        ruta = carpeta / f"{k:03d}.jpg"
        if not cv2.imwrite(str(ruta), img, [cv2.IMWRITE_JPEG_QUALITY, int(calidad_jpg)]):
            raise IOError(f"No se pudo escribir {ruta}")
        rutas.append(str(ruta))
    return rutas
