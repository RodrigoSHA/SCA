"""Orquestación: poses → detección → frames → archivos de salida.

Integrado en el proyecto principal: lo usa ``Preprocesador.procesar_dataset``.
Cambios respecto a la herramienta: se eliminaron ``configurar_logging`` y
``fijar_semillas`` (el proyecto tiene los suyos) y ``procesar_video`` acepta
``carpeta_destino`` (para escribir en ``datos/frames/<split>/<clase>/<video>/``).
"""
import json
import logging
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

from . import DIR_SALIDA
from .calculador_features import (energia_por_frame, features_frames_clave,
                                  features_secuencia)
from .detector_ejercicio import Cancelado, analizar_video, extraer_poses
from .extractor_frames import crear_anonimizador, extraer_frames_clave, indices_clave
from .gestor_csv import (COLUMNAS_NUEVAS, consolidar, escribir_features_frame,
                         escribir_features_seq)
from .graficos import guardar_debug_png

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ utilidades
def listar_videos(carpeta_entrada, cfg: dict) -> List[Tuple[str, Path]]:
    """Videos ``(clase, ruta)`` de ``<carpeta>/<clase>/*.mp4`` (clases de config)."""
    carpeta_entrada = Path(carpeta_entrada)
    exts = {e.lower() for e in cfg.get("extensiones_video", [".mp4"])}
    out = []
    for clase in cfg["clases"]:
        d = carpeta_entrada / clase
        if d.is_dir():
            for p in sorted(d.iterdir()):
                if p.is_file() and p.suffix.lower() in exts:
                    out.append((clase, p))
    return out


def carpeta_video(dir_salida, clase: str, video_path) -> Path:
    return Path(dir_salida) / "frames" / clase / Path(video_path).stem


def _firma(video_path, cfg) -> str:
    st = Path(video_path).stat()
    return f"{st.st_size}_{st.st_mtime_ns}_{cfg['confianza_mediapipe']}_{cfg['complejidad_pose']}_{cfg['usar_poses_sinteticas']}"


def _cargar_cache(carpeta: Path, firma: str) -> Optional[dict]:
    ruta = carpeta / "poses.npz"
    if not ruta.exists():
        return None
    try:
        z = np.load(ruta, allow_pickle=False)
        if str(z["firma"]) != firma:
            return None
        return {"poses": z["poses"], "fps": float(z["fps"]), "ancho": int(z["ancho"]),
                "alto": int(z["alto"]), "n_frames": int(z["poses"].shape[0])}
    except Exception as exc:  # noqa: BLE001
        logger.warning("Caché de poses ilegible (%s): %s", ruta, exc)
        return None


def _guardar_cache(carpeta: Path, datos: dict, firma: str) -> None:
    np.savez_compressed(carpeta / "poses.npz", poses=datos["poses"], fps=datos["fps"],
                        ancho=datos["ancho"], alto=datos["alto"], firma=firma)


def _analizar(clase, datos, cfg):
    aspecto = datos["ancho"] / datos["alto"] if datos["alto"] else 1.0
    r = analizar_video(clase, datos["poses"], datos["fps"], cfg, aspecto, datos["alto"])
    r["meta"]["ancho_px"], r["meta"]["alto_px"] = datos["ancho"], datos["alto"]
    return r, aspecto


# ------------------------------------------------------------- procesar video
def procesar_video(video_path, clase: str, cfg: dict, dir_salida=DIR_SALIDA,
                   anonimizador=None, progreso_cb: Optional[Callable[[float], None]] = None,
                   cancelar: Optional[Callable[[], bool]] = None,
                   usar_cache: bool = True, carpeta_destino=None) -> dict:
    """Procesa un video completo y escribe todos sus archivos de salida.

    Args:
        carpeta_destino: Si se indica, TODOS los archivos del video se escriben
            en esa carpeta (p. ej. ``datos/frames/train/salto/video01``); si no,
            en ``<dir_salida>/frames/<clase>/<video>/`` (comportamiento original).

    Returns:
        dict con ``video_id``, ``clase``, ``carpeta``, ``meta``, ``senal``,
        ``indices_clave``, ``rutas_frames``.
    Raises:
        Cancelado, RuntimeError (sin detector de rostros), IOError, ...
    """
    video_path = Path(video_path)
    video_id = video_path.stem
    carpeta = (Path(carpeta_destino) if carpeta_destino is not None
               else carpeta_video(dir_salida, clase, video_path))
    carpeta.mkdir(parents=True, exist_ok=True)
    prog = progreso_cb or (lambda f: None)

    firma = _firma(video_path, cfg)
    datos = _cargar_cache(carpeta, firma) if usar_cache else None
    if datos is None:
        datos = extraer_poses(video_path, cfg, lambda f: prog(0.8 * f), cancelar)
        _guardar_cache(carpeta, datos, firma)
    else:
        logger.info("%s: poses tomadas de la caché", video_id)
    prog(0.8)
    if cancelar and cancelar():
        raise Cancelado()

    r, aspecto = _analizar(clase, datos, cfg)
    meta, senal = r["meta"], r["senal"]
    ini, fin = r["inicio"], r["fin"]
    n_seq, img_size = int(cfg["n_seq"]), int(cfg["img_size"])
    idx = indices_clave(ini, fin, n_seq)

    rutas = extraer_frames_clave(video_path, ini, fin, n_seq, img_size, anonimizador,
                                 carpeta, int(cfg["calidad_jpg"]))
    prog(0.92)

    P = senal["poses"]
    filas = features_frames_clave(video_id, clase, P, senal["poses_interp"], idx, ini, fin,
                                  datos["fps"], aspecto, senal["sospechoso"])
    fila_seq = features_secuencia(video_id, clase, n_seq, meta, senal["poses_interp"],
                                  ini, fin, aspecto, senal["energia_s"])
    nuevas = {c: meta.get(c) for c in COLUMNAS_NUEVAS}      # campos a nivel de video
    for fila in filas:
        fila.update(nuevas)
    fila_seq.update(nuevas)
    escribir_features_frame(carpeta / "features.csv", filas)
    escribir_features_seq(carpeta / "features_seq.csv", fila_seq)

    # Rutas de los frames relativas a la base de salida (con carpeta_destino, a esa carpeta).
    base_rel = carpeta if carpeta_destino is not None else Path(dir_salida)
    rel = [Path(p).relative_to(base_rel).as_posix() for p in rutas]
    meta_json = dict(meta)
    meta_json.update(video_id=video_id, clase=clase, archivo=video_path.name,
                     n_seq=n_seq, img_size=img_size, indices_clave=idx,
                     rutas_frames=rel)
    with open(carpeta / "meta.json", "w", encoding="utf-8") as f:
        json.dump(meta_json, f, indent=2, ensure_ascii=False)

    res = {"video_id": video_id, "clase": clase, "carpeta": carpeta, "meta": meta_json,
           "senal": senal, "indices_clave": idx, "rutas_frames": rutas,
           "video_path": video_path}
    guardar_debug_png(carpeta / "debug.png", res)
    prog(1.0)
    logger.info("%s/%s: intervalo [%d, %d] (%.2fs) ok=%s motivo=%s", clase, video_id, ini, fin,
                meta["duracion_intervalo_s"], meta["deteccion_ok"], meta["motivo_fallo"])
    return res


def registrar_error(video_path, clase: str, dir_salida, exc: Exception) -> dict:
    """Marca un video como fallido (``error_procesamiento``) y lo deja en disco."""
    video_path = Path(video_path)
    carpeta = carpeta_video(dir_salida, clase, video_path)
    carpeta.mkdir(parents=True, exist_ok=True)
    meta = {"video_id": video_path.stem, "clase": clase, "archivo": video_path.name,
            "deteccion_ok": False, "motivo_fallo": "error_procesamiento",
            "error": f"{type(exc).__name__}: {exc}"}
    with open(carpeta / "meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    from .calculador_features import COLUMNAS_SEQ
    fila = {c: None for c in COLUMNAS_SEQ}
    fila.update(video_id=video_path.stem, clase=clase, n_seq=None, deteccion_ok=False,
                motivo_fallo="error_procesamiento")
    escribir_features_seq(carpeta / "features_seq.csv", fila)
    return meta


def cargar_resultado_existente(video_path, clase: str, cfg: dict,
                               dir_salida=DIR_SALIDA) -> Optional[dict]:
    """Reconstruye el resultado de un video ya procesado sin recalcular poses ni
    frames (usa ``poses.npz`` + ``meta.json``). ``None`` si falta algo."""
    video_path = Path(video_path)
    carpeta = carpeta_video(dir_salida, clase, video_path)
    ruta_meta = carpeta / "meta.json"
    if not ruta_meta.exists():
        return None
    datos = _cargar_cache(carpeta, _firma(video_path, cfg))
    if datos is None:
        return None
    with open(ruta_meta, "r", encoding="utf-8") as f:
        meta_json = json.load(f)
    if meta_json.get("motivo_fallo") == "error_procesamiento" or "inicio" not in meta_json:
        return None
    r, _ = _analizar(clase, datos, cfg)
    rutas = [str(Path(dir_salida) / p) for p in meta_json.get("rutas_frames", [])]
    if not rutas or not all(Path(p).exists() for p in rutas):
        return None
    return {"video_id": video_path.stem, "clase": clase, "carpeta": carpeta,
            "meta": meta_json, "senal": r["senal"],
            "indices_clave": meta_json.get("indices_clave", []),
            "rutas_frames": rutas, "video_path": video_path}


# ------------------------------------------------------------------- por lote
def procesar_lote(videos: List[Tuple[str, Path]], cfg: dict, dir_salida=DIR_SALIDA,
                  progreso_cb: Optional[Callable[[float, str], None]] = None,
                  cancelar: Optional[Callable[[], bool]] = None) -> dict:
    """Procesa varios videos de forma independiente (un fallo no detiene el lote).

    Debe ejecutarse en el hilo que lo usará: crea ahí su propio anonimizador.

    Returns:
        dict con ``resultados`` (lista de meta), ``cancelado`` (bool).
    """
    anon = crear_anonimizador(cfg["confianza_mediapipe"])   # RuntimeError si no hay detector
    resultados, cancelado = [], False
    n = len(videos)
    try:
        for i, (clase, ruta) in enumerate(videos):
            if cancelar and cancelar():
                cancelado = True
                break
            etiqueta = f"[{i + 1}/{n}] {clase}/{ruta.name}"
            logger.info("Procesando %s", etiqueta)

            def cb(f, i=i, etiqueta=etiqueta):
                if progreso_cb:
                    progreso_cb((i + f) / n, etiqueta)
            try:
                res = procesar_video(ruta, clase, cfg, dir_salida, anon, cb, cancelar)
                resultados.append(res["meta"])
            except Cancelado:
                cancelado = True
                logger.info("Cancelado por el usuario durante %s", etiqueta)
                break
            except Exception as exc:  # noqa: BLE001
                logger.exception("Error procesando %s", etiqueta)
                resultados.append(registrar_error(ruta, clase, dir_salida, exc))
            if progreso_cb:
                progreso_cb((i + 1) / n, etiqueta)
    finally:
        anon.cerrar()
    try:
        consolidar(dir_salida)
    except Exception as exc:  # noqa: BLE001
        logger.warning("No se pudieron consolidar los CSV: %s", exc)
    return {"resultados": resultados, "cancelado": cancelado}


# --------------------------------------------------------------------- resumen
def resumen_metas(metas: List[dict]) -> dict:
    """Totales a partir de una lista de metas."""
    por_motivo: Dict[str, int] = {}
    for m in metas:
        if not m.get("deteccion_ok", False):
            k = m.get("motivo_fallo") or "desconocido"
            por_motivo[k] = por_motivo.get(k, 0) + 1
    fallos = sum(por_motivo.values())
    return {"procesados": len(metas), "ok": len(metas) - fallos,
            "fallos": fallos, "por_motivo": por_motivo}


def resumen_salida(dir_salida=DIR_SALIDA) -> dict:
    """Resumen de TODO lo que hay en ``datos_salida/frames``."""
    metas = []
    for p in sorted((Path(dir_salida) / "frames").glob("*/*/meta.json")):
        try:
            with open(p, "r", encoding="utf-8") as f:
                metas.append(json.load(f))
        except Exception as exc:  # noqa: BLE001
            logger.warning("meta.json ilegible %s: %s", p, exc)
    return resumen_metas(metas)


def texto_resumen(r: dict) -> str:
    lineas = [f"Videos procesados: {r['procesados']}",
              f"  con deteccion_ok=True:  {r['ok']}",
              f"  con deteccion_ok=False: {r['fallos']}"]
    for motivo, c in sorted(r["por_motivo"].items()):
        lineas.append(f"      · {motivo}: {c}")
    return "\n".join(lineas)
