"""Detección automática del intervalo del ejercicio por clase.

Contiene dos partes:

1. ``extraer_poses``: recorre un video con MediaPipe Pose y devuelve los
   landmarks de cada frame (filas NaN donde no hubo detección).
2. ``detectar_intervalo`` / ``analizar_video``: reglas de negocio por clase
   (abdominales, pesas, salto, elasticidad) más reglas de fallback.

Todos los umbrales se leen de ``config.json``.
"""
import logging
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import warnings

import cv2
import numpy as np
from scipy.signal import find_peaks

from . import cargar_config
from .calculador_features import (
    angulos_serie, ancho_hombros_serie, energia_por_frame,
    interpolar_poses, media_movil, y_cadera_media_serie,
)

warnings.filterwarnings("ignore", message="All-NaN slice encountered", category=RuntimeWarning)

logger = logging.getLogger(__name__)

CLASES_CICLICAS = ("abdominales", "pesas")
CLASES_CONOCIDAS = ("abdominales", "pesas", "salto", "elasticidad")

_MOTIVO_NO_DISCRIMINA = {
    "abdominales": "sin_picos", "pesas": "sin_picos",
    "salto": "sin_salto", "elasticidad": "sin_estiramiento",
}


class Cancelado(Exception):
    """El usuario canceló el procesamiento."""


# =========================================================== poses (MediaPipe)
def ruta_poses_sinteticas(video_path) -> Path:
    """Ruta del archivo auxiliar de poses que crea generar_videos_sinteticos.py."""
    return Path(video_path).with_suffix(".poses.npz")


def extraer_poses(video_path, cfg: Optional[dict] = None,
                  progreso_cb: Optional[Callable[[float], None]] = None,
                  cancelar: Optional[Callable[[], bool]] = None) -> dict:
    """Extrae los landmarks de MediaPipe Pose de todos los frames de un video.

    Returns:
        dict con ``poses`` (n,33,4; NaN si no hubo pose), ``fps``, ``ancho``,
        ``alto`` (px) y ``n_frames``.

    Notas:
        * Si junto al video existe ``<video>.poses.npz`` (solo lo crea el
          generador de videos sintéticos) y ``usar_poses_sinteticas`` es true,
          se usan esas poses en lugar de MediaPipe, porque MediaPipe no detecta
          figuras de palitos. Los videos reales nunca tienen ese archivo.
        * Crea su propia instancia de Pose (MediaPipe no es thread-safe).
    """
    cfg = cfg or cargar_config()
    video_path = Path(video_path)
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise IOError(f"No se pudo abrir el video: {video_path}")
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    fps_cfg = cfg.get("fps_para_frames", "auto")      # "auto" = leer del video
    if fps_cfg != "auto":
        try:
            fps = float(fps_cfg)
        except (TypeError, ValueError):
            logger.warning("fps_para_frames inválido (%r); se usa el del video", fps_cfg)
    if not np.isfinite(fps) or fps < 1.0:
        logger.warning("%s: FPS inválido (%s); se asume 30", video_path.name, fps)
        fps = 30.0
    ancho = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    alto = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    n_est = max(1, int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 1))

    lado_aux = ruta_poses_sinteticas(video_path)
    if cfg.get("usar_poses_sinteticas", True) and lado_aux.exists():
        cap.release()
        poses = np.load(lado_aux)["poses"].astype(float)
        logger.info("%s: usando poses sintéticas (%s)", video_path.name, lado_aux.name)
        if progreso_cb:
            progreso_cb(1.0)
        return {"poses": poses, "fps": fps, "ancho": ancho, "alto": alto,
                "n_frames": int(poses.shape[0])}

    try:
        import mediapipe as mp
        mp_pose = mp.solutions.pose
    except Exception as exc:  # noqa: BLE001
        cap.release()
        raise RuntimeError(
            "MediaPipe Pose no está disponible (se requiere mediapipe 0.10.x "
            f"con mp.solutions, p. ej. mediapipe==0.10.9). Detalle: {exc}") from exc

    pose = mp_pose.Pose(
        static_image_mode=False, model_complexity=int(cfg["complejidad_pose"]),
        smooth_landmarks=True,
        min_detection_confidence=float(cfg["confianza_mediapipe"]),
        min_tracking_confidence=float(cfg["confianza_mediapipe"]))
    lado = int(cfg["max_lado_procesamiento"])
    lista: List[np.ndarray] = []
    vacio = np.full((33, 4), np.nan)
    try:
        i = 0
        while True:
            if cancelar and cancelar():
                raise Cancelado()
            ok, frame = cap.read()
            if not ok:
                break
            h, w = frame.shape[:2]
            if max(h, w) > lado:
                s = lado / float(max(h, w))
                frame = cv2.resize(frame, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)
            res = pose.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            if res.pose_landmarks:
                lista.append(np.array([[l.x, l.y, l.z, l.visibility]
                                       for l in res.pose_landmarks.landmark], dtype=float))
            else:
                lista.append(vacio.copy())
            i += 1
            if progreso_cb and (i % 10 == 0):
                progreso_cb(min(1.0, i / n_est))
    finally:
        pose.close()
        cap.release()
    if not lista:
        raise IOError(f"No se pudo leer ningún frame de {video_path}")
    if progreso_cb:
        progreso_cb(1.0)
    return {"poses": np.stack(lista), "fps": fps, "ancho": ancho, "alto": alto,
            "n_frames": len(lista)}


# ================================================================ detección
def _py(v):
    """Convierte tipos numpy a tipos nativos (para JSON)."""
    if isinstance(v, (np.bool_,)):
        return bool(v)
    if isinstance(v, np.integer):
        return int(v)
    if isinstance(v, np.floating):
        return None if not np.isfinite(v) else float(v)
    if isinstance(v, float) and not np.isfinite(v):
        return None
    if isinstance(v, dict):
        return {k: _py(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_py(x) for x in v]
    return v


def _detectar_ciclico(energia_s, fps, cfg):
    """abdominales / pesas: picos de energía suavizada."""
    n = energia_s.size
    umbral = float(energia_s.mean() + cfg["k_umbral_picos"] * energia_s.std())
    dist = max(1, int(round(cfg["distancia_minima_picos_s"] * fps)))
    picos, _ = find_peaks(energia_s, prominence=umbral, distance=dist)
    extra = {"n_repeticiones": int(len(picos)), "picos_idx": [int(p) for p in picos],
             "umbral_prominencia_picos": umbral, "tipo_evento": "ciclico"}
    if len(picos) == 0:
        return 0, n - 1, "sin_picos", extra, {"umbrales": [(umbral, "prominencia")]}
    margen = int(round(cfg["margen_inicio_fin_s"] * fps))
    ini = max(0, int(picos[0]) - margen)
    fin = min(n - 1, int(picos[-1]) + margen)
    return ini, fin, None, extra, {"umbrales": []}


# ---------------------------------------------------------------- utilidades v2
_DEF = {
    # Parámetros nuevos (ver config.json / README). Valores por defecto si faltan.
    "parada_dura_elasticidad_s": 6.0, "umbral_cadera_x_salto": 0.15,
    "cambio_tronco_salto": 1.6, "umbral_visibilidad_rodilla": 0.5,
    "umbral_ancho_hombros_frontal": 0.15, "umbral_ancho_hombros_perfil": 0.08,
    "union_huecos_meseta_s": 0.5, "percentil_meseta_elasticidad": 90,
    "umbral_meseta_elasticidad": 0.5, "fps_para_frames": "auto",
    "suavizado_salto": 3, "prominencia_flexion_rodilla_grados": 15.0,
    "coherencia_max_salto_s": 0.3, "ventana_ref_tronco_s": 2.0,
    "union_descartes_persona_s": 1.0, "duracion_min_salto_s": 0.25,
    "duracion_max_salto_s": 2.5, "max_fraccion_descartados_salto": 0.1,
    "sostenido_fin_elasticidad_s": 0.5, "ratio_ambiguedad_elasticidad": 0.6,
    "estiramiento_minimo_s": 0.5, "min_frames_orientacion": 10,
    "percentil_energia_aterrizaje": 60, "ventana_confirmacion_rodilla_s": 0.25, "duracion_minima_salto_s": 0.5,
    "margen_adulto_s": 0.2, "umbral_rom_inicio_elasticidad": 0.30,
    "sostenido_inicio_elasticidad_s": 0.7, "umbral_tronco_adulto": [0.625, 1.6],
    "umbral_y_cadera_adulto": 0.12, "umbral_x_cadera_adulto": 0.07,
    "duracion_min_adulto_s": 0.2,
}


def _p(cfg: dict, clave: str):
    return cfg[clave] if clave in cfg else _DEF[clave]


def _tramos(mascara: np.ndarray) -> List[List[int]]:
    """Tramos ``[ini, fin]`` (inclusivos) donde ``mascara`` es True."""
    out: List[List[int]] = []
    ini = None
    for i, v in enumerate(mascara):
        if v and ini is None:
            ini = i
        elif not v and ini is not None:
            out.append([ini, i - 1])
            ini = None
    if ini is not None:
        out.append([ini, len(mascara) - 1])
    return out


def _unir_tramos(tramos: List[List[int]], hueco: int) -> List[List[int]]:
    """Une tramos separados por menos de ``hueco`` frames."""
    out: List[List[int]] = []
    for t in tramos:
        if out and t[0] - out[-1][1] - 1 < hueco:
            out[-1][1] = t[1]
        else:
            out.append(list(t))
    return out


def _orientacion(P, mascara, aspecto, cfg) -> str:
    """frontal / perfil / mixta / desconocida por la MEDIANA del ancho de hombros
    (frames con visibilidad de ambos hombros > umbral) dentro de ``mascara``."""
    ok = mascara & ~np.isnan(P[:, 0, 0])
    ok &= (np.nan_to_num(P[:, 11, 3]) > 0.5) & (np.nan_to_num(P[:, 12, 3]) > 0.5)
    if ok.sum() < int(_p(cfg, "min_frames_orientacion")):
        return "desconocida"
    w = float(np.median(ancho_hombros_serie(P[ok], aspecto)))
    if w > _p(cfg, "umbral_ancho_hombros_frontal"):
        return "frontal"
    if w < _p(cfg, "umbral_ancho_hombros_perfil"):
        return "perfil"
    return "mixta"


# ------------------------------------------------------------------- salto v2
def _persona_correcta(P, valida, aspecto, fps, cfg) -> np.ndarray:
    """Máscara de frames DESCARTADOS por no ser (con seguridad) el estudiante.

    Se descarta un frame si: no hay pose; el tronco (cadera_media–hombro_medio)
    mide más de ``cambio_tronco_salto``× (o menos de 1/×) la referencia (mediana
    de los primeros ``ventana_ref_tronco_s`` s); o la x de la cadera salta más de
    ``umbral_cadera_x_salto`` respecto al frame válido anterior. Los tramos
    descartados separados por menos de ``union_descartes_persona_s`` se unen.
    """
    n = P.shape[0]
    hom = (P[:, 11, :2] + P[:, 12, :2]) / 2
    cad = (P[:, 23, :2] + P[:, 24, :2]) / 2
    tr = np.linalg.norm((hom - cad) * [aspecto, 1.0], axis=1)
    nref = max(2, int(_p(cfg, "ventana_ref_tronco_s") * fps))
    ref = np.nanmedian(np.where(valida[:nref], tr[:nref], np.nan))
    if not np.isfinite(ref):
        ref = np.nanmedian(tr)
    k = float(_p(cfg, "cambio_tronco_salto"))
    with np.errstate(invalid="ignore"):
        r = tr / max(ref, 1e-6)
        malo = ~valida | (r > k) | (r < 1.0 / k)
    iv = np.where(valida)[0]
    if len(iv) > 1:
        dx = np.abs(np.diff(cad[iv, 0]))
        malo[iv[1:][dx > _p(cfg, "umbral_cadera_x_salto")]] = True
    tramos = _unir_tramos(_tramos(malo), int(_p(cfg, "union_descartes_persona_s") * fps))
    out = np.zeros(n, dtype=bool)
    for a, b in tramos:
        out[a:b + 1] = True
    return out


def _detectar_salto(P, valida, fps, cfg, aspecto, alto_px):
    """Salto de perfil o de frente. Estructura por la CADERA, rodilla = confirmación.

    1) Se descartan frames de "otra persona".  2) Señales: y_cadera_media (ventana
    ``suavizado_salto``), energía vertical y ángulo de la rodilla de la pierna más
    visible. 3) Estructura: máximo de y_cadera (agachada) → mínimo (punto más alto)
    → siguiente máximo (aterrizaje); se elige la secuencia con mayor subida.
    4) Confirmación: un valle de rodilla (prominencia >= ``prominencia_flexion_rodilla_grados``)
    a menos de ``ventana_confirmacion_rodilla_s`` de la agachada o del aterrizaje.
    ``coherencia_salto`` = distancia (s) entre el pico de cadera y el extremo de rodilla
    (valle o pico) más cercano dentro del salto; debe ser <= ``coherencia_max_salto_s``.
    inicio = agachada - margen; fin = aterrizaje + margen.
    """
    n = P.shape[0]
    desc = _persona_correcta(P, valida, aspecto, fps, cfg)
    buenos = ~desc
    extra = {"tipo_evento": "salto_unico", "altura_salto_px": None, "altura_salto_norm": None,
             "frame_pico": None, "frame_aterrizaje": None, "frame_despegue": None,
             "rom_rodilla_pico": None, "energia_vertical_pico": None, "coherencia_salto": None,
             "persona_correcta_frames_descartados": int(desc.sum()),
             "firma_salto_valida": False, "pierna_referencia": None}
    senal = {"umbrales": [], "descartados": desc, "buenos": buenos, "marcas": [], "extras": []}
    if buenos.sum() < 10:
        return 0, n - 1, "pose_insuficiente", extra, senal, np.zeros(n)

    Pc = P.copy()
    Pc[desc] = np.nan
    Pi, _ = interpolar_poses(Pc)
    w = int(_p(cfg, "suavizado_salto"))
    yc = media_movil(y_cadera_media_serie(Pi), w)
    anch = ancho_hombros_serie(Pi, aspecto)
    ref_w = max(float(np.median(anch[buenos])), 1e-3)
    dy = np.abs(np.diff(Pi[:, :, 1], axis=0)).sum(axis=1) / ref_w
    ev = media_movil(np.concatenate([[dy[0]], dy]), w)
    ev[desc] = 0.0

    # Rodilla: pierna con mayor visibilidad media (en perfil, la delantera)
    izq = float(np.nanmean(P[buenos, 25, 3])) >= float(np.nanmean(P[buenos, 26, 3]))
    idx_r, nombre = (25, "angulo_rodilla_izq") if izq else (26, "angulo_rodilla_der")
    extra["pierna_referencia"] = "izq" if izq else "der"
    ok_r = buenos & (np.nan_to_num(P[:, idx_r, 3]) > float(_p(cfg, "umbral_visibilidad_rodilla")))
    t = np.arange(n)
    if ok_r.sum() < max(10, 0.2 * n):
        return 0, n - 1, "sin_salto", extra, senal, yc
    ang = angulos_serie(Pi, aspecto)[nombre]
    rod = media_movil(np.interp(t, t[ok_r], ang[ok_r]), int(cfg["suavizado_energia"]))
    senal["extras"] = [("energía vertical", ev), ("rom rodilla (°)", rod)]

    prom = float(_p(cfg, "prominencia_flexion_rodilla_grados"))
    d_min = int(_p(cfg, "duracion_min_salto_s") * fps)
    d_max = int(_p(cfg, "duracion_max_salto_s") * fps)
    alt_min = float(cfg["altura_minima_salto"])
    maximos = [int(x) for x in find_peaks(yc, prominence=alt_min)[0] if buenos[x]]

    mejor, mejor_sin_aterr = None, None
    for a in maximos:
        for b in maximos:
            if not (d_min <= b - a <= d_max) or desc[a:b + 1].mean() > _p(cfg, "max_fraccion_descartados_salto"):
                continue
            pico = a + int(np.argmin(yc[a:b + 1]))
            subida = float(yc[a] - yc[pico])
            if subida < alt_min or pico in (a, b):
                continue
            if mejor is None or subida > mejor["subida"]:
                mejor = dict(a=a, b=b, pico=pico, subida=subida)
        fin_b = min(n, a + d_max)                    # ¿subida sin máximo posterior?
        if fin_b - a > d_min:
            pico = a + int(np.argmin(yc[a:fin_b]))
            subida = float(yc[a] - yc[pico])
            if pico > a and subida >= alt_min and not any(pico < m_ <= fin_b for m_ in maximos):
                if mejor_sin_aterr is None or subida > mejor_sin_aterr["subida"]:
                    mejor_sin_aterr = dict(a=a, pico=pico, subida=subida)

    if mejor is None:
        if mejor_sin_aterr is not None:
            c = mejor_sin_aterr
            pl = np.where(buenos & (ev > np.percentile(ev[buenos], _p(cfg, "percentil_energia_aterrizaje"))))[0]
            pl = pl[pl > c["pico"]]
            extra.update(frame_pico=c["pico"], frame_despegue=c["a"],
                         frame_aterrizaje=int(pl[-1]) if len(pl) else None,
                         energia_vertical_pico=float(ev[c["a"]:].max()))
            senal["marcas"] = [(c["a"], yc[c["a"]], "agachada"), (c["pico"], yc[c["pico"]], "pico_y")]
            return 0, n - 1, "sin_aterrizaje", extra, senal, yc
        return 0, n - 1, "sin_salto", extra, senal, yc

    a, b, pico = mejor["a"], mejor["b"], mejor["pico"]
    # extremo de rodilla (valle o pico con prominencia suficiente) más cercano al pico de cadera
    ext_pts = [int(x) for x in np.concatenate([find_peaks(-rod, prominence=prom)[0],
                                               find_peaks(rod, prominence=prom)[0]]) if a <= x <= b]
    t_rod = min(ext_pts, key=lambda x: abs(x - pico)) if ext_pts else None
    coh = abs(t_rod - pico) / fps if t_rod is not None else None
    vent = int(_p(cfg, "ventana_confirmacion_rodilla_s") * fps)
    valles = [int(x) for x in find_peaks(-rod, prominence=prom)[0] if buenos[x]]
    confirma = any(abs(v - a) <= vent or abs(v - b) <= vent for v in valles)
    extra.update(
        frame_pico=pico, frame_despegue=a, frame_aterrizaje=b,
        altura_salto_norm=float(yc[b] - yc[pico]), altura_salto_px=float((yc[b] - yc[pico]) * alto_px),
        rom_rodilla_pico=float(rod[t_rod]) if t_rod is not None else None,
        energia_vertical_pico=float(ev[a:b + 1].max()),
        coherencia_salto=float(coh) if coh is not None else None)
    senal["marcas"] = [(a, yc[a], "agachada"), (pico, yc[pico], "pico_y"), (b, yc[b], "aterrizaje")]
    if t_rod is not None:
        senal["marcas"].append((t_rod, rod[t_rod], "rodilla"))
    if not confirma or coh is None or coh > _p(cfg, "coherencia_max_salto_s"):
        return 0, n - 1, "salto_incoherente", extra, senal, yc
    margen = int(round(cfg["margen_inicio_fin_s"] * fps))
    extra["firma_salto_valida"] = True
    return max(0, a - margen), min(n - 1, b + margen), None, extra, senal, yc


# ------------------------------------------------------------ elasticidad v2
def _detectar_adulto(Pi, aspecto, fps, cfg):
    """Entrada del adulto por DESVIACIÓN respecto a una referencia del inicio del video.

    Un frame cuenta como «adulto» si se cumplen al menos 2 de 3 condiciones:
    tronco (cadera_media–hombro_medio) fuera de ``umbral_tronco_adulto`` × la referencia,
    |y_cadera − y_ref| > ``umbral_y_cadera_adulto``, |x_cadera − x_ref| > ``umbral_x_cadera_adulto``.
    (La comparación entre frames consecutivos no sirve: a 60 fps el adulto entra en ~10-20 frames.)
    Referencia = mediana de los primeros 2 s (0.1·n frames si el video es corto).

    Returns:
        (frame_adulto_inicio o None, máscara de frames de adulto)
    """
    n = Pi.shape[0]
    hom = (Pi[:, 11, :2] + Pi[:, 12, :2]) / 2
    cad = (Pi[:, 23, :2] + Pi[:, 24, :2]) / 2
    tr = np.linalg.norm((hom - cad) * [aspecto, 1.0], axis=1)
    nref = max(10, min(int(2.0 * fps), int(0.1 * n)))
    ref_t, ref_y, ref_x = (np.median(tr[:nref]), np.median(cad[:nref, 1]), np.median(cad[:nref, 0]))
    lo, hi = _p(cfg, "umbral_tronco_adulto")
    r = tr / max(ref_t, 1e-6)
    cnt = (((r > hi) | (r < lo)).astype(int)
           + (np.abs(cad[:, 1] - ref_y) > _p(cfg, "umbral_y_cadera_adulto"))
           + (np.abs(cad[:, 0] - ref_x) > _p(cfg, "umbral_x_cadera_adulto")))
    min_len = max(2, int(_p(cfg, "duracion_min_adulto_s") * fps))
    tramos = [t for t in _tramos(cnt >= 2) if t[1] - t[0] + 1 >= min_len]
    mascara = np.zeros(n, dtype=bool)
    for a_, b_ in tramos:
        mascara[a_:b_ + 1] = True
    return (int(tramos[0][0]) if tramos else None), mascara


def _inicio_sostenido(rom_s, desde, hasta, umbral, sost):
    """Primer frame en [desde, hasta] desde el que el ROM se mantiene > umbral ``sost`` frames."""
    for j in range(desde, max(desde, hasta - sost + 1) + 1):
        v = rom_s[j:j + sost]
        if v.size >= sost and (v > umbral).all():
            return j
    return None


def _detectar_elasticidad(Pi, aspecto, fps, cfg):
    """Elasticidad v4 (protocolo: el adulto entra DESPUÉS del estiramiento).

    * Se detecta la entrada del adulto (``_detectar_adulto``).
    * Con adulto: pico = máximo del ROM en [0, adulto − margen_adulto_s];
      inicio = primer frame con ROM > ``umbral_rom_inicio_elasticidad``·pico durante
      ``sostenido_inicio_elasticidad_s``; fin = adulto − margen_adulto_s.
    * Sin adulto: el pico se toma en la meseta dominante del ROM (tramo más largo
      > ``umbral_meseta_elasticidad``·p``percentil_meseta_elasticidad``; no el máximo global,
      que puede ser un pico de un solo movimiento); inicio igual que arriba; fin = primer
      frame con ROM < 20 % del nivel de la meseta durante ``sostenido_fin_elasticidad_s``
      (sin pasar de ``parada_dura_elasticidad_s`` ni del inicio de otra subida); si no
      hay cruce sostenido, fin = final de la meseta (cruce del 50 %).
    """
    n = Pi.shape[0]
    ang = angulos_serie(Pi, aspecto)
    cadera = np.nanmean(np.vstack([ang["angulo_cadera_izq"], ang["angulo_cadera_der"]]), axis=0)
    tronco = ang["angulo_tronco"]
    nb = max(1, min(int(cfg["frames_baseline"]), n))
    b_t, b_c = np.nanmedian(tronco[:nb]), np.nanmedian(cadera[:nb])
    rom = np.nan_to_num(np.abs(tronco - b_t) + np.abs(cadera - b_c))
    rom_s = media_movil(rom, cfg["suavizado_energia"])
    m = float(rom_s.max())
    adulto_ini, mask_ad = _detectar_adulto(Pi, aspecto, fps, cfg)
    extra = {"tipo_evento": "estiramiento_unico", "rom_maximo": m, "rom_pico": None,
             "duracion_estiramiento_s": None, "nivel_meseta_elasticidad": None,
             "fin_criterio": None, "pico_estiramiento": None,
             "adulto_detectado": adulto_ini is not None, "frame_adulto_inicio": adulto_ini}
    senal = {"umbrales": [], "marcas": [], "meseta": None, "nivel_meseta": None,
             "descartados": mask_ad}
    if adulto_ini is not None:
        senal["marcas"].append((adulto_ini, rom_s[adulto_ini], "adulto"))
    if m < cfg["rom_minimo_elasticidad_grados"]:
        return 0, n - 1, "sin_estiramiento", extra, senal, rom_s

    sost_ini = max(1, int(_p(cfg, "sostenido_inicio_elasticidad_s") * fps))
    umb_ini = float(_p(cfg, "umbral_rom_inicio_elasticidad"))
    sost_fin = max(1, int(_p(cfg, "sostenido_fin_elasticidad_s") * fps))

    if adulto_ini is not None:
        margen = int(round(_p(cfg, "margen_adulto_s") * fps))
        fin = adulto_ini - margen
        if fin < int(_p(cfg, "estiramiento_minimo_s") * fps):
            return 0, n - 1, "adulto_en_intervalo", extra, senal, rom_s
        pico = int(np.argmax(rom_s[:fin + 1]))
        rom_pico = float(rom_s[pico])
        ini = _inicio_sostenido(rom_s, 0, fin, umb_ini * rom_pico, sost_ini)
        criterio = "pre_adulto"
        nivel_ref = rom_pico
    else:
        p = float(np.percentile(rom_s, _p(cfg, "percentil_meseta_elasticidad")))
        umbral = _p(cfg, "umbral_meseta_elasticidad") * p
        tramos = _unir_tramos(_tramos(rom_s > umbral), int(_p(cfg, "union_huecos_meseta_s") * fps))
        if not tramos:
            return 0, n - 1, "sin_estiramiento", extra, senal, rom_s
        orden = sorted(tramos, key=lambda t: t[1] - t[0], reverse=True)
        a, b = orden[0]
        nivel = float(np.median(rom_s[a:b + 1]))
        pico = a + int(np.argmax(rom_s[a:b + 1]))
        rom_pico = float(rom_s[pico])
        ini = _inicio_sostenido(rom_s, 0, b, umb_ini * rom_pico, sost_ini)
        bajo = cfg["umbral_rom_elasticidad_bajo"] * nivel
        limite = min(n - 1, b + int(_p(cfg, "parada_dura_elasticidad_s") * fps))
        sig = [t[0] for t in tramos if t[0] > b]       # otra subida de ROM = otro movimiento
        if sig:
            limite = min(limite, min(sig) - 1)
        fin, criterio = None, None
        for j in range(b, limite + 1):
            v = rom_s[j:j + sost_fin]
            if v.size >= sost_fin and (v < bajo).all():
                fin, criterio = j, "cruce_20"
                break
        if fin is None:
            fin, criterio = b, "cruce_50"
        extra.update(meseta_inicio=int(a), meseta_fin=int(b), n_mesetas_candidatas=len(tramos))
        senal.update(meseta=(a, b), nivel_meseta=nivel, umbrales=[(bajo, "20% del nivel")])
        nivel_ref = nivel
        if len(orden) > 1:
            l1, l2 = orden[0][1] - orden[0][0], orden[1][1] - orden[1][0]
            extra["_ambiguo"] = l2 >= _p(cfg, "ratio_ambiguedad_elasticidad") * l1

    senal["marcas"].append((pico, rom_s[pico], "pico"))
    senal["umbrales"] = senal["umbrales"] + [(umb_ini * rom_pico, "20% del pico (inicio)")]
    extra.update(rom_pico=rom_pico, pico_estiramiento=int(pico), fin_criterio=criterio)
    if ini is None:
        return 0, n - 1, "sin_estiramiento", extra, senal, rom_s
    extra["nivel_meseta_elasticidad"] = float(nivel_ref if adulto_ini is None else np.median(rom_s[ini:fin + 1]))
    extra["duracion_estiramiento_s"] = (fin - ini + 1) / fps
    if extra.pop("_ambiguo", False):
        return 0, n - 1, "estiramiento_ambiguo", extra, senal, rom_s
    extra.pop("_ambiguo", None)
    if (fin - ini + 1) / fps < _p(cfg, "estiramiento_minimo_s"):
        return 0, n - 1, "estiramiento_muy_corto", extra, senal, rom_s
    if not (ini <= pico <= fin):
        return 0, n - 1, "estiramiento_incoherente", extra, senal, rom_s
    return ini, fin, None, extra, senal, rom_s


def analizar_video(clase: str, pose_por_frame, fps: float, cfg: Optional[dict] = None,
                   aspecto: float = 1.0, alto_px: float = 1.0) -> dict:
    """Detección completa: intervalo, meta y señales auxiliares para el visor.

    Returns:
        dict con ``inicio``, ``fin``, ``meta`` y ``senal`` (arrays para dibujar).
    """
    cfg = cfg or cargar_config()
    clase = str(clase).lower()
    if clase not in CLASES_CONOCIDAS:
        raise ValueError(f"Clase desconocida: {clase!r} (válidas: {CLASES_CONOCIDAS})")
    P = np.stack(pose_por_frame) if not isinstance(pose_por_frame, np.ndarray) \
        else pose_por_frame
    P = P.astype(float)
    n = P.shape[0]
    fps = float(fps) if fps and fps > 0 else 30.0
    w = int(cfg["suavizado_energia"])

    Pi, valida = interpolar_poses(P)
    ancho_h = ancho_hombros_serie(Pi, aspecto) if valida.any() else np.zeros(n)
    ancho_ref = float(np.median(ancho_h[valida])) if valida.any() else 1.0
    ancho_ref = max(ancho_ref, 1e-3)
    energia = energia_por_frame(Pi, aspecto, ancho_ref) if valida.any() else np.zeros(n)
    energia_s = media_movil(energia, w)
    yc = y_cadera_media_serie(Pi) if valida.any() else np.zeros(n)
    yc_s = media_movil(yc, w)

    # ---- frames sospechosos de "adulto" (regla barata) ----
    sosp = np.zeros(n, dtype=bool)
    if n > 1 and valida.any():
        par = valida[1:] & valida[:-1]
        prev = np.maximum(ancho_h[:-1], 1e-6)
        cambio_w = np.abs(ancho_h[1:] - ancho_h[:-1]) / prev
        cambio_y = np.abs(yc[1:] - yc[:-1])
        sosp[1:] = par & ((cambio_w > cfg["cambio_ancho_hombros_adulto"])
                          | (cambio_y > cfg["cambio_y_cadera_adulto"]))

    ini, fin, motivo = 0, n - 1, None
    extra: dict = {}
    senal_extra: dict = {"umbrales": []}
    senal_nombre, senal_vals = "energía (suavizada)", energia_s

    if n / fps < cfg["duracion_minima_intervalo_s"]:
        motivo = "video_corto"
    elif valida.sum() < 2:
        motivo = "pose_insuficiente"
    else:
        if clase in CLASES_CICLICAS:
            ini, fin, motivo, extra, senal_extra = _detectar_ciclico(energia_s, fps, cfg)
        elif clase == "salto":
            ini, fin, motivo, extra, senal_extra, y_salto = _detectar_salto(
                P, valida, fps, cfg, aspecto, alto_px)
            senal_nombre, senal_vals = "y cadera media (suavizada)", y_salto
        else:
            ini, fin, motivo, extra, senal_extra, rom_s = _detectar_elasticidad(Pi, aspecto, fps, cfg)
            senal_nombre, senal_vals = "ROM instantáneo (°, suavizado)", rom_s

    # ---- reglas de fallback generales ----
    if motivo is None:
        dur = (fin - ini + 1) / fps
        dur_min = _p(cfg, "duracion_minima_salto_s") if clase == "salto" \
            else cfg["duracion_minima_intervalo_s"]      # un salto real dura < 1 s
        if dur < dur_min:
            motivo = "video_corto"
        elif (fin - ini + 1) > cfg["fraccion_maxima_intervalo"] * n:
            motivo = _MOTIVO_NO_DISCRIMINA[clase]   # no discrimina: cubre ~todo el video
        elif (1.0 - valida[ini:fin + 1].mean()) > cfg["fraccion_minima_pose"]:
            motivo = "pose_insuficiente"
    if motivo is not None:
        ini, fin = 0, n - 1

    # ---- meta ----
    seg_valido = valida[ini:fin + 1]
    vis_frame = np.where(valida, np.nan_to_num(P[:, :, 3]).mean(axis=1), np.nan)
    vis_seg = vis_frame[ini:fin + 1]
    vis_min = float(np.nanmin(vis_seg)) if seg_valido.any() else 0.0
    meta = {
        "duracion_video_s": n / fps, "fps": fps, "n_frames_originales": n,
        "ancho_px": None, "alto_px": None, "aspecto": float(aspecto),
        "inicio": int(ini), "fin": int(fin),
        "inicio_s": ini / fps, "fin_s": fin / fps,
        "duracion_intervalo_s": (fin - ini + 1) / fps,
        "visibilidad_min_intervalo": vis_min,
        "adulto_sospechoso": bool(sosp[ini + 1:fin + 1].any()) if fin > ini else False,
        "deteccion_ok": motivo is None, "motivo_fallo": motivo,
        "n_repeticiones": None, "lado_activo": None, "tipo_evento": None,
    }
    meta.update(extra)
    mascara_ori = senal_extra.get("buenos", valida)       # salto: solo "persona correcta"
    ori_mask = np.zeros(n, dtype=bool)
    ori_mask[ini:fin + 1] = True
    meta["orientacion_estimada"] = _orientacion(P, ori_mask & mascara_ori, aspecto, cfg)

    if clase == "pesas":
        ang = angulos_serie(Pi[ini:fin + 1], aspecto)
        rom_i = float(np.nanmax(ang["angulo_codo_izq"]) - np.nanmin(ang["angulo_codo_izq"]))
        rom_d = float(np.nanmax(ang["angulo_codo_der"]) - np.nanmin(ang["angulo_codo_der"]))
        mayor = max(rom_i, rom_d)
        if mayor > 0 and abs(rom_i - rom_d) > cfg["umbral_asimetria_rom"] * mayor:
            lado = "izq" if rom_i > rom_d else "der"
        else:
            lado = "bilateral"
        meta.update(rom_codo_izq=rom_i, rom_codo_der=rom_d, lado_activo=lado)

    senal = {
        "nombre": senal_nombre, "valores": senal_vals, "energia": energia,
        "energia_s": energia_s, "y_cadera": yc, "valida": valida,
        "sospechoso": sosp, "picos": meta.get("picos_idx", []),
        "umbrales": senal_extra.get("umbrales", []),
        "poses_interp": Pi, "poses": P,
    }
    for k in ("extras", "marcas", "meseta", "nivel_meseta", "descartados"):
        if k in senal_extra:
            senal[k] = senal_extra[k]
    return {"inicio": int(ini), "fin": int(fin), "meta": _py(meta), "senal": senal}


def detectar_intervalo(clase: str, pose_por_frame: List[np.ndarray], fps: float,
                       cfg: Optional[dict] = None, aspecto: float = 1.0,
                       alto_px: float = 1.0) -> Tuple[int, int, dict]:
    """Detecta el intervalo ``(inicio, fin)`` del ejercicio y su ``meta``.

    Args:
        clase: "abdominales" | "pesas" | "salto" | "elasticidad".
        pose_por_frame: lista de arrays (33, 4) con (x, y, z, visibilidad)
            normalizados; un array de NaN indica "sin pose".
        fps: cuadros por segundo del video.
        cfg: configuración (por defecto, ``config.json``).
        aspecto: ancho/alto del frame (para que ángulos y distancias sean
            isótropos). 1.0 si se desconoce.
        alto_px: alto del frame en px (solo para ``altura_salto_px``).
    """
    r = analizar_video(clase, pose_por_frame, fps, cfg, aspecto, alto_px)
    return r["inicio"], r["fin"], r["meta"]
