"""Cálculo de features cinemáticas a partir de landmarks de MediaPipe Pose.

Convenciones
------------
* ``poses`` es un array ``(n, 33, 4)`` con ``(x, y, z, visibilidad)``
  normalizados. Los frames sin pose detectada son filas completas de NaN.
* Los ángulos se calculan en 2D (x, y). Para que no se distorsionen en videos
  no cuadrados, ``x`` se multiplica por ``aspecto = ancho/alto`` del frame, de
  modo que las distancias quedan en "unidades de alto de frame".
* Ángulo de 3 puntos (A, B, C) = ángulo en B, en grados [0, 180].
* Ángulo del tronco = ángulo entre cadera_media→hombro_medio y la vertical.
"""
from typing import Dict, List, Optional

import warnings

import numpy as np

warnings.filterwarnings("ignore", message="All-NaN slice encountered", category=RuntimeWarning)

# Índices de MediaPipe Pose
NARIZ = 0
HOMBRO_I, HOMBRO_D = 11, 12
CODO_I, CODO_D = 13, 14
MUNECA_I, MUNECA_D = 15, 16
CADERA_I, CADERA_D = 23, 24
RODILLA_I, RODILLA_D = 25, 26
TOBILLO_I, TOBILLO_D = 27, 28

# (nombre, A, B, C): ángulo en B
DEFINICION_ANGULOS = [
    ("angulo_rodilla_izq", CADERA_I, RODILLA_I, TOBILLO_I),
    ("angulo_rodilla_der", CADERA_D, RODILLA_D, TOBILLO_D),
    ("angulo_cadera_izq", HOMBRO_I, CADERA_I, RODILLA_I),
    ("angulo_cadera_der", HOMBRO_D, CADERA_D, RODILLA_D),
    ("angulo_codo_izq", HOMBRO_I, CODO_I, MUNECA_I),
    ("angulo_codo_der", HOMBRO_D, CODO_D, MUNECA_D),
    ("angulo_hombro_izq", CODO_I, HOMBRO_I, CADERA_I),
    ("angulo_hombro_der", CODO_D, HOMBRO_D, CADERA_D),
]
NOMBRES_ANGULOS: List[str] = [d[0] for d in DEFINICION_ANGULOS] + ["angulo_tronco"]

COLUMNAS_FRAME = (
    ["video_id", "clase", "frame_idx_original", "frame_idx_clave", "t_seg",
     "t_rel", "visibilidad_media"]
    + NOMBRES_ANGULOS
    + ["y_cadera_media", "x_cadera_media", "ancho_hombros",
       "fase_adulto_sospechosa"]
)

ESTADISTICOS = ["media", "std", "min", "max", "rom"]
COLUMNAS_SEQ = (
    ["video_id", "clase", "n_seq", "duracion_intervalo_s", "deteccion_ok",
     "motivo_fallo", "n_repeticiones", "lado_activo", "tipo_evento",
     "adulto_sospechoso", "visibilidad_min_intervalo"]
    + [f"{a}_{e}" for a in NOMBRES_ANGULOS for e in ESTADISTICOS]
    + ["delta_y_cadera", "energia_media_intervalo"]
)


# ---------------------------------------------------------------- utilidades
def media_movil(x: np.ndarray, ventana: int) -> np.ndarray:
    """Media móvil centrada de misma longitud que ``x`` (bordes replicados)."""
    x = np.asarray(x, dtype=float)
    if ventana <= 1 or x.size == 0:
        return x.copy()
    pad_i = ventana // 2
    pad_d = ventana - 1 - pad_i
    xp = np.pad(x, (pad_i, pad_d), mode="edge")
    return np.convolve(xp, np.ones(ventana) / ventana, mode="valid")


def interpolar_poses(poses: np.ndarray):
    """Rellena frames sin pose por interpolación lineal (bordes: el más cercano).

    Returns:
        (poses_interpoladas, mascara_valida) ; la máscara es True donde MediaPipe
        sí detectó pose.
    """
    P = np.asarray(poses, dtype=float)
    valida = ~np.isnan(P[:, 0, 0])
    if valida.all() or not valida.any():
        return P.copy(), valida
    n = P.shape[0]
    t = np.arange(n)
    tv = t[valida]
    out = P.copy()
    for j in range(P.shape[1]):
        for c in range(P.shape[2]):
            out[:, j, c] = np.interp(t, tv, P[valida, j, c])
    return out, valida


def _xy(P: np.ndarray, idx: int, aspecto: float) -> np.ndarray:
    xy = P[..., idx, :2].copy()
    xy[..., 0] *= aspecto
    return xy


def angulo_tres_puntos(a: np.ndarray, b: np.ndarray, c: np.ndarray) -> np.ndarray:
    """Ángulo en ``b`` (grados) para puntos ``(..., 2)``; NaN si es degenerado."""
    ba, bc = a - b, c - b
    nba = np.linalg.norm(ba, axis=-1)
    nbc = np.linalg.norm(bc, axis=-1)
    den = nba * nbc
    with np.errstate(invalid="ignore", divide="ignore"):
        cos = np.sum(ba * bc, axis=-1) / den
    cos = np.clip(cos, -1.0, 1.0)
    ang = np.degrees(np.arccos(cos))
    return np.where(den > 1e-9, ang, np.nan)


def punto_medio(P: np.ndarray, i: int, j: int, aspecto: float) -> np.ndarray:
    return (_xy(P, i, aspecto) + _xy(P, j, aspecto)) / 2.0


def angulo_tronco_serie(P: np.ndarray, aspecto: float) -> np.ndarray:
    """Ángulo (grados) entre cadera_media→hombro_medio y la vertical."""
    v = punto_medio(P, HOMBRO_I, HOMBRO_D, aspecto) - punto_medio(P, CADERA_I, CADERA_D, aspecto)
    # En imagen "arriba" es -y; el ángulo con la vertical es el de v con (0,-1)
    norma = np.linalg.norm(v, axis=-1)
    with np.errstate(invalid="ignore", divide="ignore"):
        cos = -v[..., 1] / norma
    ang = np.degrees(np.arccos(np.clip(cos, -1.0, 1.0)))
    return np.where(norma > 1e-9, ang, np.nan)


def angulos_serie(P: np.ndarray, aspecto: float = 1.0) -> Dict[str, np.ndarray]:
    """Todos los ángulos de ``NOMBRES_ANGULOS`` para cada frame de ``P``."""
    out = {}
    for nombre, a, b, c in DEFINICION_ANGULOS:
        out[nombre] = angulo_tres_puntos(_xy(P, a, aspecto), _xy(P, b, aspecto),
                                         _xy(P, c, aspecto))
    out["angulo_tronco"] = angulo_tronco_serie(P, aspecto)
    return out


def ancho_hombros_serie(P: np.ndarray, aspecto: float = 1.0) -> np.ndarray:
    """Distancia hombro izq–der (unidades de alto de frame)."""
    return np.linalg.norm(_xy(P, HOMBRO_I, aspecto) - _xy(P, HOMBRO_D, aspecto), axis=-1)


def y_cadera_media_serie(P: np.ndarray) -> np.ndarray:
    return (P[..., CADERA_I, 1] + P[..., CADERA_D, 1]) / 2.0


def x_cadera_media_serie(P: np.ndarray) -> np.ndarray:
    return (P[..., CADERA_I, 0] + P[..., CADERA_D, 0]) / 2.0


def energia_por_frame(P: np.ndarray, aspecto: float, ancho_ref: float) -> np.ndarray:
    """Suma de desplazamientos de los 33 landmarks entre frames consecutivos,
    dividida por el ancho de hombros de referencia (invariante a la escala).

    El primer valor replica el segundo para que la serie tenga longitud ``n``.
    """
    n = P.shape[0]
    if n < 2:
        return np.zeros(n)
    xy = P[:, :, :2].copy()
    xy[..., 0] *= aspecto
    d = np.linalg.norm(np.diff(xy, axis=0), axis=2).sum(axis=1) / max(ancho_ref, 1e-6)
    return np.concatenate([[d[0]], d])


def visibilidad_media_serie(poses_raw: np.ndarray) -> np.ndarray:
    """Visibilidad media de los 33 landmarks por frame (0 si no hubo pose)."""
    return np.nan_to_num(np.asarray(poses_raw)[:, :, 3].mean(axis=1), nan=0.0)


# ----------------------------------------------------------- tablas de salida
def features_frames_clave(video_id: str, clase: str, poses_raw: np.ndarray,
                          poses_interp: np.ndarray, indices: List[int],
                          inicio: int, fin: int, fps: float, aspecto: float,
                          sospechoso: Optional[np.ndarray] = None) -> List[dict]:
    """Una fila (dict) por frame clave, con las columnas de ``COLUMNAS_FRAME``.

    La geometría se calcula sobre ``poses_interp`` (así un frame suelto sin
    detección no produce NaN) y la visibilidad sobre los datos crudos: un frame
    sin pose real tiene ``visibilidad_media = 0``.
    """
    idx = np.asarray(indices, dtype=int)
    Pk = poses_interp[idx]
    ang = angulos_serie(Pk, aspecto)
    ycad = y_cadera_media_serie(Pk)
    xcad = x_cadera_media_serie(Pk)
    anch = ancho_hombros_serie(Pk, aspecto)
    vis = visibilidad_media_serie(poses_raw)[idx]
    filas = []
    for k, f in enumerate(idx):
        fila = {
            "video_id": video_id, "clase": clase,
            "frame_idx_original": int(f), "frame_idx_clave": k,
            "t_seg": float(f / fps),
            "t_rel": float((f - inicio) / (fin - inicio)) if fin > inicio else 0.0,
            "visibilidad_media": float(vis[k]),
        }
        for nombre in NOMBRES_ANGULOS:
            fila[nombre] = float(ang[nombre][k])
        fila["y_cadera_media"] = float(ycad[k])
        fila["x_cadera_media"] = float(xcad[k])
        fila["ancho_hombros"] = float(anch[k])
        fila["fase_adulto_sospechosa"] = bool(sospechoso[f]) if sospechoso is not None else False
        filas.append(fila)
    return filas


def features_secuencia(video_id: str, clase: str, n_seq: int, meta: dict,
                       poses_interp: np.ndarray, inicio: int, fin: int,
                       aspecto: float, energia: np.ndarray) -> dict:
    """Fila única por video con estadísticos de los ángulos sobre TODO el
    intervalo detectado (no solo sobre los ``n_seq`` frames clave)."""
    seg = poses_interp[inicio:fin + 1]
    ang = angulos_serie(seg, aspecto)
    fila = {
        "video_id": video_id, "clase": clase, "n_seq": n_seq,
        "duracion_intervalo_s": meta.get("duracion_intervalo_s"),
        "deteccion_ok": meta.get("deteccion_ok"),
        "motivo_fallo": meta.get("motivo_fallo"),
        "n_repeticiones": meta.get("n_repeticiones"),
        "lado_activo": meta.get("lado_activo"),
        "tipo_evento": meta.get("tipo_evento"),
        "adulto_sospechoso": meta.get("adulto_sospechoso"),
        "visibilidad_min_intervalo": meta.get("visibilidad_min_intervalo"),
    }
    for nombre in NOMBRES_ANGULOS:
        s = ang[nombre]
        if np.all(np.isnan(s)):
            vals = [np.nan] * 5
        else:
            mn, mx = float(np.nanmin(s)), float(np.nanmax(s))
            vals = [float(np.nanmean(s)), float(np.nanstd(s)), mn, mx, mx - mn]
        for e, v in zip(ESTADISTICOS, vals):
            fila[f"{nombre}_{e}"] = v
    y = y_cadera_media_serie(seg)
    fila["delta_y_cadera"] = float(np.nanmax(y) - np.nanmin(y))
    fila["energia_media_intervalo"] = float(np.mean(energia[inicio:fin + 1]))
    return fila


# ===================================================================
# Rama tabular de los modelos (integración): features SOLO desde poses
# ===================================================================
# Por qué existe: las columnas de ``features_seq.csv`` salen de ``analizar_video``,
# que recibe la CLASE REAL (intervalo, tipo_evento, n_repeticiones, columnas
# específicas de salto/elasticidad...). Usarlas filtraría la etiqueta y no se
# pueden calcular en inferencia. ``features_desde_poses`` NO recibe la clase.
BASES_FEATURE_FRAME: List[str] = NOMBRES_ANGULOS + [
    "ancho_hombros", "y_cadera_media", "x_cadera_media", "visibilidad_media"]
NOMBRES_FEATURES: List[str] = (
    [f"{b}_{e}" for b in BASES_FEATURE_FRAME for e in ESTADISTICOS]
    + ["energia_media_intervalo", "delta_y_cadera"]
)
# Fuente única de verdad del tamaño de la rama tabular (derivado, no fijo).
N_FEATURES: int = len(NOMBRES_FEATURES)


def features_desde_poses(poses_8_frames: np.ndarray, aspecto: float = 1.0) -> np.ndarray:
    """Vector de features geométricas de una secuencia de poses (sin clase).

    Por frame se calculan 13 valores: 9 ángulos (``NOMBRES_ANGULOS``),
    ``ancho_hombros``, ``y_cadera_media``, ``x_cadera_media`` y
    ``visibilidad_media``. Cada uno se resume sobre los frames con
    ``media, std, min, max, rom`` (13 x 5 = 65) y se añaden dos globales:

    * ``energia_media_intervalo``: media del desplazamiento de los 33 landmarks
      entre frames consecutivos, normalizado por el ancho de hombros mediano
      (``energia_por_frame``; se descarta el primer valor, que solo replica
      al segundo).
    * ``delta_y_cadera``: max - min de ``y_cadera_media``.

    Total: ``N_FEATURES`` (= 67) valores, en el orden de ``NOMBRES_FEATURES``.

    Los frames sin pose (filas NaN) NO se interpolan: se ignoran en los
    estadísticos (``nan*``) y, si no queda ningún dato, el valor es NaN (se
    imputa después con las medias de entrenamiento). La visibilidad de un frame
    sin pose es 0, como en la herramienta.

    Se usa de forma idéntica en entrenamiento (poses de ``poses.npz`` en los
    ``indices_clave``) y en la detección en vivo (poses del búfer).

    Args:
        poses_8_frames: Array ``(n, 33, 4)`` con ``(x, y, z, visibilidad)``
            normalizados; ``n`` suele ser ``seq_length`` (8).
        aspecto: ``ancho / alto`` del frame original.

    Returns:
        ``np.ndarray`` float64 de forma ``(N_FEATURES,)``.

    Raises:
        ValueError: Si la forma de ``poses_8_frames`` no es ``(n >= 1, 33, 4)``.
    """
    P = np.asarray(poses_8_frames, dtype=float)
    if P.ndim != 3 or P.shape[0] < 1 or P.shape[1:] != (33, 4):
        raise ValueError(f"poses debe tener forma (n>=1, 33, 4); recibido {P.shape}")
    aspecto = float(aspecto) if aspecto and np.isfinite(aspecto) and aspecto > 0 else 1.0

    ang = angulos_serie(P, aspecto)
    series = [ang[n] for n in NOMBRES_ANGULOS]
    ancho_h = ancho_hombros_serie(P, aspecto)
    y_cad = y_cadera_media_serie(P)
    series += [ancho_h, y_cad, x_cadera_media_serie(P), visibilidad_media_serie(P)]

    out: List[float] = []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)   # slices todo-NaN
        for s in series:
            s = np.asarray(s, dtype=float)
            if np.all(np.isnan(s)):
                out += [np.nan] * len(ESTADISTICOS)
                continue
            mn, mx = float(np.nanmin(s)), float(np.nanmax(s))
            out += [float(np.nanmean(s)), float(np.nanstd(s)), mn, mx, mx - mn]

        if P.shape[0] >= 2 and not np.all(np.isnan(ancho_h)):
            ref = max(float(np.nanmedian(ancho_h)), 1e-3)
            en = energia_por_frame(P, aspecto, ref)[1:]
            energia = float(np.nanmean(en)) if not np.all(np.isnan(en)) else np.nan
        else:
            energia = np.nan
        delta_y = (float(np.nanmax(y_cad) - np.nanmin(y_cad))
                   if not np.all(np.isnan(y_cad)) else np.nan)
    out += [energia, delta_y]

    vec = np.asarray(out, dtype=float)
    assert vec.shape == (N_FEATURES,), vec.shape
    return vec
