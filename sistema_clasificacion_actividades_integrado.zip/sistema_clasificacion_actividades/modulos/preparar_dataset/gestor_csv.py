"""Lectura/escritura de los CSV frame-level, sequence-level y de validación."""
import csv
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from .calculador_features import COLUMNAS_FRAME, COLUMNAS_SEQ

logger = logging.getLogger(__name__)

COLUMNAS_VALIDACION = ["video_id", "clase", "decision", "motivo", "fecha"]

# Columnas añadidas (valores a nivel de video; se repiten en cada fila del CSV
# frame-level). Las específicas de una clase quedan vacías en las demás.
COLUMNAS_NUEVAS = [
    "orientacion_estimada",
    "rom_rodilla_pico", "energia_vertical_pico", "coherencia_salto",
    "persona_correcta_frames_descartados", "firma_salto_valida",      # solo salto
    "rom_pico", "duracion_estiramiento_s", "nivel_meseta_elasticidad",  # solo elasticidad
]


def escribir_features_frame(ruta, filas: List[dict]) -> None:
    """Escribe ``features.csv`` (una fila por frame clave)."""
    Path(ruta).parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(filas).reindex(columns=COLUMNAS_FRAME + COLUMNAS_NUEVAS).to_csv(
        ruta, index=False, encoding="utf-8")


def escribir_features_seq(ruta, fila: dict) -> None:
    """Escribe ``features_seq.csv`` (una única fila por video)."""
    Path(ruta).parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame([fila]).reindex(columns=COLUMNAS_SEQ + COLUMNAS_NUEVAS).to_csv(
        ruta, index=False, encoding="utf-8")


def consolidar(dir_salida) -> Dict[str, int]:
    """Concatena todos los ``features*.csv`` por video en dos CSV globales.

    Genera ``datos_salida/features_todos.csv`` y ``features_seq_todos.csv``
    (comodidad extra; los CSV por video siguen siendo la fuente de verdad).
    """
    dir_salida = Path(dir_salida)
    res = {}
    for nombre, salida in (("features.csv", "features_todos.csv"),
                           ("features_seq.csv", "features_seq_todos.csv")):
        partes = []
        for p in sorted((dir_salida / "frames").glob(f"*/*/{nombre}")):
            try:
                partes.append(pd.read_csv(p))
            except Exception as exc:  # noqa: BLE001
                logger.warning("No se pudo leer %s: %s", p, exc)
        if partes:
            pd.concat(partes, ignore_index=True).to_csv(
                dir_salida / salida, index=False, encoding="utf-8")
        res[salida] = len(partes)
    return res


# ----------------------------------------------------------- validación manual
def registrar_validacion(ruta, video_id: str, clase: str, decision: str,
                         motivo: str = "") -> None:
    """Agrega una decisión a ``validacion_manual.csv`` (historial; vale la última)."""
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    nuevo = not ruta.exists() or ruta.stat().st_size == 0
    with open(ruta, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if nuevo:
            w.writerow(COLUMNAS_VALIDACION)
        w.writerow([video_id, clase, decision, motivo,
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")])


def leer_validaciones(ruta) -> Dict[tuple, dict]:
    """Última decisión por ``(clase, video_id)``."""
    ruta = Path(ruta)
    if not ruta.exists():
        return {}
    out = {}
    with open(ruta, "r", newline="", encoding="utf-8") as f:
        for fila in csv.DictReader(f):
            out[(fila.get("clase"), fila.get("video_id"))] = fila
    return out
