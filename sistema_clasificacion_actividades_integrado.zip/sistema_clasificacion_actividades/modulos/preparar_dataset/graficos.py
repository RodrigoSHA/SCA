"""Dibujo de la curva de detección (compartido por el visor y debug.png).

Usa solo ``matplotlib.figure.Figure`` (sin pyplot) para ser seguro en hilos.
"""
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure


def dibujar_curva(ax, res: dict, mostrar_titulo: bool = True):
    """Dibuja la señal usada para la detección con intervalo y frames clave.

    Args:
        ax: ejes de matplotlib.
        res: resultado de ``pipeline.procesar_video`` (con ``senal``, ``meta`` e
            ``indices_clave``).

    Returns:
        La línea vertical del "frame actual" (para que el visor la mueva).
    """
    senal, meta = res["senal"], res["meta"]
    y = np.asarray(senal["valores"], dtype=float)
    x = np.arange(y.size)
    ini, fin = meta["inicio"], meta["fin"]
    ax.clear()
    ax.plot(x, y, color="#1f77b4", lw=1.3, label=senal["nombre"])
    ymin, ymax = float(np.nanmin(y)), float(np.nanmax(y))
    if ymax - ymin < 1e-9:
        ymax = ymin + 1.0
    pad = 0.08 * (ymax - ymin)
    ax.set_ylim(ymin - pad, ymax + pad)
    ax.set_xlim(0, max(1, y.size - 1))

    sosp = np.asarray(senal["sospechoso"], dtype=bool)
    if sosp.any():
        ax.fill_between(x, ymin - pad, ymax + pad, where=sosp, color="gray",
                        alpha=0.25, step="mid", label="adulto sospechoso", lw=0)
    ok = meta.get("deteccion_ok", True)
    color_zona = "#2ca02c" if ok else "#ff7f0e"
    ax.axvspan(ini, fin, color=color_zona, alpha=0.15)
    ax.axvline(ini, color="green", lw=1.8, label=f"inicio ({ini})")
    ax.axvline(fin, color="red", lw=1.8, label=f"fin ({fin})")
    for valor, etiqueta in senal.get("umbrales", []):
        ax.axhline(valor, color="gray", ls=":", lw=0.9)
    picos = senal.get("picos") or []
    if picos:
        ax.plot(picos, y[picos], "v", color="#9467bd", ms=5, label="picos")
    claves = res.get("indices_clave") or []
    if claves:
        claves = [min(max(int(k), 0), y.size - 1) for k in claves]
        ax.plot(claves, y[claves], "o", color="#d62728", ms=6, mec="white", label="frames clave")
    desc = senal.get("descartados")
    if desc is not None and np.any(desc):
        ax.fill_between(x, ymin - pad, ymax + pad, where=np.asarray(desc, dtype=bool),
                        color="red", alpha=0.10, step="mid", lw=0,
                        label="otra persona (descartado)")
    mes = senal.get("meseta")
    if mes:
        ax.axvspan(mes[0], mes[1], facecolor="none", edgecolor="#1f77b4", hatch="///",
                   alpha=0.35, lw=0, label="meseta")
    if senal.get("nivel_meseta") is not None:
        ax.axhline(senal["nivel_meseta"], color="#1f77b4", ls="--", lw=1.0, label="nivel meseta")
    for xi, yi, etiqueta in senal.get("marcas", []):
        ax.plot(xi, yi, "*", ms=12, color="gold", mec="black", zorder=5)
        ax.annotate(etiqueta, (xi, yi), textcoords="offset points", xytext=(5, 7), fontsize=7)
    for nombre, vals in senal.get("extras", []):          # otras señales, normalizadas
        v = np.asarray(vals, dtype=float)
        rng = float(np.nanmax(v) - np.nanmin(v)) or 1.0
        ax.plot(x, ymin + (v - np.nanmin(v)) / rng * (ymax - ymin), lw=0.9, alpha=0.8,
                label=f"{nombre} (norm.)")
    linea = ax.axvline(0, color="black", lw=1.0, alpha=0.8)
    ax.set_xlabel("frame")
    ax.grid(alpha=0.25)
    ax.legend(loc="upper right", fontsize=7, ncol=3, framealpha=0.8)
    if mostrar_titulo:
        estado = "OK" if ok else f"FALLBACK ({meta.get('motivo_fallo')})"
        ax.set_title(f"{res['clase']}/{res['video_id']} — {estado}", fontsize=9)
    return linea


def guardar_debug_png(ruta, res: dict) -> None:
    """Guarda ``debug.png``: señal principal con intervalo, frames clave y marcas;
    si hay señales adicionales (salto: energía vertical y rom de rodilla) se
    dibujan en paneles propios debajo."""
    senal = res["senal"]
    extras = senal.get("extras", [])
    n = 1 + len(extras)
    fig = Figure(figsize=(9, 3.2 + 1.7 * len(extras)), dpi=100)
    FigureCanvasAgg(fig)
    axs = fig.subplots(n, 1, sharex=True, gridspec_kw={"height_ratios": [2.2] + [1] * len(extras)}) \
        if n > 1 else [fig.add_subplot(111)]
    res_base = dict(res, senal=dict(senal, extras=[]))
    linea = dibujar_curva(axs[0], res_base)
    linea.set_visible(False)
    meta = res["meta"]
    for ax, (nombre, vals) in zip(axs[1:], extras):
        v = np.asarray(vals, dtype=float)
        ax.plot(np.arange(v.size), v, color="#2c3e50", lw=1.1)
        ax.axvspan(meta["inicio"], meta["fin"], color="#2ca02c", alpha=0.15)
        ax.axvline(meta["inicio"], color="green", lw=1.5)
        ax.axvline(meta["fin"], color="red", lw=1.5)
        for xi, _yi, etiqueta in senal.get("marcas", []):
            ax.axvline(xi, color="gold", ls=":", lw=1.2)
        ax.set_ylabel(nombre, fontsize=8)
        ax.grid(alpha=0.25)
    axs[-1].set_xlabel("frame")
    fig.tight_layout()
    fig.savefig(str(ruta))
