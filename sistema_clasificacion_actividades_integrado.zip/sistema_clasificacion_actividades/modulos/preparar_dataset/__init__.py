"""Preparación de dataset integrada en el proyecto principal.

Procede de la herramienta independiente ``herramientas/preparar_dataset``.
Por cada video: poses (MediaPipe Pose) -> intervalo del ejercicio -> 8 frames
clave anonimizados (JPG) -> ``poses.npz`` + ``meta.json`` + ``debug.png``.

Rama tabular de los modelos
---------------------------
Los modelos usan SOLO :func:`features_desde_poses`, que depende únicamente de
las poses de los frames clave. NO se usan las columnas de ``features_seq.csv``
que genera la herramienta: dependen de la etiqueta real (``analizar_video``
recibe la clase) y no se pueden calcular en inferencia.

Los parámetros del detector (antes ``config.json`` de la herramienta) viven
aquí como valores por defecto; :func:`cargar_config` los combina con la
configuración del proyecto (``seq_length`` -> ``n_seq``, ``img_size``).
"""
import copy
from pathlib import Path
from typing import Optional

# Raíz del proyecto principal (modulos/preparar_dataset/__init__.py -> raíz).
BASE_DIR = Path(__file__).resolve().parent.parent.parent
# Salida por defecto de procesar_video cuando NO se indica ``carpeta_destino``:
# <DIR_SALIDA>/frames/<clase>/<video>/. El proyecto siempre usa carpeta_destino.
DIR_SALIDA = BASE_DIR / "datos_salida"

EXTENSIONES_VIDEO = [".mp4", ".avi", ".mov", ".mkv", ".mpg", ".mpeg", ".webm"]

# Valores por defecto del detector: copia del config.json de la herramienta
# (sin n_seq / img_size / clases, que salen de la configuración del proyecto).
PARAMETROS_DETECTOR = {
    "suavizado_energia": 5,
    "k_umbral_picos": 0.5,
    "distancia_minima_picos_s": 0.3,
    "margen_inicio_fin_s": 0.2,
    "umbral_rom_elasticidad_alto": 0.3,
    "umbral_rom_elasticidad_bajo": 0.2,
    "cambio_ancho_hombros_adulto": 0.4,
    "cambio_y_cadera_adulto": 0.2,
    "confianza_mediapipe": 0.5,
    "duracion_minima_intervalo_s": 1.0,
    "fraccion_maxima_intervalo": 0.95,
    "fraccion_minima_pose": 0.5,
    "umbral_asimetria_rom": 0.2,
    "frames_baseline": 10,
    "prominencia_salto_rel": 0.15,
    "altura_minima_salto": 0.03,
    "rom_minimo_elasticidad_grados": 5.0,
    "max_lado_procesamiento": 640,
    "complejidad_pose": 1,
    "calidad_jpg": 95,
    "usar_poses_sinteticas": True,
    "parada_dura_elasticidad_s": 6,
    "umbral_cadera_x_salto": 0.15,
    "cambio_tronco_salto": 1.6,
    "umbral_visibilidad_rodilla": 0.5,
    "umbral_ancho_hombros_frontal": 0.15,
    "umbral_ancho_hombros_perfil": 0.08,
    "union_huecos_meseta_s": 0.5,
    "percentil_meseta_elasticidad": 90,
    "umbral_meseta_elasticidad": 0.5,
    "fps_para_frames": "auto",
    "suavizado_salto": 3,
    "prominencia_flexion_rodilla_grados": 15,
    "coherencia_max_salto_s": 0.3,
    "ventana_ref_tronco_s": 2.0,
    "union_descartes_persona_s": 1.0,
    "duracion_min_salto_s": 0.25,
    "duracion_max_salto_s": 2.5,
    "max_fraccion_descartados_salto": 0.1,
    "sostenido_fin_elasticidad_s": 0.5,
    "ratio_ambiguedad_elasticidad": 0.6,
    "estiramiento_minimo_s": 0.5,
    "min_frames_orientacion": 10,
    "percentil_energia_aterrizaje": 60,
    "ventana_confirmacion_rodilla_s": 0.25,
    "duracion_minima_salto_s": 0.5,
    "margen_adulto_s": 0.2,
    "umbral_rom_inicio_elasticidad": 0.3,
    "sostenido_inicio_elasticidad_s": 0.7,
    "umbral_tronco_adulto": [0.625, 1.6],
    "umbral_y_cadera_adulto": 0.12,
    "umbral_x_cadera_adulto": 0.07,
    "duracion_min_adulto_s": 0.2,
}
CLASES_POR_DEFECTO = ["abdominales", "pesas", "salto", "elasticidad"]


def cargar_config(cfg_proyecto=None, sobreescribir: Optional[dict] = None) -> dict:
    """Parámetros del detector para un procesamiento.

    Args:
        cfg_proyecto: ``Configuracion`` (o dict) del proyecto. De ahí salen
            ``n_seq`` (= ``seq_length``), ``img_size`` y ``clases``. Si es
            None se usan 8, 224 y las cuatro clases por defecto.
        sobreescribir: Parámetros del detector a modificar.

    Returns:
        Diccionario con todas las claves que esperan ``detector_ejercicio``,
        ``extractor_frames`` y ``pipeline``.
    """
    cfg = copy.deepcopy(PARAMETROS_DETECTOR)
    cfg.update(n_seq=8, img_size=224, clases=list(CLASES_POR_DEFECTO),
               extensiones_video=list(EXTENSIONES_VIDEO))
    if cfg_proyecto is not None:
        cfg["n_seq"] = int(cfg_proyecto["seq_length"])
        cfg["img_size"] = int(cfg_proyecto["img_size"])
        cfg["clases"] = list(cfg_proyecto["clases"])
    if sobreescribir:
        cfg.update(sobreescribir)
    return cfg


# Las importaciones de submódulos van después de definir cargar_config porque
# detector_ejercicio hace ``from . import cargar_config``.
from .calculador_features import (N_FEATURES, NOMBRES_FEATURES,  # noqa: E402
                                  features_desde_poses, features_frames_clave,
                                  features_secuencia)
from .detector_ejercicio import (CLASES_CONOCIDAS, Cancelado,  # noqa: E402
                                 detectar_intervalo)
from .extractor_frames import crear_anonimizador, extraer_frames_clave  # noqa: E402
from .gestor_csv import (consolidar, escribir_features_frame,  # noqa: E402
                         escribir_features_seq)
from .pipeline import listar_videos, procesar_lote, procesar_video  # noqa: E402

# Alias con el nombre pedido en el plan (frame-level; el seq-level es
# ``escribir_features_seq``).
escribir_csv = escribir_features_frame

__all__ = [
    "procesar_video", "procesar_lote", "listar_videos", "detectar_intervalo",
    "extraer_frames_clave", "features_frames_clave", "features_secuencia",
    "features_desde_poses", "crear_anonimizador", "escribir_csv",
    "escribir_features_frame", "escribir_features_seq", "consolidar",
    "cargar_config", "NOMBRES_FEATURES", "N_FEATURES", "CLASES_CONOCIDAS",
    "Cancelado", "BASE_DIR", "DIR_SALIDA",
]
