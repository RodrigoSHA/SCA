"""Módulo 5: circuito cuántico variacional (PQC).

Define :class:`CircuitoPQC`, un circuito de ``n_qubits`` qubits simulado con
PennyLane e integrable en Keras mediante ``qml.qnn.KerasLayer``.

Estructura del circuito::

    |0> -- RY(x_0) -- [StronglyEntanglingLayers(theta)] -- <Z_0>
    |0> -- RY(x_1) -- [   (rotaciones + CNOT en anillo)] -- <Z_1>
     ...

* **Codificación** (``AngleEmbedding``, rotación RY): cada característica
  clásica ``x_i`` (en [-pi, pi]) se convierte en el ángulo de un qubit.
* **Parte variacional** (``StronglyEntanglingLayers``): ``n_capas`` capas de
  rotaciones entrenables ``theta`` (forma ``(n_capas, n_qubits, 3)``)
  seguidas de CNOT que entrelazan los qubits.
* **Medición**: valor esperado de Pauli-Z en cada qubit, en [-1, 1].
"""
import logging
from typing import Dict, Tuple

import numpy as np
import pennylane as qml

logger = logging.getLogger(__name__)


class CircuitoPQC:
    """Circuito cuántico variacional parametrizado.

    Args:
        n_qubits: Número de qubits (>= 2).
        n_capas: Número de capas variacionales.
        shots: Disparos usados en simulación con muestreo finito.
        seed: Semilla de inicialización de los pesos.
        usar_shots: Si es True, también el entrenamiento usa ``shots``
            (regla de desplazamiento de parámetros; mucho más lento). Si es
            False, entrenamiento con simulación analítica y retropropagación.

    Attributes:
        weight_shapes: Forma de los pesos entrenables para Keras.
    """

    def __init__(self, n_qubits: int = 4, n_capas: int = 2, shots: int = 1024,
                 seed: int = 42, usar_shots: bool = False) -> None:
        if n_qubits < 2:
            raise ValueError("El circuito requiere al menos 2 qubits")
        self.n_qubits = int(n_qubits)
        self.n_capas = int(n_capas)
        self.shots = int(shots)
        self.seed = int(seed)
        self.usar_shots = bool(usar_shots)
        self.weight_shapes: Dict[str, Tuple[int, ...]] = {
            "pesos": (self.n_capas, self.n_qubits, 3)}

    # ---- construcción del circuito ----------------------------------------
    def _funcion_circuito(self):
        """Devuelve la función del circuito (firma exigida por KerasLayer)."""
        n = self.n_qubits

        def circuito(inputs, pesos):
            # 1) Codificación por ángulos: x_i -> RY(x_i) sobre el qubit i.
            qml.AngleEmbedding(inputs, wires=range(n), rotation="Y")
            # 2) Bloque variacional entrenable con entrelazamiento.
            qml.StronglyEntanglingLayers(pesos, wires=range(n))
            # 3) Medición de <Z> en cada qubit.
            return [qml.expval(qml.PauliZ(i)) for i in range(n)]

        return circuito

    def crear_qnode(self, shots=None, diff_method: str = "backprop",
                    interface: str = "tf") -> qml.QNode:
        """Crea un QNode.

        Args:
            shots: ``None`` para simulación exacta o un entero de disparos.
            diff_method: Método de diferenciación.
            interface: Interfaz de ML (``"tf"`` o ``"numpy"``).
        """
        dev = qml.device("default.qubit", wires=self.n_qubits, shots=shots)
        return qml.QNode(self._funcion_circuito(), dev, interface=interface,
                         diff_method=diff_method)

    def crear_capa_keras(self, name: str = "capa_cuantica"):
        """Crea la capa Keras que envuelve el PQC.

        Entrada: tensor ``(batch, n_qubits)``; salida: ``(batch, n_qubits)``.
        """
        import tensorflow as tf
        if self.usar_shots:
            qnode = self.crear_qnode(shots=self.shots, diff_method="parameter-shift")
        else:
            qnode = self.crear_qnode(shots=None, diff_method="backprop")
        specs = {"pesos": {"initializer": tf.keras.initializers.RandomUniform(
            minval=0.0, maxval=2 * np.pi, seed=self.seed)}}
        return qml.qnn.KerasLayer(qnode, self.weight_shapes,
                                  output_dim=self.n_qubits,
                                  weight_specs=specs, name=name)

    # ---- ejecución y utilidades --------------------------------------------
    def ejecutar(self, entradas: np.ndarray, pesos: np.ndarray,
                 shots: int = None) -> np.ndarray:
        """Evalúa el circuito con NumPy, opcionalmente con disparos finitos.

        Args:
            entradas: Array ``(batch, n_qubits)`` de ángulos.
            pesos: Array con forma ``weight_shapes["pesos"]``.
            shots: Disparos; ``None`` usa ``self.shots``; 0 = exacto.

        Returns:
            Array ``(batch, n_qubits)`` con los valores esperados de Z.
        """
        s = self.shots if shots is None else shots
        qnode = self.crear_qnode(shots=(s or None), diff_method="best",
                                 interface="numpy")
        entradas = np.atleast_2d(np.asarray(entradas, dtype=float))
        salida = [np.stack([np.asarray(v) for v in qnode(x, np.asarray(pesos))])
                  for x in entradas]
        return np.stack(salida)

    def dibujar(self) -> str:
        """Devuelve un diagrama de texto del circuito."""
        qnode = self.crear_qnode(shots=None, diff_method="best", interface="numpy")
        return qml.draw(qnode)(np.zeros(self.n_qubits),
                               np.zeros(self.weight_shapes["pesos"]))

    def parametros(self) -> dict:
        """Parámetros del circuito (para persistencia)."""
        return {"n_qubits": self.n_qubits, "n_capas_pqc": self.n_capas,
                "shots": self.shots, "usar_shots_entrenamiento": self.usar_shots}
