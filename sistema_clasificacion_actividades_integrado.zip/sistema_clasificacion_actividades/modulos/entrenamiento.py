"""Módulo 6: entrenamiento de ambos modelos.

:class:`Entrenador` entrena el modelo clásico, el híbrido o ambos bajo
condiciones idénticas (mismo dataset particionado, mismas semillas,
optimizador, épocas y batch size). Está pensado para ejecutarse en un hilo
de la GUI: expone ``pausar``/``reanudar``/``detener`` y notifica el progreso
mediante callbacks.
"""
import logging
import threading
import time
from typing import Callable, Dict, List, Optional

import tensorflow as tf

from modulos.configuracion import fijar_semillas
from modulos.modelo_clasico import ModeloClasico
from modulos.modelo_hibrido import ModeloHibrido
from modulos.persistencia import RepositorioModelos
from modulos.preprocesamiento import Preprocesador

logger = logging.getLogger(__name__)


class _PuenteKeras(tf.keras.callbacks.Callback):
    """Conecta el bucle de Keras con el control de pausa/parada y la GUI."""

    def __init__(self, entrenador: "Entrenador", nombre: str, epocas: int) -> None:
        super().__init__()
        self.ent = entrenador
        self.nombre = nombre
        self.epocas = epocas

    def on_train_batch_begin(self, batch, logs=None):
        # Pausa cooperativa: se bloquea entre batches mientras esté pausado.
        self.ent._esperar_si_pausado()
        if self.ent._detener.is_set():
            self.model.stop_training = True

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        info = {"modelo": self.nombre, "epoca": epoch + 1, "epocas": self.epocas,
                "loss": float(logs.get("loss", 0.0)),
                "accuracy": float(logs.get("accuracy", 0.0)),
                "val_loss": float(logs.get("val_loss", 0.0)),
                "val_accuracy": float(logs.get("val_accuracy", 0.0))}
        self.ent._emitir_log(
            f"[{self.nombre}] época {info['epoca']}/{self.epocas} - "
            f"loss {info['loss']:.4f} acc {info['accuracy']:.3f} | "
            f"val_loss {info['val_loss']:.4f} val_acc {info['val_accuracy']:.3f}")
        if self.ent.callback_epoca:
            self.ent.callback_epoca(info)


class Entrenador:
    """Orquesta el entrenamiento de los modelos.

    Args:
        cfg: Configuración vigente.
        repositorio: Destino de los modelos entrenados.
        callback_epoca: ``f(info_dict)`` al terminar cada época.
        callback_log: ``f(mensaje)`` para eventos de texto.

    Attributes:
        historial: ``{modelo: {métrica: [valores por época]}}``.
    """

    def __init__(self, cfg, repositorio: Optional[RepositorioModelos] = None,
                 callback_epoca: Optional[Callable[[dict], None]] = None,
                 callback_log: Optional[Callable[[str], None]] = None) -> None:
        self.cfg = cfg
        self.repositorio = repositorio or RepositorioModelos()
        self.callback_epoca = callback_epoca
        self.callback_log = callback_log
        self.historial: Dict[str, Dict[str, List[float]]] = {}
        self._reanudar = threading.Event()
        self._reanudar.set()  # set = en marcha, clear = en pausa
        self._detener = threading.Event()

    # ---- control --------------------------------------------------------------
    def pausar(self) -> None:
        """Pausa el entrenamiento en el siguiente batch."""
        self._reanudar.clear()
        self._emitir_log("Entrenamiento en pausa")

    def reanudar(self) -> None:
        """Reanuda un entrenamiento pausado."""
        self._reanudar.set()
        self._emitir_log("Entrenamiento reanudado")

    def detener(self) -> None:
        """Solicita detener el entrenamiento (libera también la pausa)."""
        self._detener.set()
        self._reanudar.set()
        self._emitir_log("Deteniendo entrenamiento...")

    @property
    def pausado(self) -> bool:
        """True si el entrenamiento está en pausa."""
        return not self._reanudar.is_set()

    def _esperar_si_pausado(self) -> None:
        while not self._reanudar.wait(0.2):
            if self._detener.is_set():
                break

    def _emitir_log(self, mensaje: str) -> None:
        logger.info(mensaje)
        if self.callback_log:
            self.callback_log(mensaje)

    # ---- entrenamiento --------------------------------------------------------------
    def entrenar(self, seleccion: str = "ambos") -> Dict[str, Dict[str, List[float]]]:
        """Entrena y guarda los modelos seleccionados (bloqueante).

        Args:
            seleccion: ``"clasico"``, ``"hibrido"`` o ``"ambos"``.

        Returns:
            El historial de entrenamiento.

        Raises:
            ValueError: Si la selección o los datos no son válidos.
        """
        if seleccion not in ("clasico", "hibrido", "ambos"):
            raise ValueError(f"Selección inválida: {seleccion!r}")
        self._detener.clear()
        self._reanudar.set()
        prep = Preprocesador(self.cfg)
        prep.detectar_clases()
        clases = list(self.cfg["clases"])
        self._emitir_log("Preparando datos (frames anonimizados + poses)...")
        prep.asegurar_frames(
            lambda i, n, m: self._emitir_log(f"Procesando video {i}/{n}: {m}")
            if i % 10 == 1 else None)
        # Con rama tabular, crear_dataset("train", entrenamiento=True) calcula las
        # medias de imputación / normalización SOLO con train y las deja en cfg;
        # validation (y test, al evaluar) reutilizan esas mismas estadísticas.
        ds_train = prep.crear_dataset("train", entrenamiento=True)
        ds_val = prep.crear_dataset("validation")
        if prep.usar_tabular:
            self._emitir_log(f"Rama tabular activa: {int(self.cfg['n_features_tabulares'])} "
                             "features desde poses (estadísticas calculadas con train)")
        else:
            self._emitir_log("Rama tabular desactivada: solo imágenes")
        nombres = ["clasico", "hibrido"] if seleccion == "ambos" else [seleccion]
        for nombre in nombres:
            if self._detener.is_set():
                break
            self._entrenar_uno(nombre, ds_train, ds_val, clases)
        return self.historial

    def _entrenar_uno(self, nombre: str, ds_train, ds_val, clases: List[str]) -> None:
        """Construye, entrena y guarda un modelo."""
        # Misma semilla antes de construir cada modelo: condiciones idénticas.
        fijar_semillas(int(self.cfg["seed"]))
        wrapper = ModeloClasico(self.cfg) if nombre == "clasico" else ModeloHibrido(self.cfg)
        wrapper.construir()
        wrapper.compilar()
        epocas = int(self.cfg["epocas"])
        self._emitir_log(f"== Entrenando modelo {nombre} ({epocas} épocas) ==")
        inicio = time.time()
        callbacks = [
            _PuenteKeras(self, nombre, epocas),
            tf.keras.callbacks.EarlyStopping(
                monitor="val_loss", patience=10, restore_best_weights=True),
        ]
        hist = wrapper.modelo.fit(ds_train, validation_data=ds_val,
                                  epochs=epocas, callbacks=callbacks, verbose=0)
        self.historial[nombre] = {k: [float(v) for v in vs]
                                  for k, vs in hist.history.items()}
        self._emitir_log(f"Modelo {nombre} terminado en {time.time() - inicio:.1f} s")
        if self._detener.is_set():
            self._emitir_log("Entrenamiento detenido por el usuario; se guarda el estado actual")
        self.repositorio.guardar(nombre, wrapper, self.cfg, clases)
        self._emitir_log(f"Modelo {nombre} guardado")
