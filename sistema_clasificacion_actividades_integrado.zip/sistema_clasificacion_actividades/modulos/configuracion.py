"""Módulo 2: gestión de configuración.

Contiene la clase :class:`Configuracion` (carga, validación y guardado de
parámetros en JSON), utilidades de rutas del proyecto y la función
:func:`fijar_semillas` que garantiza la reproducibilidad (seed = 42).
"""
import copy
import json
import logging
import os
import random
from pathlib import Path
from typing import Any, Dict, Optional

import numpy as np

logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config.json"
MODELOS_DIR = BASE_DIR / "modelos_guardados"
RESULTADOS_DIR = BASE_DIR / "datos" / "resultados"
LOGS_DIR = BASE_DIR / "logs"

CONFIG_DEFECTO: Dict[str, Any] = {
    "modelo": "clasico",
    "n_qubits": 4,
    "n_capas_pqc": 2,
    "seq_length": 8,
    "shots": 1024,
    "learning_rate": 0.001,
    "epocas": 50,
    "batch_size": 32,
    "ruta_dataset": "datos/dataset",
    "ruta_frames": "datos/frames",
    "img_size": 224,
    "seed": 42,
    "congelar_pct": 0.8,
    "pesos_imagenet": True,
    "clases": ["abdominales", "pesas", "salto", "elasticidad"],
    "n_clases": 4,
    "lstm_unidades": 128,
    "usar_shots_entrenamiento": False,
    # --- rama tabular (features desde poses de los frames clave) ---
    "usar_features_tabulares": True,
    # Se rellenan en cada entrenamiento (solo con train) y se guardan con el modelo:
    "columnas_tabulares": [],        # nombres en orden (= preparar_dataset.NOMBRES_FEATURES)
    "medias_imputacion": {},         # {columna: media de train} para los NaN
    "medias_normalizacion": [],      # media de train tras imputar, una por columna
    "stds_normalizacion": [],        # desviación de train tras imputar, una por columna
    # Debe coincidir con len(NOMBRES_FEATURES) (67); el Preprocesador lo actualiza.
    "n_features_tabulares": 67,
}


def crear_estructura(base: Optional[Path] = None) -> None:
    """Crea las carpetas del proyecto si no existen.

    Args:
        base: Carpeta raíz del proyecto. Por defecto, la del paquete.
    """
    base = Path(base) if base else BASE_DIR
    carpetas = [base / "logs", base / "modelos_guardados",
                base / "datos" / "resultados"]
    for split in ("train", "validation", "test"):
        carpetas.append(base / "datos" / "dataset" / split)
        carpetas.append(base / "datos" / "frames" / split)
    for carpeta in carpetas:
        carpeta.mkdir(parents=True, exist_ok=True)


def fijar_semillas(seed: int = 42) -> None:
    """Fija las semillas de Python, NumPy y TensorFlow (si está instalado).

    Args:
        seed: Semilla aleatoria (42 por defecto, según los requisitos).
    """
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.keras.utils.set_random_seed(seed)
    except ImportError:
        logger.debug("TensorFlow no disponible; solo se fijaron random/numpy")


class Configuracion:
    """Parámetros del sistema con persistencia en ``config.json``.

    Se comporta como un diccionario (``cfg["epocas"]``, ``cfg.get(...)``).
    Las claves que falten en el archivo se completan con los valores por
    defecto.

    Attributes:
        datos: Diccionario con los parámetros vigentes.
        ruta: Archivo JSON asociado.
    """

    def __init__(self, ruta: Optional[Path] = None) -> None:
        """Carga la configuración desde ``ruta`` o usa los valores por defecto."""
        self.ruta = Path(ruta) if ruta else CONFIG_PATH
        self.datos: Dict[str, Any] = copy.deepcopy(CONFIG_DEFECTO)
        if self.ruta.exists():
            try:
                self.cargar(self.ruta)
            except (OSError, ValueError) as exc:
                logger.warning("Configuración inválida (%s); se usan valores "
                               "por defecto", exc)

    # ---- acceso tipo diccionario -------------------------------------
    def __getitem__(self, clave: str) -> Any:
        return self.datos[clave]

    def __setitem__(self, clave: str, valor: Any) -> None:
        self.datos[clave] = valor

    def get(self, clave: str, defecto: Any = None) -> Any:
        """Devuelve ``datos[clave]`` o ``defecto`` si no existe."""
        return self.datos.get(clave, defecto)

    def as_dict(self) -> Dict[str, Any]:
        """Copia profunda de los parámetros."""
        return copy.deepcopy(self.datos)

    # ---- persistencia -------------------------------------------------
    def cargar(self, ruta: Optional[Path] = None) -> None:
        """Lee un JSON y lo fusiona con los valores por defecto.

        Raises:
            ValueError: Si el archivo no es JSON válido o no es un objeto.
            OSError: Si no se puede leer el archivo.
        """
        ruta = Path(ruta) if ruta else self.ruta
        with open(ruta, "r", encoding="utf-8") as fh:
            try:
                leido = json.load(fh)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{ruta.name} no es un JSON válido: {exc}")
        if not isinstance(leido, dict):
            raise ValueError(f"{ruta.name} debe contener un objeto JSON")
        nuevo = copy.deepcopy(CONFIG_DEFECTO)
        nuevo.update(leido)
        nuevo.pop("anonimizar", None)   # clave obsoleta (nunca se leyó): se descarta
        errores = self.validar(nuevo, comprobar_ruta=False)
        if errores:
            raise ValueError("; ".join(f"{k}: {v}" for k, v in errores.items()))
        self.datos = nuevo
        logger.info("Configuración cargada desde %s", ruta)

    def guardar(self, ruta: Optional[Path] = None) -> None:
        """Escribe la configuración actual en formato JSON."""
        ruta = Path(ruta) if ruta else self.ruta
        ruta.parent.mkdir(parents=True, exist_ok=True)
        with open(ruta, "w", encoding="utf-8") as fh:
            json.dump(self.datos, fh, indent=2, ensure_ascii=False)
        logger.info("Configuración guardada en %s", ruta)

    def restablecer(self) -> None:
        """Vuelve a los valores por defecto (no escribe a disco)."""
        self.datos = copy.deepcopy(CONFIG_DEFECTO)

    def actualizar(self, nuevos: Dict[str, Any]) -> None:
        """Actualiza varios parámetros y mantiene ``n_clases`` coherente."""
        self.datos.update(nuevos)
        self.datos["n_clases"] = len(self.datos["clases"])

    def ruta_absoluta(self, clave: str) -> Path:
        """Resuelve una ruta de la configuración respecto a la raíz del proyecto."""
        ruta = Path(str(self.datos[clave]))
        return ruta if ruta.is_absolute() else BASE_DIR / ruta

    # ---- validación ---------------------------------------------------
    @staticmethod
    def validar(datos: Dict[str, Any], comprobar_ruta: bool = True) -> Dict[str, str]:
        """Valida los parámetros.

        Args:
            datos: Diccionario a validar.
            comprobar_ruta: Si es True, exige que la ruta del dataset exista.

        Returns:
            Diccionario ``{campo: mensaje de error}``; vacío si todo es válido.
        """
        errores: Dict[str, str] = {}

        def entero(clave: str, minimo: int, maximo: int) -> None:
            try:
                valor = int(datos[clave])
                if not minimo <= valor <= maximo:
                    errores[clave] = f"Debe estar entre {minimo} y {maximo}."
            except (KeyError, TypeError, ValueError):
                errores[clave] = "Debe ser un número entero."

        if datos.get("modelo") not in ("clasico", "hibrido"):
            errores["modelo"] = "Seleccione 'clasico' o 'hibrido'."
        entero("n_qubits", 2, 8)
        entero("n_capas_pqc", 1, 10)
        entero("seq_length", 2, 64)
        entero("shots", 1, 100000)
        entero("epocas", 1, 1000)
        entero("batch_size", 1, 512)
        entero("img_size", 32, 512)
        try:
            lr = float(datos["learning_rate"])
            if not 0 < lr < 1:
                errores["learning_rate"] = "Debe estar entre 0 y 1 (ej. 0.001)."
        except (KeyError, TypeError, ValueError):
            errores["learning_rate"] = "Debe ser un número decimal (ej. 0.001)."
        try:
            pct = float(datos["congelar_pct"])
            if not 0 <= pct <= 1:
                errores["congelar_pct"] = "Debe estar entre 0 y 1."
        except (KeyError, TypeError, ValueError):
            errores["congelar_pct"] = "Debe ser un número decimal."
        if not isinstance(datos.get("usar_features_tabulares", True), bool):
            errores["usar_features_tabulares"] = "Debe ser verdadero o falso."
        cols = datos.get("columnas_tabulares") or []
        if cols and len(cols) != int(datos.get("n_features_tabulares", len(cols))):
            errores["columnas_tabulares"] = (
                "El número de columnas no coincide con n_features_tabulares.")
        ruta = str(datos.get("ruta_dataset", "")).strip()
        if not ruta:
            errores["ruta_dataset"] = "Indique la ruta del dataset."
        elif comprobar_ruta:
            p = Path(ruta)
            p = p if p.is_absolute() else BASE_DIR / p
            if not p.is_dir():
                errores["ruta_dataset"] = f"La carpeta no existe: {p}"
        return errores
