"""Módulo 7: evaluación y comparación de modelos.

Calcula accuracy, precision, recall y F1 (promedio macro), matriz de
confusión, tiempo por video y uso de recursos (CPU, GPU, RAM) sobre el
conjunto de prueba, y permite comparar y exportar los resultados.

No importa TensorFlow: recibe los modelos ya construidos.
"""
import csv
import json
import logging
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import psutil

from modulos.configuracion import RESULTADOS_DIR
from modulos.persistencia import RepositorioModelos
from modulos.preprocesamiento import Preprocesador

logger = logging.getLogger(__name__)

# (etiqueta, clave en el resultado)
FILAS_COMPARACION = [
    ("Accuracy", "accuracy"), ("Precision", "precision"),
    ("Recall", "recall"), ("F1-Score", "f1"),
    ("Tiempo/video (s)", "tiempo_por_video"), ("CPU (%)", "cpu"),
    ("GPU (%)", "gpu"), ("RAM (MB)", "ram_mb"),
]


class MonitorRecursos:
    """Mide CPU (%), GPU (%) y RAM (MB) del proceso.

    Puede usarse de forma puntual (:meth:`instantanea`) o como muestreador
    en segundo plano (:meth:`iniciar` / :meth:`detener`), que devuelve los
    promedios. La GPU se consulta con ``nvidia-smi``; si no existe se
    reporta 0 %.
    """

    def __init__(self, intervalo: float = 0.5) -> None:
        self.intervalo = intervalo
        self._muestras: List[Dict[str, float]] = []
        self._hilo: Optional[threading.Thread] = None
        self._activo = threading.Event()
        psutil.cpu_percent(None)  # primera llamada: inicializa el contador

    @staticmethod
    def _gpu() -> float:
        if shutil.which("nvidia-smi") is None:
            return 0.0
        try:
            salida = subprocess.run(
                ["nvidia-smi", "--query-gpu=utilization.gpu",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=2,
                creationflags=0x08000000 if os.name == "nt" else 0)
            valores = [float(v) for v in salida.stdout.split() if v.strip()]
            return float(np.mean(valores)) if valores else 0.0
        except Exception:  # noqa: BLE001
            return 0.0

    def instantanea(self) -> Dict[str, float]:
        """Lectura puntual de ``cpu``, ``gpu`` y ``ram_mb``."""
        return {"cpu": float(psutil.cpu_percent(None)), "gpu": self._gpu(),
                "ram_mb": psutil.Process().memory_info().rss / (1024 * 1024)}

    def _bucle(self) -> None:
        while self._activo.is_set():
            self._muestras.append(self.instantanea())
            time.sleep(self.intervalo)

    def iniciar(self) -> None:
        """Comienza el muestreo en segundo plano."""
        self._muestras = []
        self._activo.set()
        self._hilo = threading.Thread(target=self._bucle, daemon=True)
        self._hilo.start()

    def detener(self) -> Dict[str, float]:
        """Detiene el muestreo y devuelve los promedios."""
        self._activo.clear()
        if self._hilo:
            self._hilo.join(timeout=3)
        if not self._muestras:
            self._muestras = [self.instantanea()]
        return {k: float(np.mean([m[k] for m in self._muestras]))
                for k in ("cpu", "gpu", "ram_mb")}


class Evaluador:
    """Evalúa modelos entrenados y compara sus resultados.

    Args:
        cfg: Configuración vigente.
        repositorio: Origen de los modelos guardados.
    """

    def __init__(self, cfg, repositorio: Optional[RepositorioModelos] = None) -> None:
        self.cfg = cfg
        self.repositorio = repositorio or RepositorioModelos()

    def evaluar(self, nombre: str, modelo=None, clases: Optional[List[str]] = None) -> dict:
        """Evalúa un modelo sobre el split ``test``.

        Args:
            nombre: ``"clasico"`` o ``"hibrido"``.
            modelo: Modelo Keras; si es None se carga del repositorio.
            clases: Nombres de clase; por defecto los de la configuración.

        Returns:
            Diccionario con las métricas, la matriz de confusión y recursos.
        """
        from sklearn.metrics import (accuracy_score, confusion_matrix,
                                     precision_recall_fscore_support)
        if modelo is None:
            modelo, clases, params = self.repositorio.cargar(nombre)
        else:
            try:
                params = self.repositorio.cargar_parametros(nombre)
            except FileNotFoundError:   # modelo en memoria que aún no se guardó
                params = self.cfg.as_dict()
                params["usar_features_tabulares"] = len(modelo.inputs) > 1
        clases = clases or list(self.cfg["clases"])
        # Lo que el modelo necesita (imagen sola o imagen + features) lo decide el
        # MODELO guardado, no la configuración actual; las estadísticas de
        # imputación/normalización son las de su entrenamiento.
        usar_tab = bool(params.get("usar_features_tabulares", False))
        prep = Preprocesador(self.cfg)
        prep.detectar_clases()
        if usar_tab:
            prep.fijar_estadisticas(params)
        # listar_muestras y crear_dataset aplican el mismo filtro (requiere_poses),
        # por lo que y_true queda alineado con las predicciones.
        _, _, y_true = prep.listar_muestras("test", requiere_poses=usar_tab)
        ds = prep.crear_dataset("test", entrenamiento=False, tabular=usar_tab)
        logger.info("Evaluando modelo %s sobre %d videos (%s)", nombre, len(y_true),
                    "imagen + features tabulares" if usar_tab else "solo imagen")
        modelo.predict(ds.take(1), verbose=0)  # calentamiento (trazado del grafo)
        monitor = MonitorRecursos()
        monitor.iniciar()
        t0 = time.perf_counter()
        probs = modelo.predict(ds, verbose=0)
        duracion = time.perf_counter() - t0
        uso = monitor.detener()
        y_pred = np.argmax(probs, axis=1)
        p, r, f1, _ = precision_recall_fscore_support(
            y_true, y_pred, average="macro", zero_division=0)
        matriz = confusion_matrix(y_true, y_pred, labels=list(range(len(clases))))
        resultado = {
            "nombre": nombre, "clases": list(clases), "n_videos": int(len(y_true)),
            "accuracy": float(accuracy_score(y_true, y_pred)),
            "precision": float(p), "recall": float(r), "f1": float(f1),
            "tiempo_por_video": float(duracion / max(1, len(y_true))),
            "cpu": uso["cpu"], "gpu": uso["gpu"], "ram_mb": uso["ram_mb"],
            "matriz": matriz.tolist(),
        }
        self.guardar_resultados(nombre, resultado)
        return resultado

    # ---- persistencia de resultados ------------------------------------------------
    @staticmethod
    def guardar_resultados(nombre: str, resultado: dict) -> Path:
        """Guarda el resultado en ``datos/resultados/eval_<nombre>.json``."""
        RESULTADOS_DIR.mkdir(parents=True, exist_ok=True)
        ruta = RESULTADOS_DIR / f"eval_{nombre}.json"
        with open(ruta, "w", encoding="utf-8") as fh:
            json.dump(resultado, fh, indent=2)
        return ruta

    @staticmethod
    def cargar_resultados(nombre: str) -> Optional[dict]:
        """Lee un resultado guardado; None si no existe o está dañado."""
        ruta = RESULTADOS_DIR / f"eval_{nombre}.json"
        if not ruta.exists():
            return None
        try:
            with open(ruta, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return None

    # ---- comparación y exportación ------------------------------------------------------
    @staticmethod
    def comparar(clasico: Optional[dict], hibrido: Optional[dict]) -> List[tuple]:
        """Tabla comparativa ``(métrica, clásico, híbrido, diferencia)``.

        La diferencia es ``híbrido - clásico``. Los valores ausentes son None.
        """
        filas = []
        for etiqueta, clave in FILAS_COMPARACION:
            c = clasico.get(clave) if clasico else None
            h = hibrido.get(clave) if hibrido else None
            d = (h - c) if (c is not None and h is not None) else None
            filas.append((etiqueta, c, h, d))
        return filas

    @staticmethod
    def exportar_csv(filas: List[tuple], ruta: Path) -> None:
        """Exporta la tabla comparativa a CSV."""
        with open(ruta, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["Métrica", "Modelo Clásico", "Modelo Híbrido", "Diferencia"])
            for fila in filas:
                w.writerow(["" if v is None else (f"{v:.6f}" if isinstance(v, float) else v)
                            for v in fila])

    @staticmethod
    def graficar_barras(fig, clasico: Optional[dict], hibrido: Optional[dict]) -> None:
        """Dibuja barras dobles de Accuracy, Precision, Recall y F1."""
        fig.clear()
        ax = fig.add_subplot(111)
        etiquetas = ["Accuracy", "Precision", "Recall", "F1-Score"]
        claves = ["accuracy", "precision", "recall", "f1"]
        x = np.arange(len(etiquetas))
        ancho = 0.38
        vc = [(clasico or {}).get(k, 0.0) for k in claves]
        vh = [(hibrido or {}).get(k, 0.0) for k in claves]
        b1 = ax.bar(x - ancho / 2, vc, ancho, label="Clásico", color="#2f6fb0")
        b2 = ax.bar(x + ancho / 2, vh, ancho, label="Híbrido", color="#e08a1e")
        for barras in (b1, b2):
            for b in barras:
                ax.annotate(f"{b.get_height():.2f}",
                            (b.get_x() + b.get_width() / 2, b.get_height()),
                            ha="center", va="bottom", fontsize=8)
        ax.set_xticks(x)
        ax.set_xticklabels(etiquetas)
        ax.set_ylim(0, 1.1)
        ax.set_title("Comparación de métricas")
        ax.legend()
        fig.tight_layout()

    @staticmethod
    def graficar_matriz(fig, resultado: Optional[dict], titulo: str = "") -> None:
        """Dibuja la matriz de confusión como mapa de calor."""
        fig.clear()
        ax = fig.add_subplot(111)
        if not resultado:
            ax.text(0.5, 0.5, "Sin resultados", ha="center", va="center")
            ax.axis("off")
            return
        m = np.array(resultado["matriz"])
        clases = resultado["clases"]
        im = ax.imshow(m, cmap="Blues")
        ax.set_xticks(range(len(clases)))
        ax.set_yticks(range(len(clases)))
        ax.set_xticklabels(clases, rotation=30, ha="right")
        ax.set_yticklabels(clases)
        ax.set_xlabel("Predicción")
        ax.set_ylabel("Real")
        ax.set_title(titulo or "Matriz de confusión")
        umbral = m.max() / 2 if m.size else 0
        for i in range(m.shape[0]):
            for j in range(m.shape[1]):
                ax.text(j, i, int(m[i, j]), ha="center", va="center",
                        color="white" if m[i, j] > umbral else "black")
        fig.colorbar(im, ax=ax, fraction=0.046)
        fig.tight_layout()
