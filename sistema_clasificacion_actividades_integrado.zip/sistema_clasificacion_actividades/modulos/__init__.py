"""Módulos del backend del Sistema de Clasificación de Actividades Físicas."""
