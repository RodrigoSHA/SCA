"""Módulo 8: detección de actividades en tiempo real.

Arquitectura de hilos (para sostener >= 15 FPS):

* **Hilo de captura**: lee la cámara; en los frames muestreados (1 de cada
  ``paso_muestreo``) extrae los 33 landmarks con **MediaPipe Pose** (solo si el
  modelo usa la rama tabular; sobre el frame original, como en el
  entrenamiento); anonimiza rostros (desenfoque gaussiano), alimenta el búfer de
  imágenes y el búfer paralelo de poses, dibuja la superposición y publica el
  frame más reciente.
* **Hilo de inferencia**: toma una copia de los búferes, calcula
  ``features_desde_poses`` (misma función que el entrenamiento), las imputa y
  normaliza con las estadísticas guardadas con el modelo y ejecuta el modelo a
  su propio ritmo, sin bloquear la captura.

Requiere MediaPipe Pose además de Face Detection cuando el modelo es multimodal.
Los modelos antiguos (un solo input) no usan Pose ni cambian de comportamiento.

La GUI solo llama a :meth:`DetectorTiempoReal.obtener_estado`.
"""
import logging
import threading
import time
from collections import deque
from typing import Deque, List, Optional

import cv2
import numpy as np

from modulos.preprocesamiento import (Anonimizador, Preprocesador,
                                      normalizar_features)

logger = logging.getLogger(__name__)


def _analizar_entradas(modelo):
    """Identifica las entradas del modelo (por su rango, no por su posición).

    Returns:
        ``(forma_imagenes, indice_imagenes, forma_tabular, indice_tabular)``;
        los dos últimos son ``None`` si el modelo tiene un solo input.

    Raises:
        ValueError: Si las entradas no son (T,S,S,3) [+ (F,)].
    """
    formas = modelo.input_shape
    if isinstance(formas, tuple) and (not formas or not isinstance(formas[0], (tuple, list))):
        formas = [formas]                      # un solo input: input_shape es una tupla
    formas = [tuple(f) for f in formas]
    i_img = [i for i, f in enumerate(formas) if len(f) == 5]
    i_tab = [i for i, f in enumerate(formas) if len(f) == 2]
    if len(i_img) != 1 or len(formas) - 1 != len(i_tab):
        raise ValueError(f"Entradas del modelo no soportadas: {formas}")
    if not i_tab:
        return formas[i_img[0]], i_img[0], None, None
    return formas[i_img[0]], i_img[0], formas[i_tab[0]], i_tab[0]


class DetectorTiempoReal:
    """Clasifica la actividad que se ve en la cámara.

    Args:
        modelo: Modelo Keras con entrada ``(None, T, S, S, 3)`` (modelo antiguo)
            o con dos entradas ``[(None, T, S, S, 3), (None, F)]`` (multimodal).
        clases: Nombres de clase.
        indice_camara: Índice de la cámara de OpenCV (también acepta la ruta de
            un video, útil para pruebas y mediciones).
        paso_muestreo: Se agrega un frame al búfer cada ``paso_muestreo``
            frames capturados (a ~30 FPS, 4 equivale a una ventana de ~1 s
            para ``T = 8``).
        params: Parámetros guardados del modelo (``config_<modelo>.json``).
            Obligatorios si el modelo es multimodal: traen ``columnas_tabulares``,
            ``medias_imputacion``, ``medias_normalizacion`` y ``stds_normalizacion``.

    Attributes:
        usa_tabular: True si el modelo tiene rama tabular (se usa MediaPipe Pose).
    """

    def __init__(self, modelo, clases: List[str], indice_camara=0,
                 paso_muestreo: int = 4, params: Optional[dict] = None) -> None:
        forma_img, self._i_img, forma_tab, self._i_tab = _analizar_entradas(modelo)
        _, self.seq_length, self.img_size, _, _ = forma_img
        self.usa_tabular = forma_tab is not None
        self._stats = None
        if self.usa_tabular:
            self._stats = Preprocesador.estadisticas_desde_dict(params or {})
            if self._stats is None:
                raise ValueError(
                    "El modelo usa features tabulares pero no se recibieron sus "
                    "parámetros (columnas/medias/stds). Cárguelo con "
                    "RepositorioModelos.cargar y pase params=...")
            if len(self._stats["columnas"]) != int(forma_tab[1]):
                raise ValueError(
                    f"El modelo espera {forma_tab[1]} features y los parámetros "
                    f"guardados tienen {len(self._stats['columnas'])}.")
        self.modelo = modelo
        self.clases = list(clases)
        self.indice_camara = indice_camara
        self.paso_muestreo = max(1, paso_muestreo)
        self._buffer: Deque[np.ndarray] = deque(maxlen=self.seq_length)
        # Búfer paralelo de poses (33, 4): se rellena a la vez que _buffer, bajo el mismo lock.
        self._buffer_poses: Deque[np.ndarray] = deque(maxlen=self.seq_length)
        self._aspecto = 640.0 / 480.0
        self._version = 0          # +1 con cada muestra nueva; evita re-inferir lo mismo
        self._n_frames = 0         # contadores para medir rendimiento (benchmark)
        self._n_inferencias = 0
        self._lock = threading.Lock()
        self._activo = threading.Event()
        self._hilos: List[threading.Thread] = []
        self._frame: Optional[np.ndarray] = None
        self._pred = ("", 0.0)
        self._fps = 0.0
        self._error: Optional[str] = None
        self._historial: Deque[tuple] = deque(maxlen=5)
        self._ultimo_hist = (None, 0.0)

    # ---- ciclo de vida --------------------------------------------------------------
    def iniciar(self) -> None:
        """Abre la cámara y lanza los hilos de captura e inferencia."""
        if self._activo.is_set():
            return
        self._error = None
        self._activo.set()
        self._hilos = [
            threading.Thread(target=self._bucle_captura, name="captura", daemon=True),
            threading.Thread(target=self._bucle_inferencia, name="inferencia", daemon=True),
        ]
        for h in self._hilos:
            h.start()

    def detener(self) -> None:
        """Detiene ambos hilos y libera la cámara."""
        self._activo.clear()
        for h in self._hilos:
            h.join(timeout=3)
        self._hilos = []

    @property
    def activo(self) -> bool:
        """True mientras los hilos estén en ejecución."""
        return self._activo.is_set()

    def obtener_estado(self) -> dict:
        """Instantánea para la GUI.

        Returns:
            Diccionario con ``frame`` (RGB anotado o None), ``clase``,
            ``confianza``, ``fps``, ``historial`` (últimas 5 predicciones),
            ``error`` (mensaje o None), y los contadores acumulados
            ``frames_capturados`` e ``inferencias``.
        """
        with self._lock:
            return {"frame": self._frame, "clase": self._pred[0],
                    "confianza": self._pred[1], "fps": self._fps,
                    "historial": list(self._historial), "error": self._error,
                    "frames_capturados": self._n_frames,
                    "inferencias": self._n_inferencias}

    # ---- hilos --------------------------------------------------------------------
    @staticmethod
    def _crear_pose():
        """MediaPipe Pose con la misma configuración que el entrenamiento
        (``extraer_poses``: complejidad 1, confianza 0.5, suavizado activo)."""
        from modulos.preparar_dataset import PARAMETROS_DETECTOR as p
        import mediapipe as mp
        return mp.solutions.pose.Pose(
            static_image_mode=False, model_complexity=int(p["complejidad_pose"]),
            smooth_landmarks=True,
            min_detection_confidence=float(p["confianza_mediapipe"]),
            min_tracking_confidence=float(p["confianza_mediapipe"]))

    @staticmethod
    def _extraer_pose(pose, frame_bgr: np.ndarray) -> np.ndarray:
        """Landmarks ``(33, 4)`` = (x, y, z, visibilidad); todo NaN si no hay persona.

        Igual que en el entrenamiento: sobre el frame ORIGINAL (antes del blur) y
        reducido a ``max_lado_procesamiento`` como máximo.
        """
        from modulos.preparar_dataset import PARAMETROS_DETECTOR as p
        h, w = frame_bgr.shape[:2]
        lado = int(p["max_lado_procesamiento"])
        if max(h, w) > lado:
            e = lado / float(max(h, w))
            frame_bgr = cv2.resize(frame_bgr, (int(w * e), int(h * e)),
                                   interpolation=cv2.INTER_AREA)
        res = pose.process(cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB))
        if res.pose_landmarks:
            return np.array([[l.x, l.y, l.z, l.visibility]
                             for l in res.pose_landmarks.landmark], dtype=float)
        return np.full((33, 4), np.nan)

    def _bucle_captura(self) -> None:
        anon = Anonimizador()
        pose = None
        cap = cv2.VideoCapture(self.indice_camara)
        if not cap.isOpened():
            with self._lock:
                self._error = (f"No se pudo abrir la cámara {self.indice_camara}. "
                               "Verifique que esté conectada y no esté en uso.")
            self._activo.clear()
            anon.cerrar()
            return
        if self.usa_tabular:
            # MediaPipe Pose se crea y se usa SOLO en este hilo (no es thread-safe).
            try:
                pose = self._crear_pose()
            except Exception as exc:  # noqa: BLE001
                logger.exception("MediaPipe Pose no disponible")
                with self._lock:
                    self._error = ("El modelo usa features tabulares y requiere MediaPipe "
                                   f"Pose (mediapipe==0.10.9). Detalle: {exc}")
                cap.release()
                anon.cerrar()
                self._activo.clear()
                return
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cajas: list = []
        contador = 0
        t_prev = time.perf_counter()
        try:
            while self._activo.is_set():
                ok, frame = cap.read()
                if not ok:
                    with self._lock:
                        self._error = "Se perdió la señal de la cámara."
                    break
                muestrear = contador % self.paso_muestreo == 0
                pose_frame = None
                if muestrear and pose is not None:
                    # Antes del blur: el entrenamiento extrajo las poses del video original.
                    pose_frame = self._extraer_pose(pose, frame)
                # La detección facial es costosa: se refresca cada 3 frames y
                # se reutilizan las cajas entre medias (el blur es siempre).
                if contador % 3 == 0:
                    cajas = anon.detectar(frame)
                anon.difuminar(frame, cajas)
                if muestrear:
                    rgb = Preprocesador.preparar_frame(frame, self.img_size)
                    with self._lock:
                        self._buffer.append(rgb)
                        if pose_frame is not None:
                            self._buffer_poses.append(pose_frame)
                            self._aspecto = frame.shape[1] / float(frame.shape[0])
                        self._version += 1
                contador += 1
                self._n_frames = contador
                ahora = time.perf_counter()
                dt = max(ahora - t_prev, 1e-6)
                t_prev = ahora
                with self._lock:
                    self._fps = 0.9 * self._fps + 0.1 / dt if self._fps else 1.0 / dt
                    clase, conf = self._pred
                    fps = self._fps
                self._dibujar(frame, clase, conf, fps)
                rgb_mostrar = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                with self._lock:
                    self._frame = rgb_mostrar
        finally:
            cap.release()
            anon.cerrar()
            if pose is not None:
                pose.close()
            self._activo.clear()

    def _predecir(self, secuencia: np.ndarray, poses: Optional[np.ndarray],
                  aspecto: float) -> np.ndarray:
        """Probabilidades para una ventana de ``seq_length`` frames (y sus poses)."""
        x_img = secuencia[np.newaxis].astype(np.float32)      # rango 0-255
        if not self.usa_tabular:
            return self.modelo(x_img, training=False).numpy()[0]
        from modulos.preparar_dataset import features_desde_poses
        st = self._stats
        crudas = features_desde_poses(poses, aspecto)         # misma función que train
        x_tab = normalizar_features(crudas, st["columnas"], st["medias_imputacion"],
                                    st["mu"], st["sd"])[np.newaxis]
        entradas = [None, None]
        entradas[self._i_img], entradas[self._i_tab] = x_img, x_tab
        return self.modelo(entradas, training=False).numpy()[0]

    def _bucle_inferencia(self) -> None:
        ultima_version = -1
        while self._activo.is_set():
            with self._lock:
                listo = (len(self._buffer) == self.seq_length
                         and self._version != ultima_version
                         and (not self.usa_tabular
                              or len(self._buffer_poses) == self.seq_length))
                if listo:
                    secuencia = np.stack(self._buffer)
                    poses = np.stack(self._buffer_poses) if self.usa_tabular else None
                    aspecto = self._aspecto
                    ultima_version = self._version
            if not listo:
                time.sleep(0.05)
                continue
            try:
                probs = self._predecir(secuencia, poses, aspecto)
            except Exception as exc:  # noqa: BLE001
                logger.exception("Error de inferencia")
                with self._lock:
                    self._error = f"Error de inferencia: {exc}"
                self._activo.clear()
                return
            idx = int(np.argmax(probs))
            clase, conf = self.clases[idx], float(probs[idx])
            ahora = time.time()
            with self._lock:
                self._pred = (clase, conf)
                self._n_inferencias += 1
                # Historial: solo cuando cambia la clase o pasan 2 s.
                if clase != self._ultimo_hist[0] or ahora - self._ultimo_hist[1] > 2.0:
                    self._historial.appendleft(
                        (time.strftime("%H:%M:%S"), clase, conf))
                    self._ultimo_hist = (clase, ahora)
            time.sleep(0.02)

    @staticmethod
    def _dibujar(frame: np.ndarray, clase: str, conf: float, fps: float) -> None:
        """Superpone la etiqueta de actividad y los FPS (in situ, BGR)."""
        alto, ancho = frame.shape[:2]
        texto = (f"Actividad: {clase} (confianza: {conf * 100:.0f}%)"
                 if clase else "Actividad: analizando...")
        fuente = cv2.FONT_HERSHEY_SIMPLEX
        (tw, th), _ = cv2.getTextSize(texto, fuente, 0.7, 2)
        cv2.rectangle(frame, (8, 8), (16 + tw, 20 + th), (0, 0, 0), -1)
        cv2.putText(frame, texto, (12, 14 + th), fuente, 0.7, (255, 255, 255), 2,
                    cv2.LINE_AA)
        etiqueta_fps = f"FPS: {fps:.1f}"
        (fw, fh), _ = cv2.getTextSize(etiqueta_fps, fuente, 0.6, 2)
        cv2.rectangle(frame, (ancho - fw - 20, 8), (ancho - 8, 20 + fh), (0, 0, 0), -1)
        cv2.putText(frame, etiqueta_fps, (ancho - fw - 14, 14 + fh), fuente, 0.6,
                    (0, 255, 0), 2, cv2.LINE_AA)
