"""Módulo 9: guardado y carga de modelos.

Archivos generados en ``modelos_guardados/``:

* ``modelo_clasico.h5`` / ``modelo_hibrido.h5``: pesos de cada modelo (HDF5).
* ``quantum_weights.npy``: pesos entrenables del PQC.
* ``class_names.txt``: una clase por línea.
* ``config.json``: configuración global al momento de guardar.
* ``config_clasico.json`` / ``config_hibrido.json``: parámetros de arquitectura
  para reconstruir cada modelo exactamente como fue entrenado. Si el modelo usa
  la rama tabular incluyen además ``usar_features_tabulares``, ``n_features_tabulares``,
  ``columnas_tabulares`` (orden exacto), ``medias_imputacion``, ``medias_normalizacion``
  y ``stds_normalizacion``: son parte del modelo y las usan evaluación e inferencia.
  Un JSON sin ``usar_features_tabulares`` (modelo anterior a la rama tabular) se
  interpreta como ``False`` y se reconstruye el modelo de un solo input.

Se guardan pesos (no el modelo serializado completo) porque la capa cuántica
de PennyLane no es serializable por ``model.save``; la arquitectura se
reconstruye desde los JSON de parámetros.
"""
import json
import logging
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

from modulos.configuracion import MODELOS_DIR

logger = logging.getLogger(__name__)


class RepositorioModelos:
    """Guarda y recupera los modelos entrenados.

    Args:
        directorio: Carpeta de destino (por defecto ``modelos_guardados``).
    """

    ARCHIVOS = {"clasico": "modelo_clasico.h5", "hibrido": "modelo_hibrido.h5"}

    def __init__(self, directorio: Optional[Path] = None) -> None:
        self.directorio = Path(directorio) if directorio else MODELOS_DIR
        self.directorio.mkdir(parents=True, exist_ok=True)

    def _ruta(self, nombre: str) -> Path:
        if nombre not in self.ARCHIVOS:
            raise ValueError(f"Modelo desconocido: {nombre!r}")
        return self.directorio / self.ARCHIVOS[nombre]

    def existe(self, nombre: str) -> bool:
        """True si hay pesos y parámetros guardados para ``nombre``."""
        return (self._ruta(nombre).exists()
                and (self.directorio / f"config_{nombre}.json").exists())

    def guardar(self, nombre: str, wrapper, cfg, clases: List[str]) -> None:
        """Guarda un modelo y sus metadatos.

        Args:
            nombre: ``"clasico"`` o ``"hibrido"``.
            wrapper: Instancia de ``ModeloClasico`` o ``ModeloHibrido``.
            cfg: Configuración vigente.
            clases: Nombres de las clases en orden de índice.
        """
        params = wrapper.parametros()
        if params.get("usar_features_tabulares"):
            self._validar_tabulares(params, "guardar")
        wrapper.modelo.save_weights(str(self._ruta(nombre)))
        with open(self.directorio / f"config_{nombre}.json", "w",
                  encoding="utf-8") as fh:
            json.dump(params, fh, indent=2)
        if nombre == "hibrido":
            np.save(self.directorio / "quantum_weights.npy",
                    wrapper.obtener_pesos_cuanticos())
        (self.directorio / "class_names.txt").write_text(
            "\n".join(clases), encoding="utf-8")
        cfg.guardar(self.directorio / "config.json")
        logger.info("Modelo %s guardado en %s", nombre, self.directorio)

    @staticmethod
    def _validar_tabulares(params: dict, accion: str) -> None:
        """Comprueba que las estadísticas de la rama tabular sean coherentes.

        Raises:
            ValueError: Si faltan o no cuadran (un modelo así no se puede evaluar
                ni usar en inferencia de forma fiable).
        """
        cols = params.get("columnas_tabulares") or []
        n = int(params.get("n_features_tabulares", 0))
        if (not cols or len(cols) != n
                or len(params.get("medias_normalizacion") or []) != n
                or len(params.get("stds_normalizacion") or []) != n
                or len(params.get("medias_imputacion") or {}) != n):
            raise ValueError(
                f"No se puede {accion} el modelo: usa features tabulares pero "
                "columnas_tabulares / medias_imputacion / medias_normalizacion / "
                "stds_normalizacion faltan o no tienen n_features_tabulares elementos.")
        from modulos.preparar_dataset import NOMBRES_FEATURES
        if list(cols) != list(NOMBRES_FEATURES):
            raise ValueError(
                f"No se puede {accion} el modelo: el orden de columnas_tabulares no "
                "coincide con preparar_dataset.NOMBRES_FEATURES (reentrene el modelo).")

    def cargar_parametros(self, nombre: str) -> dict:
        """Lee ``config_<nombre>.json`` sin construir el modelo.

        Returns:
            Parámetros guardados. Los modelos anteriores a la rama tabular no
            traen ``usar_features_tabulares``; se completa con ``False``.

        Raises:
            FileNotFoundError: Si no existe el modelo.
        """
        if not self.existe(nombre):
            raise FileNotFoundError(
                f"No hay un modelo {nombre} guardado en {self.directorio}.")
        with open(self.directorio / f"config_{nombre}.json", "r",
                  encoding="utf-8") as fh:
            params = json.load(fh)
        params.setdefault("usar_features_tabulares", False)
        return params

    def cargar_clases(self) -> List[str]:
        """Lee ``class_names.txt``."""
        ruta = self.directorio / "class_names.txt"
        if not ruta.exists():
            raise FileNotFoundError("No existe class_names.txt; entrene un modelo primero.")
        return [l for l in ruta.read_text(encoding="utf-8").splitlines() if l]

    def cargar(self, nombre: str) -> Tuple[object, List[str], dict]:
        """Reconstruye y carga un modelo guardado.

        Returns:
            ``(modelo_keras, clases, parametros)``.

        Raises:
            FileNotFoundError: Si el modelo no se ha entrenado/guardado.
        """
        if not self.existe(nombre):
            raise FileNotFoundError(
                f"No hay un modelo {nombre} guardado en {self.directorio}. "
                "Entrénelo primero desde la pantalla de Entrenamiento.")
        # Imports tardíos: evitan cargar TensorFlow hasta que hace falta.
        from modulos.modelo_clasico import ModeloClasico
        from modulos.modelo_hibrido import ModeloHibrido
        params = self.cargar_parametros(nombre)
        if params["usar_features_tabulares"]:
            self._validar_tabulares(params, "cargar")
        clases = self.cargar_clases()
        params.setdefault("n_clases", len(clases))
        if nombre == "clasico":
            wrapper = ModeloClasico(params, pesos_imagenet=False)
        else:
            wrapper = ModeloHibrido(params, pesos_imagenet=False)
        wrapper.construir()
        wrapper.modelo.load_weights(str(self._ruta(nombre)))
        npy = self.directorio / "quantum_weights.npy"
        if nombre == "hibrido" and npy.exists():
            try:
                wrapper.asignar_pesos_cuanticos(np.load(npy))
            except Exception as exc:  # noqa: BLE001
                logger.warning("No se aplicaron quantum_weights.npy: %s", exc)
        logger.info("Modelo %s cargado (%s)", nombre,
                    "imagen + features tabulares" if params["usar_features_tabulares"]
                    else "solo imagen")
        return wrapper.modelo, clases, params
